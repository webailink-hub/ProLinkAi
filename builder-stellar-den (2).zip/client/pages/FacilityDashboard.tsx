import {
  BarChart3,
  TrendingUp,
  Users,
  Calendar,
  DollarSign,
  Clock,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Target,
  Activity,
  Zap,
  Plus,
  Filter,
  Download,
  Search,
  MoreHorizontal,
  ArrowUpRight,
  ArrowDownRight,
  Star,
  MapPin,
  Award,
  Eye,
  MessageSquare,
  Bell,
  Settings,
  ChevronRight,
  TrendingDown,
  Percent,
  Timer,
} from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function FacilityDashboard() {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState("30d");
  const [selectedDepartment, setSelectedDepartment] = useState("all");

  // Mock data for demonstration
  const facilityMetrics = {
    totalShifts: 456,
    filledShifts: 423,
    avgFillTime: 2.3,
    totalSpend: 125000,
    savings: 35000,
    nurseRating: 4.7,
  };

  const departments = [
    {
      name: "ICU",
      shifts: 89,
      filled: 87,
      avgRate: 52,
      savings: 8500,
      fillTime: 1.8,
    },
    {
      name: "Emergency",
      shifts: 76,
      filled: 74,
      avgRate: 48,
      savings: 6200,
      fillTime: 2.1,
    },
    {
      name: "Medical-Surgical",
      shifts: 134,
      filled: 129,
      avgRate: 42,
      savings: 9800,
      fillTime: 2.5,
    },
    {
      name: "OR",
      shifts: 67,
      filled: 65,
      avgRate: 58,
      savings: 5200,
      fillTime: 1.9,
    },
    {
      name: "Pediatrics",
      shifts: 45,
      filled: 43,
      avgRate: 44,
      savings: 3100,
      fillTime: 2.8,
    },
    {
      name: "Oncology",
      shifts: 45,
      filled: 45,
      avgRate: 46,
      savings: 2200,
      fillTime: 1.5,
    },
  ];

  const recentShifts = [
    {
      id: "SH-001",
      department: "ICU",
      date: "Today",
      nurse: "Sarah Johnson, RN",
      status: "confirmed",
      rate: 52,
      time: "7p-7a",
    },
    {
      id: "SH-002",
      department: "Emergency",
      date: "Tomorrow",
      nurse: "Mike Chen, RN",
      status: "pending",
      rate: 48,
      time: "3p-11p",
    },
    {
      id: "SH-003",
      department: "ICU",
      date: "Dec 15",
      nurse: "Lisa Rodriguez, RN",
      status: "filled",
      rate: 54,
      time: "7a-7p",
    },
    {
      id: "SH-004",
      department: "OR",
      date: "Dec 16",
      nurse: "David Wilson, RN",
      status: "filled",
      rate: 58,
      time: "6a-2p",
    },
    {
      id: "SH-005",
      department: "Med-Surg",
      date: "Dec 17",
      nurse: "Open Position",
      status: "urgent",
      rate: 42,
      time: "11p-7a",
    },
  ];

  const topNurses = [
    {
      name: "Sarah Johnson",
      rating: 4.9,
      shifts: 23,
      specialty: "ICU",
      lastShift: "2 days ago",
    },
    {
      name: "Michael Chen",
      rating: 4.8,
      shifts: 19,
      specialty: "Emergency",
      lastShift: "1 day ago",
    },
    {
      name: "Lisa Rodriguez",
      rating: 4.7,
      shifts: 21,
      specialty: "ICU",
      lastShift: "3 days ago",
    },
    {
      name: "David Wilson",
      rating: 4.9,
      shifts: 15,
      specialty: "OR",
      lastShift: "Today",
    },
    {
      name: "Amanda Taylor",
      rating: 4.6,
      shifts: 18,
      specialty: "Med-Surg",
      lastShift: "4 days ago",
    },
  ];

  const aiRecommendations = [
    {
      type: "cost-optimization",
      title: "Reduce ICU Overtime by 25%",
      description:
        "AI predicts you can save $8,500/month by scheduling 3 additional per diem shifts during peak hours",
      impact: "$8,500",
      confidence: 94,
    },
    {
      type: "quality-improvement",
      title: "Improve Patient Satisfaction",
      description:
        "Deploy Sarah Johnson (4.9★) to Weekend ICU shifts to boost satisfaction scores",
      impact: "+0.3 points",
      confidence: 87,
    },
    {
      type: "staffing-prediction",
      title: "Prepare for Flu Season Surge",
      description:
        "AI forecasts 40% increase in shift demand starting next week. Pre-book 8 nurses now.",
      impact: "Avoid gaps",
      confidence: 91,
    },
  ];

  const costBreakdown = [
    {
      category: "Regular Staff",
      amount: 89000,
      percentage: 71,
      trend: "down",
      change: -5.2,
    },
    {
      category: "Per Diem Nurses",
      amount: 25000,
      percentage: 20,
      trend: "up",
      change: 12.3,
    },
    {
      category: "Overtime",
      amount: 8000,
      percentage: 6,
      trend: "down",
      change: -35.4,
    },
    {
      category: "Agency Staff",
      amount: 3000,
      percentage: 3,
      trend: "down",
      change: -68.1,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-header font-bold text-gray-900">
            Staffing Dashboard
          </h1>
          <p className="text-gray-600 font-body">
            Real-time insights and AI-powered recommendations for Metro General
            Hospital
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedDepartment}
            onChange={(e) => setSelectedDepartment(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg font-body focus:ring-2 focus:ring-medical-blue focus:border-transparent"
          >
            <option value="all">All Departments</option>
            <option value="icu">ICU</option>
            <option value="emergency">Emergency</option>
            <option value="med-surg">Medical-Surgical</option>
            <option value="or">Operating Room</option>
          </select>
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg font-body focus:ring-2 focus:ring-medical-blue focus:border-transparent"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2 bg-medical-blue text-white rounded-lg hover:bg-blue-700 transition-colors font-body">
            <Plus className="w-4 h-4" />
            Post Shift
          </button>
        </div>
      </div>

      {/* Key Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <Calendar className="w-5 h-5 text-medical-blue" />
            <div className="flex items-center text-medical-green text-xs">
              <ArrowUpRight className="w-3 h-3 mr-1" />
              +12%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            {facilityMetrics.totalShifts}
          </h3>
          <p className="text-gray-600 text-sm font-body">Total Shifts</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle2 className="w-5 h-5 text-medical-green" />
            <div className="flex items-center text-medical-green text-xs">
              <ArrowUpRight className="w-3 h-3 mr-1" />
              +8%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            {(
              (facilityMetrics.filledShifts / facilityMetrics.totalShifts) *
              100
            ).toFixed(1)}
            %
          </h3>
          <p className="text-gray-600 text-sm font-body">Fill Rate</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <Clock className="w-5 h-5 text-ai-purple" />
            <div className="flex items-center text-medical-green text-xs">
              <ArrowDownRight className="w-3 h-3 mr-1" />
              -45%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            {facilityMetrics.avgFillTime}h
          </h3>
          <p className="text-gray-600 text-sm font-body">Avg Fill Time</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="w-5 h-5 text-medical-teal" />
            <div className="flex items-center text-red-500 text-xs">
              <ArrowUpRight className="w-3 h-3 mr-1" />
              +5%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            ${(facilityMetrics.totalSpend / 1000).toFixed(0)}K
          </h3>
          <p className="text-gray-600 text-sm font-body">Monthly Spend</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-5 h-5 text-medical-green" />
            <div className="flex items-center text-medical-green text-xs">
              <ArrowUpRight className="w-3 h-3 mr-1" />
              +35%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            ${(facilityMetrics.savings / 1000).toFixed(0)}K
          </h3>
          <p className="text-gray-600 text-sm font-body">Cost Savings</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <Star className="w-5 h-5 text-yellow-500" />
            <div className="flex items-center text-medical-green text-xs">
              <ArrowUpRight className="w-3 h-3 mr-1" />
              +0.2
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            {facilityMetrics.nurseRating}
          </h3>
          <p className="text-gray-600 text-sm font-body">Nurse Rating</p>
        </div>
      </div>

      {/* AI Recommendations */}
      <div className="bg-gradient-to-br from-ai-purple to-medical-blue rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Zap className="w-6 h-6 mr-3" />
            <h2 className="text-xl font-header font-bold">
              AI-Powered Recommendations
            </h2>
          </div>
          <button className="text-white/80 hover:text-white text-sm">
            View All
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          {aiRecommendations.map((rec, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur rounded-xl p-4"
            >
              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    rec.type === "cost-optimization"
                      ? "bg-green-400/20"
                      : rec.type === "quality-improvement"
                        ? "bg-yellow-400/20"
                        : "bg-blue-400/20"
                  }`}
                >
                  {rec.type === "cost-optimization" ? (
                    <DollarSign className="w-4 h-4 text-green-300" />
                  ) : rec.type === "quality-improvement" ? (
                    <Star className="w-4 h-4 text-yellow-300" />
                  ) : (
                    <TrendingUp className="w-4 h-4 text-blue-300" />
                  )}
                </div>
                <span className="text-xs bg-white/20 px-2 py-1 rounded">
                  {rec.confidence}% confidence
                </span>
              </div>
              <h3 className="font-header font-semibold mb-2 text-sm">
                {rec.title}
              </h3>
              <p className="text-blue-100 text-xs mb-3">{rec.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium">{rec.impact}</span>
                <button className="text-xs bg-white/20 hover:bg-white/30 px-2 py-1 rounded transition-colors">
                  Apply
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Department Performance */}
        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-header font-bold text-gray-900">
              Department Performance
            </h2>
            <button className="text-medical-blue hover:text-blue-700 text-sm font-medium">
              View Details
            </button>
          </div>

          <div className="space-y-4">
            {departments.map((dept, index) => (
              <div
                key={index}
                className="p-4 border border-gray-200 rounded-lg hover:border-medical-blue/30 transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-gray-900">{dept.name}</h3>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs bg-medical-green/10 text-medical-green px-2 py-1 rounded">
                      ${(dept.savings / 1000).toFixed(1)}K saved
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Fill Rate</p>
                    <p className="font-medium">
                      {((dept.filled / dept.shifts) * 100).toFixed(0)}%
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-600">Avg Rate</p>
                    <p className="font-medium">${dept.avgRate}/hr</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Fill Time</p>
                    <p className="font-medium">{dept.fillTime}h</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Shifts</p>
                    <p className="font-medium">{dept.shifts}</p>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-medical-blue h-2 rounded-full"
                      style={{ width: `${(dept.filled / dept.shifts) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cost Breakdown */}
        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-header font-bold text-gray-900">
              Cost Breakdown
            </h2>
            <button className="text-medical-blue hover:text-blue-700 text-sm font-medium">
              Optimize
            </button>
          </div>

          <div className="space-y-4">
            {costBreakdown.map((cost, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 border border-gray-200 rounded-lg"
              >
                <div className="flex items-center">
                  <div
                    className={`w-3 h-3 rounded-full mr-3 ${
                      index === 0
                        ? "bg-medical-blue"
                        : index === 1
                          ? "bg-medical-green"
                          : index === 2
                            ? "bg-ai-purple"
                            : "bg-accent-orange"
                    }`}
                  ></div>
                  <div>
                    <p className="font-medium text-gray-900 text-sm">
                      {cost.category}
                    </p>
                    <p className="text-gray-600 text-xs">
                      {cost.percentage}% of total spend
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-gray-900">
                    ${(cost.amount / 1000).toFixed(0)}K
                  </p>
                  <div
                    className={`flex items-center text-xs ${
                      cost.trend === "up"
                        ? "text-red-500"
                        : "text-medical-green"
                    }`}
                  >
                    {cost.trend === "up" ? (
                      <ArrowUpRight className="w-3 h-3 mr-1" />
                    ) : (
                      <ArrowDownRight className="w-3 h-3 mr-1" />
                    )}
                    {Math.abs(cost.change)}%
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 bg-medical-green/10 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-medical-green">
                  Total Monthly Savings
                </p>
                <p className="text-sm text-gray-600">
                  vs. traditional staffing
                </p>
              </div>
              <p className="text-2xl font-bold text-medical-green">
                ${(facilityMetrics.savings / 1000).toFixed(0)}K
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Shifts */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-header font-bold text-gray-900">
              Recent Shifts
            </h2>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <Filter className="w-4 h-4 text-gray-600" />
              </button>
              <button className="text-medical-blue hover:text-blue-700 text-sm font-medium">
                View All
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {recentShifts.map((shift, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors"
              >
                <div className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 text-white text-xs font-bold ${
                      shift.department === "ICU"
                        ? "bg-medical-blue"
                        : shift.department === "Emergency"
                          ? "bg-red-500"
                          : shift.department === "OR"
                            ? "bg-ai-purple"
                            : "bg-medical-green"
                    }`}
                  >
                    {shift.department.substring(0, 2)}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 text-sm">
                      {shift.department} • {shift.time}
                    </p>
                    <p className="text-gray-600 text-xs">
                      {shift.nurse} • {shift.date}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="font-medium text-gray-900">
                    ${shift.rate}/hr
                  </span>
                  <div
                    className={`px-2 py-1 rounded-full text-xs ${
                      shift.status === "confirmed"
                        ? "bg-medical-green/10 text-medical-green"
                        : shift.status === "filled"
                          ? "bg-medical-blue/10 text-medical-blue"
                          : shift.status === "pending"
                            ? "bg-yellow-100 text-yellow-700"
                            : "bg-red-100 text-red-700"
                    }`}
                  >
                    {shift.status}
                  </div>
                  <button className="p-1 hover:bg-gray-100 rounded">
                    <MoreHorizontal className="w-4 h-4 text-gray-600" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Nurses */}
        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-header font-bold text-gray-900">
              Top Performers
            </h2>
            <button className="text-medical-blue hover:text-blue-700 text-sm font-medium">
              View All
            </button>
          </div>

          <div className="space-y-4">
            {topNurses.map((nurse, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-full flex items-center justify-center mr-3 text-white font-bold text-sm">
                    {nurse.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 text-sm">
                      {nurse.name}
                    </p>
                    <div className="flex items-center text-xs text-gray-600">
                      <Star className="w-3 h-3 text-yellow-500 mr-1" />
                      {nurse.rating} • {nurse.shifts} shifts • {nurse.specialty}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <button className="text-medical-blue hover:text-blue-700 text-xs">
                    Book Again
                  </button>
                  <p className="text-gray-500 text-xs mt-1">
                    {nurse.lastShift}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
        <h2 className="text-xl font-header font-bold text-gray-900 mb-6">
          Quick Actions
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <button
            onClick={() => navigate('/dashboard/post-shift')}
            className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group"
          >
            <Plus className="w-8 h-8 text-medical-blue group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">
              Post Shift
            </span>
          </button>
          <button
            onClick={() => navigate('/dashboard/applicants')}
            className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group"
          >
            <Users className="w-8 h-8 text-medical-green group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">
              View Applicants
            </span>
          </button>
          <button
            onClick={() => navigate('/dashboard/timesheet-approval')}
            className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group"
          >
            <Clock className="w-8 h-8 text-medical-blue group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">
              Approve Timesheets
            </span>
          </button>
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <BarChart3 className="w-8 h-8 text-ai-purple group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">Analytics</span>
          </button>
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <MessageSquare className="w-8 h-8 text-medical-teal group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">Messages</span>
          </button>
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <Download className="w-8 h-8 text-accent-orange group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">Reports</span>
          </button>
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <Settings className="w-8 h-8 text-gray-600 group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
}
