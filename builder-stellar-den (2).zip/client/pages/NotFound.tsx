import React from "react";
import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import {
  Brain,
  Home,
  Search,
  ArrowLeft,
  MessageSquare,
  HelpCircle,
  AlertTriangle,
  Compass,
  BookOpen,
  Settings,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  const popularPages = [
    {
      path: "/",
      icon: Home,
      label: "Home",
      description: "Return to our homepage",
    },
    {
      path: "/dashboard",
      icon: Settings,
      label: "Dashboard",
      description: "Access your dashboard",
    },
    {
      path: "/login",
      icon: ArrowLeft,
      label: "Sign In",
      description: "Sign into your account",
    },
    {
      path: "/register",
      icon: BookOpen,
      label: "Register",
      description: "Create a new account",
    },
    {
      path: "/about",
      icon: HelpCircle,
      label: "About Us",
      description: "Learn more about ProLinkAi",
    },
    {
      path: "/help",
      icon: MessageSquare,
      label: "Help Center",
      description: "Get support and answers",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-medical-gray via-white to-ai-light">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            {/* Navigation Links */}
            <div className="hidden md:flex items-center space-x-8">
              <Link
                to="/"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Home
              </Link>
              <Link
                to="/about"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                About
              </Link>
              <Link
                to="/login"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-6 py-2 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium shadow-card hover:shadow-card-hover"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* 404 Content */}
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] px-4 py-12">
        <div className="text-center max-w-4xl w-full">
          {/* Error Icon and Message */}
          <div className="mb-8">
            <div className="w-24 h-24 bg-gradient-to-br from-medical-blue to-ai-purple rounded-3xl flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-12 h-12 text-white" />
            </div>

            <h1 className="text-6xl md:text-8xl font-header font-bold text-gray-900 mb-4">
              404
            </h1>

            <h2 className="text-2xl md:text-3xl font-header font-bold text-gray-900 mb-4">
              Oops! Page Not Found
            </h2>

            <p className="text-lg text-gray-600 font-body mb-2">
              The page you're looking for doesn't exist or has been moved.
            </p>
            <p className="text-sm text-gray-500 font-body mb-8">
              Attempted to access:{" "}
              <code className="bg-gray-100 px-2 py-1 rounded text-red-600">
                {location.pathname}
              </code>
            </p>
          </div>

          {/* Primary Actions */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link to="/">
              <Button className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-blue-700 hover:to-purple-600 text-white px-8 py-3 text-lg font-semibold w-full sm:w-auto">
                <Home className="w-5 h-5 mr-2" />
                Go Home
              </Button>
            </Link>

            <Link to="/dashboard">
              <Button
                variant="outline"
                className="px-8 py-3 text-lg font-semibold w-full sm:w-auto"
              >
                <Settings className="w-5 h-5 mr-2" />
                Dashboard
              </Button>
            </Link>

            <Button
              variant="ghost"
              onClick={() => window.history.back()}
              className="px-8 py-3 text-lg font-semibold w-full sm:w-auto"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Go Back
            </Button>
          </div>

          {/* Popular Pages */}
          <div className="mb-12">
            <h3 className="text-xl font-header font-semibold text-gray-900 mb-6 flex items-center justify-center gap-2">
              <Compass className="w-5 h-5" />
              Popular Pages
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
              {popularPages.map((page) => {
                const Icon = page.icon;
                return (
                  <Link key={page.path} to={page.path}>
                    <Card className="hover:shadow-lg transition-all duration-200 hover:border-medical-blue group">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-10 h-10 bg-gradient-to-br from-medical-blue/10 to-ai-purple/10 rounded-lg flex items-center justify-center group-hover:from-medical-blue/20 group-hover:to-ai-purple/20 transition-colors">
                            <Icon className="w-5 h-5 text-medical-blue" />
                          </div>
                          <div className="text-left">
                            <h4 className="font-semibold text-gray-900 group-hover:text-medical-blue transition-colors">
                              {page.label}
                            </h4>
                            <p className="text-sm text-gray-600">
                              {page.description}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Search Suggestion */}
          <div className="bg-white rounded-2xl p-8 shadow-card border border-gray-200 max-w-2xl mx-auto">
            <h3 className="text-lg font-header font-semibold text-gray-900 mb-4 flex items-center justify-center gap-2">
              <Search className="w-5 h-5" />
              Looking for Something Specific?
            </h3>
            <p className="text-gray-600 mb-4">
              If you were looking for a specific page or feature, try these
              options:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              <div className="text-left space-y-2">
                <p className="font-medium text-gray-900">For Nurses:</p>
                <ul className="space-y-1 text-gray-600">
                  <li>
                    •{" "}
                    <Link
                      to="/register/nurse"
                      className="text-medical-blue hover:underline"
                    >
                      Join as Nurse
                    </Link>
                  </li>
                  <li>
                    •{" "}
                    <Link
                      to="/dashboard/shifts"
                      className="text-medical-blue hover:underline"
                    >
                      Find Shifts
                    </Link>
                  </li>
                  <li>
                    •{" "}
                    <Link
                      to="/nurses"
                      className="text-medical-blue hover:underline"
                    >
                      Nurse Info
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="text-left space-y-2">
                <p className="font-medium text-gray-900">For Facilities:</p>
                <ul className="space-y-1 text-gray-600">
                  <li>
                    •{" "}
                    <Link
                      to="/register/facility"
                      className="text-medical-blue hover:underline"
                    >
                      Join as Facility
                    </Link>
                  </li>
                  <li>
                    •{" "}
                    <Link
                      to="/dashboard/post-shift"
                      className="text-medical-blue hover:underline"
                    >
                      Post Shifts
                    </Link>
                  </li>
                  <li>
                    •{" "}
                    <Link
                      to="/facilities"
                      className="text-medical-blue hover:underline"
                    >
                      Facility Info
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Contact Support */}
          <div className="mt-12">
            <p className="text-gray-600 mb-4">
              Still can't find what you're looking for?
            </p>
            <Link to="/help">
              <Button variant="outline" className="px-6 py-2">
                <MessageSquare className="w-4 h-4 mr-2" />
                Contact Support
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
