import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Brain,
  ArrowLeft,
  Building2,
  Users,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Clock,
  CheckCircle2,
  Zap,
  BarChart3,
  Shield,
  DollarSign,
  Award,
  TrendingUp,
  User,
  Briefcase,
} from "lucide-react";

interface DemoFormData {
  // Organization Info
  organizationName: string;
  organizationType: string;
  bedCount: string;
  currentChallenges: string[];
  
  // Contact Info
  firstName: string;
  lastName: string;
  title: string;
  email: string;
  phone: string;
  
  // Demo Preferences
  preferredDate: string;
  preferredTime: string;
  demoType: string;
  specificInterests: string[];
  additionalQuestions: string;
  
  // Consent
  agreedToContact: boolean;
  newsletterOptIn: boolean;
}

export default function Demo() {
  const [formData, setFormData] = useState<DemoFormData>({
    organizationName: "",
    organizationType: "",
    bedCount: "",
    currentChallenges: [],
    firstName: "",
    lastName: "",
    title: "",
    email: "",
    phone: "",
    preferredDate: "",
    preferredTime: "",
    demoType: "live",
    specificInterests: [],
    additionalQuestions: "",
    agreedToContact: false,
    newsletterOptIn: false,
  });

  const organizationTypes = [
    "Acute Care Hospital",
    "Critical Access Hospital",
    "Specialty Hospital",
    "Rehabilitation Hospital",
    "Long-term Care Facility",
    "Skilled Nursing Facility",
    "Assisted Living",
    "Outpatient Surgery Center",
    "Clinic/Medical Group",
    "Home Health Agency",
    "Health System",
    "Staffing Agency",
    "Other",
  ];

  const bedCountOptions = [
    "Under 25 beds",
    "25-50 beds",
    "51-100 beds",
    "101-200 beds",
    "201-400 beds",
    "400+ beds",
    "Not applicable",
  ];

  const challengeOptions = [
    "High nursing turnover",
    "Difficulty filling shifts quickly",
    "High overtime costs",
    "Complex scheduling",
    "Compliance tracking",
    "Quality consistency",
    "Administrative burden",
    "Staff communication",
    "Cost management",
    "Credentialing delays",
  ];

  const interestOptions = [
    "AI-powered matching",
    "Predictive analytics",
    "Cost optimization",
    "Real-time dashboard",
    "Mobile app features",
    "Integration capabilities",
    "Compliance tools",
    "Reporting & analytics",
    "Staff communication",
    "Quality assurance",
  ];

  const timeSlots = [
    "9:00 AM - 10:00 AM",
    "10:00 AM - 11:00 AM",
    "11:00 AM - 12:00 PM",
    "1:00 PM - 2:00 PM",
    "2:00 PM - 3:00 PM",
    "3:00 PM - 4:00 PM",
    "4:00 PM - 5:00 PM",
  ];

  const handleInputChange = (field: keyof DemoFormData, value: string | boolean | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayToggle = (field: "currentChallenges" | "specificInterests", item: string) => {
    const currentArray = formData[field];
    const updatedArray = currentArray.includes(item)
      ? currentArray.filter(i => i !== item)
      : [...currentArray, item];
    handleInputChange(field, updatedArray);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Demo request submitted:", formData);
    // Handle demo request submission
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-medical-gray via-white to-blue-50">
      {/* Header */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            <Link
              to="/"
              className="text-gray-600 hover:text-medical-blue transition-colors font-body"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back button */}
        <Link
          to="/"
          className="inline-flex items-center text-medical-blue hover:text-blue-700 font-medium mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto mb-6">
            <BarChart3 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
            Request Your Custom Demo
          </h1>
          <p className="text-xl text-gray-600 font-body max-w-2xl mx-auto">
            See how ProLinkAi can transform your healthcare staffing operations with AI-powered solutions tailored to your facility's needs.
          </p>
        </div>

        {/* Benefits Preview */}
        <div className="bg-gradient-to-br from-medical-blue via-ai-purple to-medical-teal rounded-2xl p-8 text-white mb-12">
          <h2 className="text-2xl font-header font-bold mb-6 text-center">
            What You'll See in Your Demo
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center mx-auto mb-3">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">AI Matching Engine</h3>
              <p className="text-sm text-blue-100">See intelligent nurse-facility matching in action</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center mx-auto mb-3">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Real-time Analytics</h3>
              <p className="text-sm text-blue-100">Live dashboard with predictive insights</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center mx-auto mb-3">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Cost Optimization</h3>
              <p className="text-sm text-blue-100">ROI calculator with your facility data</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center mx-auto mb-3">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Compliance Tools</h3>
              <p className="text-sm text-blue-100">Automated credentialing and tracking</p>
            </div>
          </div>
        </div>

        {/* Demo Request Form */}
        <div className="bg-white rounded-2xl shadow-card border border-gray-200 p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Organization Information */}
            <div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-6 flex items-center">
                <Building2 className="w-5 h-5 mr-2" />
                Organization Information
              </h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Organization Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.organizationName}
                    onChange={(e) => handleInputChange("organizationName", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                    placeholder="Enter your organization name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Organization Type *
                  </label>
                  <select
                    required
                    value={formData.organizationType}
                    onChange={(e) => handleInputChange("organizationType", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                  >
                    <option value="">Select organization type</option>
                    {organizationTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Facility Size
                </label>
                <select
                  value={formData.bedCount}
                  onChange={(e) => handleInputChange("bedCount", e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                >
                  <option value="">Select facility size</option>
                  {bedCountOptions.map((count) => (
                    <option key={count} value={count}>
                      {count}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-4">
                  Current Staffing Challenges (Select all that apply)
                </label>
                <div className="grid md:grid-cols-2 gap-3">
                  {challengeOptions.map((challenge) => (
                    <label
                      key={challenge}
                      className={`flex items-center p-3 rounded-lg border cursor-pointer transition-colors ${
                        formData.currentChallenges.includes(challenge)
                          ? "border-medical-blue bg-medical-blue/5"
                          : "border-gray-300 hover:border-gray-400"
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={formData.currentChallenges.includes(challenge)}
                        onChange={() => handleArrayToggle("currentChallenges", challenge)}
                        className="w-4 h-4 text-medical-blue border-gray-300 rounded focus:ring-medical-blue"
                      />
                      <span className="ml-3 text-sm font-body">{challenge}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-6 flex items-center">
                <User className="w-5 h-5 mr-2" />
                Contact Information
              </h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    First Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => handleInputChange("firstName", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                    placeholder="Enter your first name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Last Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => handleInputChange("lastName", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                    placeholder="Enter your last name"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mt-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Job Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => handleInputChange("title", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                    placeholder="e.g., Chief Nursing Officer, HR Director"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                      placeholder="Enter your email"
                    />
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number *
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                    placeholder="(555) 123-4567"
                  />
                </div>
              </div>
            </div>

            {/* Demo Preferences */}
            <div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-6 flex items-center">
                <Calendar className="w-5 h-5 mr-2" />
                Demo Preferences
              </h3>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Preferred Date
                  </label>
                  <input
                    type="date"
                    value={formData.preferredDate}
                    onChange={(e) => handleInputChange("preferredDate", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Preferred Time (EST)
                  </label>
                  <select
                    value={formData.preferredTime}
                    onChange={(e) => handleInputChange("preferredTime", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                  >
                    <option value="">Select preferred time</option>
                    {timeSlots.map((time) => (
                      <option key={time} value={time}>
                        {time}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Demo Type *
                </label>
                <div className="grid md:grid-cols-2 gap-4">
                  <label className={`flex items-center p-4 rounded-lg border cursor-pointer transition-colors ${
                    formData.demoType === "live" ? "border-medical-blue bg-medical-blue/5" : "border-gray-300"
                  }`}>
                    <input
                      type="radio"
                      name="demoType"
                      value="live"
                      checked={formData.demoType === "live"}
                      onChange={(e) => handleInputChange("demoType", e.target.value)}
                      className="w-4 h-4 text-medical-blue border-gray-300 focus:ring-medical-blue"
                    />
                    <div className="ml-3">
                      <div className="font-medium">Live Demo</div>
                      <div className="text-sm text-gray-600">30-minute personalized presentation</div>
                    </div>
                  </label>
                  
                  <label className={`flex items-center p-4 rounded-lg border cursor-pointer transition-colors ${
                    formData.demoType === "self-guided" ? "border-medical-blue bg-medical-blue/5" : "border-gray-300"
                  }`}>
                    <input
                      type="radio"
                      name="demoType"
                      value="self-guided"
                      checked={formData.demoType === "self-guided"}
                      onChange={(e) => handleInputChange("demoType", e.target.value)}
                      className="w-4 h-4 text-medical-blue border-gray-300 focus:ring-medical-blue"
                    />
                    <div className="ml-3">
                      <div className="font-medium">Self-Guided Tour</div>
                      <div className="text-sm text-gray-600">Interactive demo at your pace</div>
                    </div>
                  </label>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-4">
                  Specific Areas of Interest (Optional)
                </label>
                <div className="grid md:grid-cols-2 gap-3">
                  {interestOptions.map((interest) => (
                    <label
                      key={interest}
                      className={`flex items-center p-3 rounded-lg border cursor-pointer transition-colors ${
                        formData.specificInterests.includes(interest)
                          ? "border-medical-blue bg-medical-blue/5"
                          : "border-gray-300 hover:border-gray-400"
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={formData.specificInterests.includes(interest)}
                        onChange={() => handleArrayToggle("specificInterests", interest)}
                        className="w-4 h-4 text-medical-blue border-gray-300 rounded focus:ring-medical-blue"
                      />
                      <span className="ml-3 text-sm font-body">{interest}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Additional Questions or Comments
                </label>
                <textarea
                  value={formData.additionalQuestions}
                  onChange={(e) => handleInputChange("additionalQuestions", e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent font-body"
                  placeholder="Tell us about your specific needs or any questions you have..."
                />
              </div>
            </div>

            {/* Consent */}
            <div className="space-y-4">
              <label className="flex items-start">
                <input
                  type="checkbox"
                  required
                  checked={formData.agreedToContact}
                  onChange={(e) => handleInputChange("agreedToContact", e.target.checked)}
                  className="w-4 h-4 text-medical-blue border-gray-300 rounded focus:ring-medical-blue mt-1"
                />
                <span className="ml-3 text-sm text-gray-600 font-body">
                  I agree to be contacted by ProLinkAi representatives regarding this demo request. *
                </span>
              </label>

              <label className="flex items-start">
                <input
                  type="checkbox"
                  checked={formData.newsletterOptIn}
                  onChange={(e) => handleInputChange("newsletterOptIn", e.target.checked)}
                  className="w-4 h-4 text-medical-blue border-gray-300 rounded focus:ring-medical-blue mt-1"
                />
                <span className="ml-3 text-sm text-gray-600 font-body">
                  Send me updates about ProLinkAi features and healthcare industry insights.
                </span>
              </label>
            </div>

            {/* Submit Button */}
            <div className="pt-6 border-t border-gray-200">
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-medical-blue to-ai-purple text-white py-4 px-6 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 flex items-center justify-center"
              >
                <Calendar className="w-5 h-5 mr-2" />
                Schedule My Demo
              </button>
            </div>
          </form>
        </div>

        {/* Contact Alternative */}
        <div className="mt-8 text-center">
          <p className="text-gray-600 mb-4">
            Prefer to speak with someone directly?
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:+1-555-123-4567"
              className="inline-flex items-center px-6 py-3 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              <Phone className="w-4 h-4 mr-2" />
              Call: (555) 123-4567
            </a>
            <a
              href="mailto:demo@prolinkAi.com"
              className="inline-flex items-center px-6 py-3 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              <Mail className="w-4 h-4 mr-2" />
              Email: demo@prolinkAi.com
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
