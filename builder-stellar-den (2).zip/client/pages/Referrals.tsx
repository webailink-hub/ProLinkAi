import React, { useState } from 'react';
import { Users, DollarSign, Gift, Share2, Copy, Mail, MessageCircle, Star, Trophy, Brain, CheckCircle, Clock, TrendingUp, Target } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Progress } from '../components/ui/progress';

interface Referral {
  id: string;
  name: string;
  email: string;
  status: 'pending' | 'signed_up' | 'verified' | 'first_shift' | 'completed';
  dateReferred: string;
  earnedAmount: number;
  avatar?: string;
}

interface ReferralTier {
  level: number;
  name: string;
  requiredReferrals: number;
  bonusMultiplier: number;
  perks: string[];
  color: string;
}

export default function Referrals() {
  const [referralCode, setReferralCode] = useState('SARAH-NURSE-2024');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('Join me on ProLinkAi - the smartest way to find nursing shifts! Use my code for a $50 bonus.');
  const [copiedCode, setCopiedCode] = useState(false);

  const [referrals, setReferrals] = useState<Referral[]>([
    {
      id: '1',
      name: 'Emily Chen',
      email: 'emily.chen@email.com',
      status: 'completed',
      dateReferred: '2024-01-15',
      earnedAmount: 150,
      avatar: '/api/placeholder/40/40'
    },
    {
      id: '2',
      name: 'Marcus Johnson',
      email: 'marcus.j@email.com',
      status: 'first_shift',
      dateReferred: '2024-01-20',
      earnedAmount: 75,
      avatar: '/api/placeholder/40/40'
    },
    {
      id: '3',
      name: 'Lisa Rodriguez',
      email: 'lisa.rodriguez@email.com',
      status: 'verified',
      dateReferred: '2024-01-25',
      earnedAmount: 50,
      avatar: '/api/placeholder/40/40'
    },
    {
      id: '4',
      name: 'David Kim',
      email: 'david.kim@email.com',
      status: 'signed_up',
      dateReferred: '2024-01-28',
      earnedAmount: 25,
      avatar: '/api/placeholder/40/40'
    },
    {
      id: '5',
      name: 'Jennifer Wilson',
      email: 'jen.wilson@email.com',
      status: 'pending',
      dateReferred: '2024-02-01',
      earnedAmount: 0
    }
  ]);

  const referralTiers: ReferralTier[] = [
    {
      level: 1,
      name: 'Advocate',
      requiredReferrals: 0,
      bonusMultiplier: 1.0,
      perks: ['$50 per successful referral', 'Basic referral tracking'],
      color: 'from-gray-400 to-gray-600'
    },
    {
      level: 2,
      name: 'Ambassador',
      requiredReferrals: 5,
      bonusMultiplier: 1.2,
      perks: ['$60 per successful referral', 'Priority shift notifications', 'Monthly bonus eligibility'],
      color: 'from-medical-blue to-medical-teal'
    },
    {
      level: 3,
      name: 'Champion',
      requiredReferrals: 15,
      bonusMultiplier: 1.5,
      perks: ['$75 per successful referral', 'AI-powered referral matching', 'Quarterly bonus rewards'],
      color: 'from-ai-purple to-medical-green'
    },
    {
      level: 4,
      name: 'Legend',
      requiredReferrals: 30,
      bonusMultiplier: 2.0,
      perks: ['$100 per successful referral', 'VIP support channel', 'Annual leadership retreat'],
      color: 'from-yellow-400 to-orange-500'
    }
  ];

  const currentCompletedReferrals = referrals.filter(r => r.status === 'completed').length;
  const currentTier = referralTiers.reduce((tier, current) => 
    currentCompletedReferrals >= current.requiredReferrals ? current : tier
  , referralTiers[0]);
  
  const nextTier = referralTiers.find(tier => tier.requiredReferrals > currentCompletedReferrals);
  const progressToNext = nextTier ? (currentCompletedReferrals / nextTier.requiredReferrals) * 100 : 100;

  const totalEarnings = referrals.reduce((sum, ref) => sum + ref.earnedAmount, 0);
  const pendingEarnings = referrals.filter(r => r.status === 'first_shift').reduce((sum, ref) => sum + (100 - ref.earnedAmount), 0);

  const copyReferralCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const sendReferral = () => {
    if (!email) return;
    // In a real app, this would send the referral email
    console.log('Sending referral to:', email);
    setEmail('');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'first_shift': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'verified': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'signed_up': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'pending': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Completed';
      case 'first_shift': return 'Working First Shift';
      case 'verified': return 'Verified';
      case 'signed_up': return 'Signed Up';
      case 'pending': return 'Pending';
      default: return 'Unknown';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'first_shift': return <Clock className="w-4 h-4" />;
      case 'verified': return <Star className="w-4 h-4" />;
      case 'signed_up': return <Users className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent mb-2">
          Referral Program
        </h1>
        <p className="text-gray-600">
          Earn rewards by referring qualified nurses to ProLinkAi with AI-optimized matching
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">${totalEarnings}</div>
            <div className="text-sm text-gray-600">Total Earned</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">${pendingEarnings}</div>
            <div className="text-sm text-gray-600">Pending Rewards</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-medical-blue">{referrals.length}</div>
            <div className="text-sm text-gray-600">Total Referrals</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-ai-purple">{currentCompletedReferrals}</div>
            <div className="text-sm text-gray-600">Successful</div>
          </CardContent>
        </Card>
      </div>

      {/* Current Tier Status */}
      <Card className="border-l-4 border-l-medical-blue">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Current Tier: {currentTier.name}</h3>
              <p className="text-gray-600">Earning ${(50 * currentTier.bonusMultiplier).toFixed(0)} per successful referral</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-medical-blue">{currentCompletedReferrals}</div>
              <div className="text-sm text-gray-600">Completed Referrals</div>
            </div>
          </div>

          {nextTier && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress to {nextTier.name}</span>
                <span>{currentCompletedReferrals} / {nextTier.requiredReferrals}</span>
              </div>
              <Progress value={progressToNext} className="h-2" />
              <p className="text-xs text-gray-500">
                {nextTier.requiredReferrals - currentCompletedReferrals} more referrals needed for next tier
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Referral Tools */}
        <div className="lg:col-span-2 space-y-6">
          {/* AI-Powered Referral Matching */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-ai-purple" />
                AI-Powered Referral Matching
                <Badge className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 text-ai-purple border-ai-purple/20">
                  Enhanced
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 rounded-lg p-4 border border-ai-purple/20">
                <div className="flex items-center gap-2 mb-3">
                  <Brain className="w-4 h-4 text-ai-purple" />
                  <span className="font-semibold text-ai-purple">Smart Referral Insights</span>
                </div>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center justify-between">
                    <span>• High-potential nurses in your network</span>
                    <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">23 identified</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>• Optimal referral timing</span>
                    <Badge className="bg-blue-100 text-blue-800 border-blue-200 text-xs">This week</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>• Success probability</span>
                    <Badge className="bg-ai-purple/10 text-ai-purple border-ai-purple/20 text-xs">87%</Badge>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Your Referral Code</h4>
                <div className="flex items-center gap-2">
                  <Input
                    value={referralCode}
                    readOnly
                    className="flex-1 font-mono"
                  />
                  <Button 
                    onClick={copyReferralCode}
                    variant="outline"
                    className="whitespace-nowrap"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    {copiedCode ? 'Copied!' : 'Copy'}
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Your referrals get $50 bonus, you earn ${(50 * currentTier.bonusMultiplier).toFixed(0)} when they complete their first shift
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Send Referral */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Share2 className="w-5 h-5" />
                Send a Referral
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                <Input
                  type="email"
                  placeholder="colleague@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Personal Message</label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Add a personal touch to your invitation..."
                />
              </div>

              <div className="flex gap-2">
                <Button 
                  onClick={sendReferral}
                  className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Send Invitation
                </Button>
                <Button variant="outline">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Share via SMS
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Referral History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Your Referrals
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {referrals.map((referral) => (
                  <div key={referral.id} className="flex items-center gap-4 p-4 border rounded-lg hover:shadow-sm transition-shadow">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={referral.avatar} />
                      <AvatarFallback className="bg-gradient-to-br from-medical-blue to-ai-purple text-white text-sm">
                        {referral.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900">{referral.name}</h4>
                      <p className="text-sm text-gray-600">{referral.email}</p>
                      <p className="text-xs text-gray-500">Referred on {new Date(referral.dateReferred).toLocaleDateString()}</p>
                    </div>

                    <div className="text-center">
                      <div className="text-lg font-bold text-green-600">${referral.earnedAmount}</div>
                      <div className="text-xs text-gray-500">Earned</div>
                    </div>

                    <Badge className={getStatusColor(referral.status)}>
                      <div className="flex items-center gap-1">
                        {getStatusIcon(referral.status)}
                        {getStatusText(referral.status)}
                      </div>
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Referral Tiers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                Referral Tiers
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {referralTiers.map((tier) => {
                const isCurrentTier = tier.level === currentTier.level;
                const isAchieved = currentCompletedReferrals >= tier.requiredReferrals;
                
                return (
                  <div
                    key={tier.level}
                    className={`p-4 rounded-lg border transition-all ${
                      isCurrentTier 
                        ? 'border-medical-blue bg-medical-blue/5 ring-2 ring-medical-blue/20' 
                        : isAchieved 
                          ? 'border-green-200 bg-green-50' 
                          : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold">{tier.name}</h4>
                      {isCurrentTier && (
                        <Badge className="bg-medical-blue text-white">Current</Badge>
                      )}
                      {isAchieved && !isCurrentTier && (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      )}
                    </div>
                    
                    <div className="text-sm text-gray-600 mb-2">
                      {tier.requiredReferrals === 0 ? 'Starting tier' : `${tier.requiredReferrals} successful referrals`}
                    </div>
                    
                    <div className="text-sm font-medium text-green-600 mb-2">
                      ${(50 * tier.bonusMultiplier).toFixed(0)} per referral
                    </div>
                    
                    <ul className="text-xs text-gray-600 space-y-1">
                      {tier.perks.map((perk, index) => (
                        <li key={index}>• {perk}</li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Quick Tips */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Referral Tips
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <h5 className="font-medium text-blue-900 text-sm mb-1">Best Time to Refer</h5>
                <p className="text-xs text-blue-700">After completing a great shift - share your positive experience!</p>
              </div>
              
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <h5 className="font-medium text-green-900 text-sm mb-1">Target Audience</h5>
                <p className="text-xs text-green-700">Experienced nurses looking for flexibility and better pay rates.</p>
              </div>
              
              <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                <h5 className="font-medium text-purple-900 text-sm mb-1">AI Optimization</h5>
                <p className="text-xs text-purple-700">Our AI identifies the best candidates from your network patterns.</p>
              </div>
            </CardContent>
          </Card>

          {/* Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Monthly Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-2 rounded-lg bg-yellow-50 border border-yellow-200">
                  <div className="w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center text-white text-xs font-bold">1</div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">Jennifer Adams</div>
                    <div className="text-xs text-gray-600">12 referrals</div>
                  </div>
                  <Trophy className="w-4 h-4 text-yellow-500" />
                </div>
                
                <div className="flex items-center gap-3 p-2 rounded-lg bg-gray-50">
                  <div className="w-6 h-6 bg-gray-400 rounded-full flex items-center justify-center text-white text-xs font-bold">2</div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">Michael Chen</div>
                    <div className="text-xs text-gray-600">8 referrals</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 p-2 rounded-lg bg-orange-50 border border-orange-200">
                  <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center text-white text-xs font-bold">3</div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">You</div>
                    <div className="text-xs text-gray-600">{currentCompletedReferrals} referrals</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
