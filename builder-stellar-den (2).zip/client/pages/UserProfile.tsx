import { useState } from "react";
import { Link } from "react-router-dom";
import {
  User,
  MapPin,
  Mail,
  Phone,
  Globe,
  Calendar,
  FileText,
  Award,
  Shield,
  Star,
  Clock,
  Building2,
  CheckCircle2,
  AlertCircle,
  Download,
  Eye,
  Edit3,
  MessageSquare,
  ThumbsUp,
  ExternalLink,
  Camera,
  Users,
  TrendingUp,
  DollarSign,
  Upload,
} from "lucide-react";

// Mock data - in real app this would come from API/props
const mockNurseProfile = {
  type: "nurse",
  avatarUrl:
    "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&h=150&fit=crop&crop=face",
  name: "Kaitlyn Nguyen",
  isVerified: true,
  licenseType: "Registered Nurse (RN)",
  specialties: ["Emergency Room (ER)", "ICU", "Trauma"],
  certifications: ["BLS", "ACLS", "PALS", "TNCC"],
  email: "kaitlyn.nguyen@email.com",
  phoneNumber: "555-123-4567",
  location: "San Francisco, CA",
  memberSince: "January 15, 2022",
  rating: 4.9,
  totalShifts: 156,
  availability: [
    { date: "2024-01-15", available: true },
    { date: "2024-01-16", available: false },
    { date: "2024-01-17", available: true },
    // ... more dates
  ],
  documents: [
    {
      type: "State Nursing License",
      status: "Verified",
      expiryDate: "2025-06-30",
    },
    { type: "BLS Certification", status: "Verified", expiryDate: "2024-12-15" },
    {
      type: "ACLS Certification",
      status: "Verified",
      expiryDate: "2024-11-20",
    },
    { type: "Background Check", status: "Pending", expiryDate: null },
  ],
  recentShifts: [
    {
      facilityName: "UCSF Medical Center",
      position: "ICU",
      date: "Jan 12, 2024",
      hours: 12,
      pay: 720,
    },
    {
      facilityName: "Stanford Hospital",
      position: "ER",
      date: "Jan 10, 2024",
      hours: 8,
      pay: 480,
    },
    {
      facilityName: "Kaiser Permanente",
      position: "ICU",
      date: "Jan 8, 2024",
      hours: 12,
      pay: 700,
    },
  ],
  reviews: [
    {
      facilityName: "UCSF Medical Center",
      rating: 5,
      comment:
        "Exceptional nurse with great bedside manner. Highly recommended!",
      date: "Jan 13, 2024",
    },
    {
      facilityName: "Stanford Hospital",
      rating: 5,
      comment:
        "Professional, skilled, and reliable. Would definitely hire again.",
      date: "Jan 11, 2024",
    },
  ],
};

const mockFacilityProfile = {
  type: "facility",
  avatarUrl:
    "https://images.unsplash.com/photo-1632833239869-a37e3a5806d2?w=150&h=150&fit=crop",
  name: "Memorial Hospital",
  city: "Downtown",
  state: "Medville, CA",
  rating: 4.8,
  legalName: "Medville Health Systems, Inc.",
  fullAddress: "123 Health St, Downtown, Medville, CA 90210",
  phoneNumber: "555-987-6543",
  website: "https://memorialhospital.com",
  contactPerson: "John Smith",
  healthSystem: "Medville Health",
  memberSince: "January 15, 2023",
  facilityType: "Acute Care Hospital",
  bedCount: 450,
  totalShifts: 892,
  fillRate: 94,
  avgResponseTime: "2.3 hours",
  openShifts: [
    {
      position: "ICU Nurse",
      department: "ICU",
      date: "Jan 15, 2024",
      time: "7:00 AM - 7:00 PM",
      pay: 55,
      urgent: true,
    },
    {
      position: "ER Nurse",
      department: "Emergency",
      date: "Jan 16, 2024",
      time: "3:00 PM - 11:00 PM",
      pay: 52,
      urgent: false,
    },
    {
      position: "Med-Surg Nurse",
      department: "Medical-Surgical",
      date: "Jan 17, 2024",
      time: "11:00 PM - 7:00 AM",
      pay: 48,
      urgent: false,
    },
  ],
  reviews: [
    {
      nurseName: "Sarah Johnson",
      rating: 5,
      comment:
        "Great facility to work at. Staff is supportive and management is professional.",
      date: "Jan 12, 2024",
    },
    {
      nurseName: "Michael Chen",
      rating: 4,
      comment:
        "Well-organized facility with good resources. Positive work environment.",
      date: "Jan 10, 2024",
    },
  ],
};

export default function UserProfile() {
  const [activeTab, setActiveTab] = useState("overview");
  const [profileType, setProfileType] = useState<"nurse" | "facility">("nurse");

  // In real app, this would be determined by URL params or user data
  const profile =
    profileType === "nurse" ? mockNurseProfile : mockFacilityProfile;

  const isNurse = profile.type === "nurse";

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      Verified: {
        bg: "bg-green-100",
        text: "text-green-800",
        icon: CheckCircle2,
      },
      Pending: { bg: "bg-yellow-100", text: "text-yellow-800", icon: Clock },
      Expired: { bg: "bg-red-100", text: "text-red-800", icon: AlertCircle },
    };

    const config = statusConfig[status as keyof typeof statusConfig];
    const IconComponent = config?.icon || AlertCircle;

    return (
      <span
        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config?.bg} ${config?.text}`}
      >
        <IconComponent className="w-3 h-3 mr-1" />
        {status}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Profile Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center space-x-6">
              {/* Avatar */}
              <div className="relative">
                <img
                  className="w-24 h-24 rounded-2xl object-cover border-4 border-white shadow-lg"
                  src={profile.avatarUrl}
                  alt={profile.name}
                />
                <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-medical-blue text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors">
                  <Camera className="w-4 h-4" />
                </button>
              </div>

              {/* Basic Info */}
              <div>
                <div className="flex items-center space-x-3 mb-2">
                  <h1 className="text-3xl font-header font-bold text-gray-900">
                    {profile.name}
                  </h1>
                  {isNurse && mockNurseProfile.isVerified && (
                    <div className="flex items-center bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                      <Shield className="w-4 h-4 mr-1" />
                      Verified
                    </div>
                  )}
                </div>

                <p className="text-lg text-gray-600 mb-2">
                  {isNurse
                    ? mockNurseProfile.licenseType
                    : mockFacilityProfile.facilityType}
                </p>

                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-1" />
                    {isNurse
                      ? mockNurseProfile.location
                      : `${mockFacilityProfile.city}, ${mockFacilityProfile.state}`}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    Member since {profile.memberSince}
                  </div>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 mr-1 text-yellow-500" />
                    {profile.rating} rating
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-6 lg:mt-0 flex flex-col sm:flex-row gap-3">
              <button className="bg-medical-blue text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center">
                <MessageSquare className="w-4 h-4 mr-2" />
                Message
              </button>
              <button className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center">
                <Edit3 className="w-4 h-4 mr-2" />
                Edit Profile
              </button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-gray-900">
                {isNurse
                  ? mockNurseProfile.totalShifts
                  : mockFacilityProfile.totalShifts}
              </div>
              <div className="text-sm text-gray-600">Total Shifts</div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {profile.rating}
              </div>
              <div className="text-sm text-gray-600">Average Rating</div>
            </div>

            {isNurse ? (
              <>
                <div className="bg-gray-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {mockNurseProfile.specialties.length}
                  </div>
                  <div className="text-sm text-gray-600">Specialties</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {mockNurseProfile.certifications.length}
                  </div>
                  <div className="text-sm text-gray-600">Certifications</div>
                </div>
              </>
            ) : (
              <>
                <div className="bg-gray-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {mockFacilityProfile.fillRate}%
                  </div>
                  <div className="text-sm text-gray-600">Fill Rate</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {mockFacilityProfile.avgResponseTime}
                  </div>
                  <div className="text-sm text-gray-600">Avg Response</div>
                </div>
              </>
            )}
          </div>

          {/* Profile Type Toggle */}
          <div className="mt-6 flex bg-gray-100 rounded-lg p-1 w-fit">
            <button
              onClick={() => setProfileType("nurse")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                profileType === "nurse"
                  ? "bg-white text-medical-blue shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Nurse Profile
            </button>
            <button
              onClick={() => setProfileType("facility")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                profileType === "facility"
                  ? "bg-white text-medical-blue shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Facility Profile
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tab Navigation */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="-mb-px flex space-x-8">
            {[
              "overview",
              "contact",
              isNurse ? "credentials" : "shifts",
              "reviews",
            ].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab
                    ? "border-medical-blue text-medical-blue"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {activeTab === "overview" && (
              <div className="space-y-6">
                {isNurse ? (
                  <>
                    {/* Specialties */}
                    <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        Specialties
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {mockNurseProfile.specialties.map(
                          (specialty, index) => (
                            <span
                              key={index}
                              className="bg-medical-blue/10 text-medical-blue px-3 py-1 rounded-full text-sm font-medium"
                            >
                              {specialty}
                            </span>
                          ),
                        )}
                      </div>
                    </div>

                    {/* Certifications */}
                    <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        Certifications
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {mockNurseProfile.certifications.map((cert, index) => (
                          <span
                            key={index}
                            className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium flex items-center"
                          >
                            <Award className="w-3 h-3 mr-1" />
                            {cert}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Recent Shifts */}
                    <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        Recent Shifts
                      </h3>
                      <div className="space-y-4">
                        {mockNurseProfile.recentShifts.map((shift, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                          >
                            <div>
                              <h4 className="font-medium text-gray-900">
                                {shift.facilityName}
                              </h4>
                              <p className="text-sm text-gray-600">
                                {shift.position} • {shift.date}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-gray-900">
                                ${shift.pay}
                              </p>
                              <p className="text-sm text-gray-600">
                                {shift.hours} hours
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Facility Details */}
                    <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        Facility Details
                      </h3>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Legal Name:</span>
                          <span className="font-medium">
                            {mockFacilityProfile.legalName}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Facility Type:</span>
                          <span className="font-medium">
                            {mockFacilityProfile.facilityType}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Bed Count:</span>
                          <span className="font-medium">
                            {mockFacilityProfile.bedCount} beds
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Health System:</span>
                          <span className="font-medium">
                            {mockFacilityProfile.healthSystem}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Open Shifts */}
                    <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-gray-900">
                          Open Shifts
                        </h3>
                        <Link
                          to="/dashboard/shifts"
                          className="text-medical-blue hover:text-blue-700 text-sm font-medium"
                        >
                          View all
                        </Link>
                      </div>
                      <div className="space-y-4">
                        {mockFacilityProfile.openShifts.map((shift, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                          >
                            <div>
                              <div className="flex items-center space-x-2">
                                <h4 className="font-medium text-gray-900">
                                  {shift.position}
                                </h4>
                                {shift.urgent && (
                                  <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">
                                    Urgent
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-gray-600">
                                {shift.department} • {shift.date}
                              </p>
                              <p className="text-sm text-gray-600">
                                {shift.time}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-gray-900">
                                ${shift.pay}/hr
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {activeTab === "contact" && (
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">
                  Contact Information
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <Mail className="w-5 h-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-medium">
                        {isNurse
                          ? mockNurseProfile.email
                          : "contact@memorialhospital.com"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <Phone className="w-5 h-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-600">Phone</p>
                      <p className="font-medium">
                        {isNurse
                          ? mockNurseProfile.phoneNumber
                          : mockFacilityProfile.phoneNumber}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <MapPin className="w-5 h-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-600">Address</p>
                      <p className="font-medium">
                        {isNurse
                          ? mockNurseProfile.location
                          : mockFacilityProfile.fullAddress}
                      </p>
                    </div>
                  </div>

                  {!isNurse && (
                    <>
                      <div className="flex items-center">
                        <Globe className="w-5 h-5 text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm text-gray-600">Website</p>
                          <a
                            href={mockFacilityProfile.website}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-medium text-medical-blue hover:text-blue-700 flex items-center"
                          >
                            {mockFacilityProfile.website}
                            <ExternalLink className="w-4 h-4 ml-1" />
                          </a>
                        </div>
                      </div>

                      <div className="flex items-center">
                        <User className="w-5 h-5 text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm text-gray-600">
                            Primary Contact
                          </p>
                          <p className="font-medium">
                            {mockFacilityProfile.contactPerson}
                          </p>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}

            {activeTab === "credentials" && isNurse && (
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">
                    Credentials & Documents
                  </h3>
                  <button className="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center text-sm">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Document
                  </button>
                </div>
                <div className="space-y-4">
                  {mockNurseProfile.documents.map((doc, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center">
                        <FileText className="w-5 h-5 text-gray-400 mr-3" />
                        <div>
                          <h4 className="font-medium text-gray-900">
                            {doc.type}
                          </h4>
                          {doc.expiryDate && (
                            <p className="text-sm text-gray-600">
                              Expires: {doc.expiryDate}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        {getStatusBadge(doc.status)}
                        <button className="text-gray-400 hover:text-gray-600">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="text-gray-400 hover:text-gray-600">
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "shifts" && !isNurse && (
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">
                  All Open Shifts
                </h3>
                <div className="space-y-4">
                  {mockFacilityProfile.openShifts.map((shift, index) => (
                    <div
                      key={index}
                      className="p-4 border border-gray-200 rounded-lg hover:border-medical-blue transition-colors"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium text-gray-900">
                            {shift.position}
                          </h4>
                          {shift.urgent && (
                            <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">
                              Urgent
                            </span>
                          )}
                        </div>
                        <span className="text-lg font-bold text-gray-900">
                          ${shift.pay}/hr
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                        <div>
                          <p>
                            <strong>Department:</strong> {shift.department}
                          </p>
                          <p>
                            <strong>Date:</strong> {shift.date}
                          </p>
                        </div>
                        <div>
                          <p>
                            <strong>Time:</strong> {shift.time}
                          </p>
                          <p>
                            <strong>Duration:</strong> 12 hours
                          </p>
                        </div>
                      </div>
                      <div className="mt-3 flex justify-end">
                        <button className="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                          Edit Shift
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "reviews" && (
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">
                  Reviews & Feedback
                </h3>
                <div className="space-y-6">
                  {profile.reviews.map((review, index) => (
                    <div
                      key={index}
                      className="border-b border-gray-200 pb-6 last:border-b-0"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-medical-blue to-ai-purple rounded-full flex items-center justify-center text-white text-sm font-bold">
                            {(isNurse
                              ? review.facilityName
                              : review.nurseName
                            ).charAt(0)}
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-900">
                              {isNurse ? review.facilityName : review.nurseName}
                            </h4>
                            <p className="text-sm text-gray-600">
                              {review.date}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating
                                  ? "text-yellow-500 fill-current"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-gray-700">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Availability Calendar (Nurses only) */}
            {isNurse && (
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  Availability
                </h3>
                <div className="text-center text-gray-600">
                  <Calendar className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                  <p>Calendar component would go here</p>
                  <button className="mt-3 text-medical-blue hover:text-blue-700 text-sm font-medium">
                    Update Availability
                  </button>
                </div>
              </div>
            )}

            {/* Quick Actions */}
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Quick Actions
              </h3>
              <div className="space-y-3">
                {isNurse ? (
                  <>
                    <button className="w-full bg-medical-blue text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      Find Shifts
                    </button>
                    <button className="w-full bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center">
                      <FileText className="w-4 h-4 mr-2" />
                      Submit Timesheet
                    </button>
                    <button className="w-full bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center">
                      <Award className="w-4 h-4 mr-2" />
                      Update Credentials
                    </button>
                  </>
                ) : (
                  <>
                    <button className="w-full bg-medical-blue text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      Post New Shift
                    </button>
                    <button className="w-full bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center">
                      <Users className="w-4 h-4 mr-2" />
                      Review Applicants
                    </button>
                    <button className="w-full bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center">
                      <TrendingUp className="w-4 h-4 mr-2" />
                      View Analytics
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Performance Stats */}
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                {isNurse ? "Performance" : "Facility Stats"}
              </h3>
              <div className="space-y-4">
                {isNurse ? (
                  <>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Completion Rate</span>
                      <span className="font-medium text-green-600">98%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">On-time Rate</span>
                      <span className="font-medium text-green-600">96%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Total Earnings</span>
                      <span className="font-medium text-gray-900">$89,420</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Shifts Posted</span>
                      <span className="font-medium text-gray-900">892</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Average Fill Time</span>
                      <span className="font-medium text-green-600">
                        2.3 hours
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Nurse Retention</span>
                      <span className="font-medium text-green-600">87%</span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
