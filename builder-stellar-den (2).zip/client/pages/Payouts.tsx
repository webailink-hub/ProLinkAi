import React, { useState } from 'react';
import { DollarSign, TrendingUp, Calendar, Clock, Download, Filter, CreditCard, Landmark, Smartphone, Brain, FileText, AlertCircle, CheckCircle, Eye, MoreHorizontal } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';

interface Payment {
  id: string;
  weekEnding: string;
  totalHours: number;
  regularHours: number;
  overtimeHours: number;
  regularRate: number;
  overtimeRate: number;
  grossPay: number;
  taxes: number;
  deductions: number;
  netPay: number;
  status: 'pending' | 'processing' | 'paid' | 'failed';
  payDate: string;
  shifts: number;
  facilities: string[];
  paymentMethod: 'direct_deposit' | 'instant_pay' | 'check';
}

interface TaxDocument {
  id: string;
  type: '1099' | 'W2' | 'paystub';
  year: number;
  amount: number;
  date: string;
  status: 'available' | 'processing';
}

export default function Payouts() {
  const [selectedPeriod, setSelectedPeriod] = useState('2024');
  const [filter, setFilter] = useState<'all' | 'pending' | 'paid'>('all');
  const [showTaxOptimization, setShowTaxOptimization] = useState(true);

  const payments: Payment[] = [
    {
      id: '1',
      weekEnding: '2024-02-02',
      totalHours: 48,
      regularHours: 40,
      overtimeHours: 8,
      regularRate: 45,
      overtimeRate: 67.5,
      grossPay: 2340,
      taxes: 468,
      deductions: 117,
      netPay: 1755,
      status: 'paid',
      payDate: '2024-02-05',
      shifts: 4,
      facilities: ['SF General', 'UCSF Medical'],
      paymentMethod: 'direct_deposit'
    },
    {
      id: '2',
      weekEnding: '2024-01-26',
      totalHours: 36,
      regularHours: 36,
      overtimeHours: 0,
      regularRate: 45,
      overtimeRate: 67.5,
      grossPay: 1620,
      taxes: 324,
      deductions: 81,
      netPay: 1215,
      status: 'paid',
      payDate: '2024-01-29',
      shifts: 3,
      facilities: ['Stanford Medical'],
      paymentMethod: 'direct_deposit'
    },
    {
      id: '3',
      weekEnding: '2024-01-19',
      totalHours: 52,
      regularHours: 40,
      overtimeHours: 12,
      regularRate: 42,
      overtimeRate: 63,
      grossPay: 2436,
      taxes: 487,
      deductions: 122,
      netPay: 1827,
      status: 'processing',
      payDate: '2024-01-22',
      shifts: 5,
      facilities: ['SF General', 'Kaiser Permanente', 'UCSF Medical'],
      paymentMethod: 'instant_pay'
    },
    {
      id: '4',
      weekEnding: '2024-01-12',
      totalHours: 44,
      regularHours: 40,
      overtimeHours: 4,
      regularRate: 42,
      overtimeRate: 63,
      grossPay: 1932,
      taxes: 386,
      deductions: 97,
      netPay: 1449,
      status: 'pending',
      payDate: '2024-01-15',
      shifts: 4,
      facilities: ['Stanford Medical', 'SF General'],
      paymentMethod: 'direct_deposit'
    }
  ];

  const taxDocuments: TaxDocument[] = [
    { id: '1', type: '1099', year: 2023, amount: 89420, date: '2024-01-31', status: 'available' },
    { id: '2', type: 'paystub', year: 2024, amount: 7241, date: '2024-02-05', status: 'available' },
    { id: '3', type: 'paystub', year: 2024, amount: 6834, date: '2024-01-29', status: 'available' }
  ];

  const currentYear = new Date().getFullYear();
  const yearToDateEarnings = payments
    .filter(p => p.payDate.startsWith('2024') && p.status === 'paid')
    .reduce((sum, p) => sum + p.netPay, 0);
  
  const averageWeeklyPay = yearToDateEarnings / Math.max(1, payments.filter(p => p.status === 'paid').length);
  const totalHoursWorked = payments.reduce((sum, p) => sum + p.totalHours, 0);
  const averageHourlyRate = payments.reduce((sum, p) => sum + (p.grossPay / p.totalHours), 0) / payments.length;

  const filteredPayments = payments.filter(payment => {
    if (filter === 'pending') return payment.status === 'pending' || payment.status === 'processing';
    if (filter === 'paid') return payment.status === 'paid';
    return true;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800 border-green-200';
      case 'processing': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'failed': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid': return <CheckCircle className="w-4 h-4" />;
      case 'processing': return <Clock className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'failed': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case 'direct_deposit': return <Landmark className="w-4 h-4" />;
      case 'instant_pay': return <Smartphone className="w-4 h-4" />;
      case 'check': return <FileText className="w-4 h-4" />;
      default: return <CreditCard className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent">
            Earnings & Payments
          </h1>
          <p className="text-gray-600 mt-2">
            Track your earnings with AI insights and tax optimization recommendations
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>
      </div>

      {/* AI Tax Optimization Panel */}
      {showTaxOptimization && (
        <Card className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 border-ai-purple/20">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-gradient-to-br from-ai-purple to-medical-teal rounded-xl">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-ai-purple mb-2">AI Tax Optimization</h3>
                  <div className="space-y-2 text-sm text-gray-600">
                    <p>• You could save $1,847 annually by optimizing deductions</p>
                    <p>• Consider contributing to retirement accounts before year-end</p>
                    <p>• Track mileage for travel shifts (estimated $450 deduction)</p>
                    <p>• Business phone/internet expenses may be deductible</p>
                  </div>
                  <Button variant="outline" size="sm" className="mt-3">
                    <FileText className="w-4 h-4 mr-2" />
                    Get Detailed Tax Report
                  </Button>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowTaxOptimization(false)}
              >
                ×
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Earnings Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">${yearToDateEarnings.toLocaleString()}</div>
                <div className="text-sm text-gray-600">Year to Date</div>
              </div>
            </div>
            <div className="mt-2">
              <div className="flex items-center gap-1 text-xs text-green-600">
                <TrendingUp className="w-3 h-3" />
                <span>+12% vs last year</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Calendar className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600">${averageWeeklyPay.toLocaleString()}</div>
                <div className="text-sm text-gray-600">Avg Weekly</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-medical-blue/10 rounded-lg">
                <Clock className="w-5 h-5 text-medical-blue" />
              </div>
              <div>
                <div className="text-2xl font-bold text-medical-blue">{totalHoursWorked}</div>
                <div className="text-sm text-gray-600">Total Hours</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-ai-purple/10 rounded-lg">
                <TrendingUp className="w-5 h-5 text-ai-purple" />
              </div>
              <div>
                <div className="text-2xl font-bold text-ai-purple">${averageHourlyRate.toFixed(0)}</div>
                <div className="text-sm text-gray-600">Avg Hourly</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Payment History */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Payment History
                </CardTitle>
                <div className="flex items-center gap-2">
                  <select 
                    value={filter}
                    onChange={(e) => setFilter(e.target.value as any)}
                    className="text-sm border border-gray-300 rounded-md px-3 py-1"
                  >
                    <option value="all">All Payments</option>
                    <option value="pending">Pending</option>
                    <option value="paid">Paid</option>
                  </select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredPayments.map((payment) => (
                  <div key={payment.id} className="border rounded-lg p-4 hover:shadow-sm transition-shadow">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-gray-900">
                          Week ending {new Date(payment.weekEnding).toLocaleDateString()}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {payment.shifts} shifts at {payment.facilities.join(', ')}
                        </p>
                      </div>
                      
                      <div className="text-right">
                        <div className="text-xl font-bold text-green-600">${payment.netPay.toLocaleString()}</div>
                        <Badge className={getStatusColor(payment.status)}>
                          <div className="flex items-center gap-1">
                            {getStatusIcon(payment.status)}
                            {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                          </div>
                        </Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Total Hours:</span>
                        <div className="font-medium">{payment.totalHours}h</div>
                        <div className="text-xs text-gray-500">
                          {payment.regularHours}h reg + {payment.overtimeHours}h OT
                        </div>
                      </div>
                      
                      <div>
                        <span className="text-gray-600">Gross Pay:</span>
                        <div className="font-medium">${payment.grossPay.toLocaleString()}</div>
                        <div className="text-xs text-gray-500">
                          ${payment.regularRate}/hr reg
                        </div>
                      </div>
                      
                      <div>
                        <span className="text-gray-600">Deductions:</span>
                        <div className="font-medium">-${(payment.taxes + payment.deductions).toLocaleString()}</div>
                        <div className="text-xs text-gray-500">
                          Taxes: ${payment.taxes} | Other: ${payment.deductions}
                        </div>
                      </div>
                      
                      <div>
                        <span className="text-gray-600">Payment Method:</span>
                        <div className="flex items-center gap-1 font-medium">
                          {getPaymentMethodIcon(payment.paymentMethod)}
                          <span className="capitalize">{payment.paymentMethod.replace('_', ' ')}</span>
                        </div>
                        <div className="text-xs text-gray-500">
                          Paid: {new Date(payment.payDate).toLocaleDateString()}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100">
                      <div className="text-xs text-gray-500">
                        Effective rate: ${(payment.grossPay / payment.totalHours).toFixed(2)}/hour
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          View Details
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90">
                <Smartphone className="w-4 h-4 mr-2" />
                Request Instant Pay
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <CreditCard className="w-4 h-4 mr-2" />
                Update Payment Method
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <FileText className="w-4 h-4 mr-2" />
                Tax Center
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Download className="w-4 h-4 mr-2" />
                Download Tax Documents
              </Button>
            </CardContent>
          </Card>

          {/* Payment Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Payment Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Direct Deposit</span>
                  <Badge className="bg-green-100 text-green-800 border-green-200">Active</Badge>
                </div>
                <div className="text-sm text-gray-600">
                  Bank ending in ****1234
                </div>
              </div>

              <div className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Instant Pay</span>
                  <Badge className="bg-blue-100 text-blue-800 border-blue-200">Available</Badge>
                </div>
                <div className="text-sm text-gray-600">
                  $2.99 fee per transaction
                </div>
              </div>

              <div className="p-3 border rounded-lg bg-gray-50">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Paper Check</span>
                  <Badge className="bg-gray-100 text-gray-800 border-gray-200">Inactive</Badge>
                </div>
                <div className="text-sm text-gray-600">
                  $5 fee, 7-10 business days
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tax Documents */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Tax Documents</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {taxDocuments.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">{doc.type.toUpperCase()} {doc.year}</div>
                    <div className="text-sm text-gray-600">
                      ${doc.amount.toLocaleString()} | {new Date(doc.date).toLocaleDateString()}
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Earnings Goal */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Monthly Goal</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>$6,840 / $8,000</span>
                </div>
                <Progress value={85.5} className="h-2" />
                <div className="text-xs text-gray-600">
                  You're $1,160 away from your monthly goal. Work 2 more shifts to reach it!
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
