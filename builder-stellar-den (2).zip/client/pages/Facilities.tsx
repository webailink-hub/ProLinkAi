import {
  Brain,
  TrendingUp,
  Clock,
  Shield,
  DollarSign,
  Users,
  CheckCircle2,
  BarChart3,
  Target,
  Zap,
  Calendar,
  Award,
  ArrowRight,
  Building2,
  Lightbulb,
  PieChart,
  Timer,
  AlertTriangle,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function Facilities() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            <div className="hidden md:flex items-center space-x-8">
              <Link
                to="/nurses"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                For Nurses
              </Link>
              <Link
                to="/facilities"
                className="text-medical-blue font-medium font-body"
              >
                For Facilities
              </Link>
              <Link
                to="/about"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                About
              </Link>
              <Link
                to="/login"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Sign In
              </Link>
              <Link
                to="/register/facility"
                className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-6 py-2 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium shadow-card hover:shadow-card-hover"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-medical-gray via-white to-blue-50 py-20 lg:py-32">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center bg-medical-green/10 text-medical-green px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Building2 className="w-4 h-4 mr-2" />
                Trusted by 500+ Healthcare Facilities
              </div>
              <h1 className="text-4xl lg:text-6xl font-header font-bold text-gray-900 leading-tight mb-6">
                Fill Shifts 50% Faster
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-medical-blue to-ai-purple block">
                  With AI Precision
                </span>
              </h1>
              <p className="text-xl text-gray-600 font-body leading-relaxed mb-8">
                Eliminate staffing gaps, reduce overtime costs, and improve
                patient care with our AI-powered nurse matching platform
                designed for modern healthcare facilities.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <Link
                  to="/register/facility"
                  className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 text-center"
                >
                  Start Free 30-Day Trial
                </Link>
                <Link
                  to="/demo"
                  className="bg-white text-medical-blue border-2 border-medical-blue px-8 py-4 rounded-xl hover:bg-medical-blue hover:text-white transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 text-center"
                >
                  Request Demo
                </Link>
              </div>

              {/* Key ROI Metrics */}
              <div className="grid grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-header font-bold text-medical-blue">
                    50%
                  </div>
                  <div className="text-sm text-gray-600 font-body">
                    Faster Shift Filling
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-header font-bold text-medical-green">
                    35%
                  </div>
                  <div className="text-sm text-gray-600 font-body">
                    Reduction in Overtime
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-header font-bold text-ai-purple">
                    $2.1M
                  </div>
                  <div className="text-sm text-gray-600 font-body">
                    Average Annual Savings
                  </div>
                </div>
              </div>
            </div>

            {/* Hero Visual - ROI Dashboard */}
            <div className="relative">
              <div className="bg-gradient-to-br from-medical-blue via-ai-purple to-medical-teal rounded-3xl p-8 shadow-card-hover">
                <div className="bg-white/95 backdrop-blur rounded-2xl p-6 mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-header font-semibold text-gray-900">
                      Staffing Dashboard
                    </h3>
                    <div className="text-xs bg-medical-green/10 text-medical-green px-2 py-1 rounded">
                      Live
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">
                        Shifts Filled Today
                      </span>
                      <span className="font-bold text-medical-green">
                        24/26
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-medical-green h-2 rounded-full"
                        style={{ width: "92%" }}
                      ></div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <div className="text-center">
                        <div className="text-lg font-bold text-medical-blue">
                          2.3h
                        </div>
                        <div className="text-xs text-gray-600">
                          Avg Fill Time
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-ai-purple">
                          $12K
                        </div>
                        <div className="text-xs text-gray-600">
                          Monthly Savings
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-center text-white">
                  <BarChart3 className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm opacity-90">
                    Real-time Analytics & Insights
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem/Solution Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              The Staffing Crisis Costs More Than You Think
            </h2>
            <p className="text-xl text-gray-600 font-body max-w-3xl mx-auto">
              Traditional staffing methods are failing. ProLinkAi's AI-powered
              solution addresses the root causes.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Problems */}
            <div>
              <h3 className="text-2xl font-header font-bold text-gray-900 mb-8 flex items-center">
                <AlertTriangle className="w-6 h-6 text-red-500 mr-3" />
                Current Challenges
              </h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 mr-4 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">
                      Time-Consuming Manual Processes
                    </h4>
                    <p className="text-gray-600 text-sm">
                      Average 6-8 hours to fill a single shift through
                      traditional methods
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 mr-4 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">
                      Expensive Overtime Costs
                    </h4>
                    <p className="text-gray-600 text-sm">
                      Unfilled shifts lead to 1.5-2x overtime rates for existing
                      staff
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 mr-4 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">
                      Quality & Compliance Risks
                    </h4>
                    <p className="text-gray-600 text-sm">
                      Rushed hiring without proper credential verification
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 mr-4 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">
                      Staff Burnout & Turnover
                    </h4>
                    <p className="text-gray-600 text-sm">
                      Overworked staff leads to 25% higher turnover rates
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Solutions */}
            <div>
              <h3 className="text-2xl font-header font-bold text-gray-900 mb-8 flex items-center">
                <CheckCircle2 className="w-6 h-6 text-medical-green mr-3" />
                ProLinkAi Solutions
              </h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-medical-green rounded-full mt-2 mr-4 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">
                      AI-Powered Instant Matching
                    </h4>
                    <p className="text-gray-600 text-sm">
                      Fill shifts in minutes with qualified, available nurses
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-medical-green rounded-full mt-2 mr-4 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">
                      Predictive Cost Management
                    </h4>
                    <p className="text-gray-600 text-sm">
                      Reduce overtime costs by 35% with proactive shift planning
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-medical-green rounded-full mt-2 mr-4 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">
                      Automated Credential Verification
                    </h4>
                    <p className="text-gray-600 text-sm">
                      100% compliance with real-time license and certification
                      checks
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-medical-green rounded-full mt-2 mr-4 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">
                      Workload Balance Optimization
                    </h4>
                    <p className="text-gray-600 text-sm">
                      Improve staff satisfaction and reduce turnover
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Features */}
      <section className="py-20 bg-medical-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Enterprise-Grade Features Built for Healthcare
            </h2>
            <p className="text-xl text-gray-600 font-body max-w-3xl mx-auto">
              Everything you need to transform your staffing operations and
              improve patient outcomes
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200">
              <div className="w-12 h-12 bg-gradient-to-br from-ai-purple to-medical-blue rounded-xl flex items-center justify-center mb-6">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Intelligent Nurse Matching
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                AI algorithms match nurses based on skills, experience,
                location, and your specific requirements.
              </p>
              <ul className="text-sm text-gray-600 space-y-2">
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Skill-based matching
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Availability optimization
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Performance history
                </li>
              </ul>
            </div>

            {/* Feature 2 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200">
              <div className="w-12 h-12 bg-gradient-to-br from-medical-green to-medical-teal rounded-xl flex items-center justify-center mb-6">
                <PieChart className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Real-Time Analytics Dashboard
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Track key metrics, monitor costs, and optimize your staffing
                strategy with actionable insights.
              </p>
              <ul className="text-sm text-gray-600 space-y-2">
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Fill rate tracking
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Cost analysis
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Predictive modeling
                </li>
              </ul>
            </div>

            {/* Feature 3 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200">
              <div className="w-12 h-12 bg-gradient-to-br from-medical-blue to-medical-teal rounded-xl flex items-center justify-center mb-6">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Automated Compliance Management
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Ensure 100% compliance with automated credential verification
                and audit trails.
              </p>
              <ul className="text-sm text-gray-600 space-y-2">
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  License verification
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Background checks
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Audit reporting
                </li>
              </ul>
            </div>

            {/* Feature 4 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200">
              <div className="w-12 h-12 bg-gradient-to-br from-accent-orange to-medical-green rounded-xl flex items-center justify-center mb-6">
                <Timer className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Predictive Staffing
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Anticipate staffing needs with AI-powered demand forecasting and
                proactive shift planning.
              </p>
              <ul className="text-sm text-gray-600 space-y-2">
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Demand forecasting
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Seasonal planning
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Gap prevention
                </li>
              </ul>
            </div>

            {/* Feature 5 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200">
              <div className="w-12 h-12 bg-gradient-to-br from-ai-purple to-accent-orange rounded-xl flex items-center justify-center mb-6">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Cost Optimization Engine
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Reduce staffing costs by up to 35% with intelligent shift
                optimization and rate management.
              </p>
              <ul className="text-sm text-gray-600 space-y-2">
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Dynamic pricing
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Overtime reduction
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Budget forecasting
                </li>
              </ul>
            </div>

            {/* Feature 6 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200">
              <div className="w-12 h-12 bg-gradient-to-br from-medical-teal to-ai-purple rounded-xl flex items-center justify-center mb-6">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Quality Assurance System
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Maintain high care standards with nurse rating systems and
                performance tracking.
              </p>
              <ul className="text-sm text-gray-600 space-y-2">
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Performance ratings
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Feedback systems
                </li>
                <li className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-medical-green mr-2" />
                  Quality metrics
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* ROI Calculator Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Calculate Your ROI
            </h2>
            <p className="text-xl text-gray-600 font-body">
              See how much ProLinkAi can save your facility annually
            </p>
          </div>

          <div className="bg-gradient-to-br from-medical-blue to-ai-purple rounded-3xl p-8 lg:p-12 text-white">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl lg:text-3xl font-header font-bold mb-6">
                  Average Facility Savings with ProLinkAi
                </h3>
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <span className="text-blue-100">
                      Reduced overtime costs (35%)
                    </span>
                    <span className="font-bold text-2xl">$850K</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-blue-100">
                      Faster shift filling (50%)
                    </span>
                    <span className="font-bold text-2xl">$420K</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-blue-100">
                      Reduced turnover (25%)
                    </span>
                    <span className="font-bold text-2xl">$380K</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-blue-100">
                      Administrative efficiency
                    </span>
                    <span className="font-bold text-2xl">$450K</span>
                  </div>
                  <div className="border-t border-blue-300/30 pt-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xl font-medium">
                        Total Annual Savings
                      </span>
                      <span className="font-bold text-4xl text-yellow-300">
                        $2.1M
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur rounded-2xl p-8">
                <h4 className="text-xl font-header font-semibold mb-6">
                  For a 300-bed facility
                </h4>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-blue-100">ProLinkAi Investment</span>
                    <span className="font-medium">$180K/year</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-100">Total Savings</span>
                    <span className="font-medium">$2.1M/year</span>
                  </div>
                  <div className="flex justify-between border-t border-blue-300/30 pt-4">
                    <span className="font-bold">Net ROI</span>
                    <span className="font-bold text-2xl text-yellow-300">
                      1,067%
                    </span>
                  </div>
                </div>

                <Link
                  to="/roi-calculator"
                  className="w-full bg-white text-medical-blue mt-6 py-3 rounded-xl hover:bg-gray-50 transition-colors font-medium text-center block"
                >
                  Calculate Your Custom ROI
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-medical-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Trusted by Leading Healthcare Systems
            </h2>
            <p className="text-xl text-gray-600 font-body">
              See what facility leaders are saying about ProLinkAi
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-medical-blue to-ai-purple rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">MH</span>
                </div>
                <div>
                  <div className="font-medium text-gray-900">
                    Michael Harrison
                  </div>
                  <div className="text-sm text-gray-600">
                    CNO, Metro General Hospital
                  </div>
                </div>
              </div>
              <p className="text-gray-700 font-body leading-relaxed">
                "ProLinkAi reduced our shift fill time from 6 hours to 20
                minutes. We've saved $1.2M in overtime costs this year alone.
                The ROI is incredible."
              </p>
              <div className="mt-4 text-medical-blue font-medium text-sm">
                $1.2M saved in overtime costs
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-medical-green to-medical-teal rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">SP</span>
                </div>
                <div>
                  <div className="font-medium text-gray-900">Sarah Parker</div>
                  <div className="text-sm text-gray-600">
                    VP Operations, City Medical Center
                  </div>
                </div>
              </div>
              <p className="text-gray-700 font-body leading-relaxed">
                "The AI matching is phenomenal. We get nurses who are perfectly
                qualified and available. Patient satisfaction scores improved by
                15% since implementation."
              </p>
              <div className="mt-4 text-medical-green font-medium text-sm">
                15% improvement in patient satisfaction
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-ai-purple to-accent-orange rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">DL</span>
                </div>
                <div>
                  <div className="font-medium text-gray-900">Dr. Lisa Chen</div>
                  <div className="text-sm text-gray-600">
                    CMO, Regional Healthcare System
                  </div>
                </div>
              </div>
              <p className="text-gray-700 font-body leading-relaxed">
                "The predictive staffing feature helped us avoid critical
                shortages during flu season. ProLinkAi is essential for our
                operations now."
              </p>
              <div className="mt-4 text-ai-purple font-medium text-sm">
                Zero critical staffing shortages
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-medical-blue via-ai-purple to-medical-teal">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white/10 backdrop-blur rounded-full p-4 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
            <TrendingUp className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl lg:text-4xl font-header font-bold text-white mb-6">
            Ready to Transform Your Staffing Operations?
          </h2>
          <p className="text-xl text-blue-100 font-body mb-8 leading-relaxed">
            Join 500+ healthcare facilities saving millions with AI-powered
            staffing. Start your free trial today and see results in 24 hours.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register/facility"
              className="bg-white text-medical-blue px-8 py-4 rounded-xl hover:bg-gray-50 transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 inline-flex items-center justify-center"
            >
              Start Free 30-Day Trial
              <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
            <Link
              to="/demo"
              className="bg-transparent text-white border-2 border-white px-8 py-4 rounded-xl hover:bg-white hover:text-medical-blue transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5"
            >
              Request Custom Demo
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <span className="ml-3 text-xl font-header font-bold">
                  ProLink<span className="text-ai-purple">Ai</span>
                </span>
              </div>
              <p className="text-gray-400 font-body leading-relaxed mb-6">
                Transforming healthcare staffing with AI-powered solutions.
                Trusted by 500+ facilities nationwide.
              </p>
              <div className="text-sm text-gray-400 font-body">
                © 2024 ProLinkAi. All rights reserved.
              </div>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-4">For Facilities</h3>
              <ul className="space-y-2 font-body">
                <li>
                  <Link
                    to="/dashboard/post-shift"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Post Shifts
                  </Link>
                </li>
                <li>
                  <Link
                    to="/dashboard/applicants"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Manage Applicants
                  </Link>
                </li>
                <li>
                  <Link
                    to="/analytics"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Analytics
                  </Link>
                </li>
                <li>
                  <Link
                    to="/roi-calculator"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    ROI Calculator
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-4">Company</h3>
              <ul className="space-y-2 font-body">
                <li>
                  <Link
                    to="/about"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/nurses"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    For Nurses
                  </Link>
                </li>
                <li>
                  <Link
                    to="/demo"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Request Demo
                  </Link>
                </li>
                <li>
                  <Link
                    to="/contact"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
