export default function Test() {
  return (
    <div className="min-h-screen bg-medical-gray p-8">
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-card p-8">
        <h1 className="text-3xl font-header font-bold text-gray-900 mb-4">
          ProLinkAi Test Page
        </h1>
        <p className="text-gray-600 font-body text-lg mb-6">
          This is a test page to verify that the ProLinkAi application is
          working correctly.
        </p>
        <div className="bg-gradient-to-r from-medical-blue to-ai-purple text-white p-4 rounded-lg">
          <p className="font-medium">✅ React is working</p>
          <p className="font-medium">✅ Routing is working</p>
          <p className="font-medium">✅ Styling is working</p>
          <p className="font-medium">✅ Mobile responsiveness is working</p>
        </div>
      </div>
    </div>
  );
}
