import React, { useState } from 'react';
import { CheckCircle, XCircle, Building2, Eye, Download, FileText, MapPin, Calendar, Phone, Mail, Users, Brain, Search, Filter, Shield, Award } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';

interface FacilityApplication {
  id: string;
  basicInfo: {
    name: string;
    type: 'hospital' | 'clinic' | 'nursing_home' | 'urgent_care' | 'surgery_center';
    website?: string;
    logo?: string;
  };
  contactInfo: {
    address: string;
    city: string;
    state: string;
    zipCode: string;
    phone: string;
    email: string;
    contactPerson: {
      name: string;
      title: string;
      email: string;
      phone: string;
    };
  };
  operationalInfo: {
    bedCount?: number;
    departments: string[];
    operatingHours: string;
    emergencyServices: boolean;
    traumaLevel?: string;
    specialties: string[];
  };
  credentials: Array<{
    type: string;
    number: string;
    issuingOrganization: string;
    issueDate: string;
    expiryDate: string;
    documentUrl: string;
    status: 'pending' | 'verified' | 'rejected';
  }>;
  insurance: {
    provider: string;
    policyNumber: string;
    coverage: string;
    expiryDate: string;
    documentUrl: string;
  };
  applicationDate: string;
  status: 'pending' | 'under_review' | 'approved' | 'rejected';
  reviewedBy?: string;
  reviewDate?: string;
  reviewNotes?: string;
  aiScore: number;
  riskAssessment: 'low' | 'medium' | 'high';
  complianceScore: number;
}

export default function FacilityVerification() {
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'under_review' | 'approved' | 'rejected'>('pending');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFacility, setSelectedFacility] = useState<FacilityApplication | null>(null);

  const [facilities, setFacilities] = useState<FacilityApplication[]>([
    {
      id: '1',
      basicInfo: {
        name: 'Bay Area Medical Center',
        type: 'hospital',
        website: 'https://bayareamedical.com',
        logo: '/api/placeholder/80/80'
      },
      contactInfo: {
        address: '1500 Medical Drive',
        city: 'San Francisco',
        state: 'CA',
        zipCode: '94102',
        phone: '+1 (415) 555-0100',
        email: 'admin@bayareamedical.com',
        contactPerson: {
          name: 'Dr. Emily Rodriguez',
          title: 'Chief Nursing Officer',
          email: 'e.rodriguez@bayareamedical.com',
          phone: '+1 (415) 555-0101'
        }
      },
      operationalInfo: {
        bedCount: 250,
        departments: ['Emergency', 'ICU', 'Medical-Surgical', 'Oncology', 'Cardiology', 'Pediatrics'],
        operatingHours: '24/7',
        emergencyServices: true,
        traumaLevel: 'Level II',
        specialties: ['Cardiac Surgery', 'Neurology', 'Orthopedics', 'Women\'s Health']
      },
      credentials: [
        {
          type: 'Hospital License',
          number: 'HL-2024-001',
          issuingOrganization: 'California Department of Public Health',
          issueDate: '2024-01-01',
          expiryDate: '2025-12-31',
          documentUrl: '/documents/hospital-license.pdf',
          status: 'pending'
        },
        {
          type: 'Joint Commission Accreditation',
          number: 'JCA-456789',
          issuingOrganization: 'The Joint Commission',
          issueDate: '2023-06-15',
          expiryDate: '2026-06-15',
          documentUrl: '/documents/jc-accreditation.pdf',
          status: 'pending'
        },
        {
          type: 'Medicare Provider Agreement',
          number: 'MPA-123456',
          issuingOrganization: 'Centers for Medicare & Medicaid Services',
          issueDate: '2023-01-01',
          expiryDate: '2024-12-31',
          documentUrl: '/documents/medicare-agreement.pdf',
          status: 'pending'
        }
      ],
      insurance: {
        provider: 'Healthcare Risk Advisors',
        policyNumber: 'HRA-789012',
        coverage: 'Professional Liability - $10M per occurrence',
        expiryDate: '2024-12-31',
        documentUrl: '/documents/insurance-policy.pdf'
      },
      applicationDate: '2024-02-09',
      status: 'pending',
      aiScore: 92,
      riskAssessment: 'low',
      complianceScore: 96
    },
    {
      id: '2',
      basicInfo: {
        name: 'Sunset Valley Urgent Care',
        type: 'urgent_care',
        website: 'https://sunsetvalleyuc.com',
        logo: '/api/placeholder/80/80'
      },
      contactInfo: {
        address: '2200 Sunset Boulevard',
        city: 'Oakland',
        state: 'CA',
        zipCode: '94601',
        phone: '+1 (510) 555-0200',
        email: 'info@sunsetvalleyuc.com',
        contactPerson: {
          name: 'Sarah Mitchell',
          title: 'Practice Manager',
          email: 's.mitchell@sunsetvalleyuc.com',
          phone: '+1 (510) 555-0201'
        }
      },
      operationalInfo: {
        bedCount: 8,
        departments: ['Urgent Care', 'Minor Emergency', 'Occupational Health'],
        operatingHours: '7 AM - 11 PM Daily',
        emergencyServices: false,
        specialties: ['Urgent Care', 'Occupational Medicine', 'Minor Procedures']
      },
      credentials: [
        {
          type: 'Clinic License',
          number: 'CL-2024-045',
          issuingOrganization: 'California Department of Public Health',
          issueDate: '2024-01-15',
          expiryDate: '2025-01-15',
          documentUrl: '/documents/clinic-license.pdf',
          status: 'pending'
        },
        {
          type: 'DEA Registration',
          number: 'DEA-BC1234567',
          issuingOrganization: 'Drug Enforcement Administration',
          issueDate: '2023-03-01',
          expiryDate: '2026-02-28',
          documentUrl: '/documents/dea-registration.pdf',
          status: 'pending'
        }
      ],
      insurance: {
        provider: 'Medical Protective',
        policyNumber: 'MP-345678',
        coverage: 'Professional Liability - $5M per occurrence',
        expiryDate: '2024-11-30',
        documentUrl: '/documents/insurance-policy-2.pdf'
      },
      applicationDate: '2024-02-11',
      status: 'under_review',
      aiScore: 88,
      riskAssessment: 'low',
      complianceScore: 94
    }
  ]);

  const handleStatusChange = (facilityId: string, newStatus: 'approved' | 'rejected', notes?: string) => {
    setFacilities(facilities.map(facility => 
      facility.id === facilityId 
        ? { 
            ...facility, 
            status: newStatus,
            reviewedBy: 'Admin User',
            reviewDate: new Date().toISOString(),
            reviewNotes: notes
          }
        : facility
    ));
  };

  const handleCredentialVerification = (facilityId: string, credentialIndex: number, status: 'verified' | 'rejected') => {
    setFacilities(facilities.map(facility => 
      facility.id === facilityId 
        ? {
            ...facility,
            credentials: facility.credentials.map((cred, index) =>
              index === credentialIndex ? { ...cred, status } : cred
            )
          }
        : facility
    ));
  };

  const filteredFacilities = facilities.filter(facility => {
    const matchesStatus = statusFilter === 'all' || facility.status === statusFilter;
    const matchesSearch = searchTerm === '' ||
      facility.basicInfo.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      facility.contactInfo.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesStatus && matchesSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'under_review': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'approved': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      case 'verified': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getFacilityTypeDisplay = (type: string) => {
    return type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  const stats = {
    total: facilities.length,
    pending: facilities.filter(f => f.status === 'pending').length,
    underReview: facilities.filter(f => f.status === 'under_review').length,
    approved: facilities.filter(f => f.status === 'approved').length,
    rejected: facilities.filter(f => f.status === 'rejected').length
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent">
            Facility Verification
          </h1>
          <p className="text-gray-600 mt-2">
            Review and approve facility applications with compliance verification
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
            <div className="text-sm text-gray-600">Total Applications</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
            <div className="text-sm text-gray-600">Pending Review</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.underReview}</div>
            <div className="text-sm text-gray-600">Under Review</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{stats.approved}</div>
            <div className="text-sm text-gray-600">Approved</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">{stats.rejected}</div>
            <div className="text-sm text-gray-600">Rejected</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by facility name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="under_review">Under Review</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Facility Applications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            Facility Applications ({filteredFacilities.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {filteredFacilities.map((facility) => (
              <div key={facility.id} className="border rounded-lg p-6 hover:shadow-sm transition-shadow">
                <div className="flex items-start gap-6">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src={facility.basicInfo.logo} />
                    <AvatarFallback className="bg-gradient-to-br from-medical-teal to-medical-blue text-white text-lg">
                      {facility.basicInfo.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-gray-900">
                          {facility.basicInfo.name}
                        </h3>
                        <p className="text-medical-teal">{getFacilityTypeDisplay(facility.basicInfo.type)}</p>
                        <p className="text-gray-600">{facility.contactInfo.email}</p>
                        <p className="text-gray-600">{facility.contactInfo.phone}</p>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(facility.status)}>
                          {facility.status.replace('_', ' ').toUpperCase()}
                        </Badge>
                        <Badge className={`${getRiskColor(facility.riskAssessment)} bg-current/10 border-current/20`}>
                          {facility.riskAssessment.toUpperCase()} RISK
                        </Badge>
                      </div>
                    </div>

                    {/* AI Scores */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="p-3 bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 rounded-lg border border-ai-purple/20">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Brain className="w-4 h-4 text-ai-purple" />
                            <span className="font-semibold text-ai-purple">AI Verification Score</span>
                          </div>
                          <div className="text-xl font-bold text-ai-purple">{facility.aiScore}%</div>
                        </div>
                      </div>
                      
                      <div className="p-3 bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-lg border border-green-500/20">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Shield className="w-4 h-4 text-green-600" />
                            <span className="font-semibold text-green-600">Compliance Score</span>
                          </div>
                          <div className="text-xl font-bold text-green-600">{facility.complianceScore}%</div>
                        </div>
                      </div>
                    </div>

                    {/* Facility Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Location</h4>
                        <p className="text-gray-700">
                          {facility.contactInfo.address}<br />
                          {facility.contactInfo.city}, {facility.contactInfo.state} {facility.contactInfo.zipCode}
                        </p>
                        
                        <h4 className="font-semibold text-gray-900 mt-3 mb-2">Contact Person</h4>
                        <p className="text-gray-700">
                          {facility.contactInfo.contactPerson.name}<br />
                          {facility.contactInfo.contactPerson.title}<br />
                          {facility.contactInfo.contactPerson.email}
                        </p>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Operational Info</h4>
                        <div className="space-y-1 text-sm text-gray-700">
                          {facility.operationalInfo.bedCount && (
                            <div>Bed Count: {facility.operationalInfo.bedCount}</div>
                          )}
                          <div>Hours: {facility.operationalInfo.operatingHours}</div>
                          <div>Emergency Services: {facility.operationalInfo.emergencyServices ? 'Yes' : 'No'}</div>
                          {facility.operationalInfo.traumaLevel && (
                            <div>Trauma Level: {facility.operationalInfo.traumaLevel}</div>
                          )}
                        </div>
                        
                        <h4 className="font-semibold text-gray-900 mt-3 mb-2">Departments</h4>
                        <div className="flex flex-wrap gap-1">
                          {facility.operationalInfo.departments.slice(0, 4).map((dept, index) => (
                            <Badge key={index} className="bg-blue-100 text-blue-800 border-blue-200 text-xs">
                              {dept}
                            </Badge>
                          ))}
                          {facility.operationalInfo.departments.length > 4 && (
                            <Badge className="bg-gray-100 text-gray-800 border-gray-200 text-xs">
                              +{facility.operationalInfo.departments.length - 4} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Credentials */}
                    <div className="mb-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Credentials & Licenses ({facility.credentials.length})</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {facility.credentials.map((credential, index) => (
                          <div key={index} className="p-3 border rounded-lg">
                            <div className="flex items-start justify-between mb-2">
                              <h5 className="font-medium text-gray-900 text-sm">{credential.type}</h5>
                              <Badge className={getStatusColor(credential.status)} size="sm">
                                {credential.status}
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-600 mb-1">
                              {credential.issuingOrganization}
                            </p>
                            <p className="text-xs text-gray-600 mb-2">
                              Expires: {new Date(credential.expiryDate).toLocaleDateString()}
                            </p>
                            <div className="flex gap-1">
                              <Button variant="ghost" size="sm" className="text-xs h-6">
                                <Eye className="w-3 h-3 mr-1" />
                                View
                              </Button>
                              {credential.status === 'pending' && (
                                <>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => handleCredentialVerification(facility.id, index, 'verified')}
                                    className="text-green-600 text-xs h-6"
                                  >
                                    <CheckCircle className="w-3 h-3 mr-1" />
                                    Verify
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => handleCredentialVerification(facility.id, index, 'rejected')}
                                    className="text-red-600 text-xs h-6"
                                  >
                                    <XCircle className="w-3 h-3 mr-1" />
                                    Reject
                                  </Button>
                                </>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Insurance */}
                    <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Professional Liability Insurance</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Provider:</span>
                          <span className="font-medium ml-2">{facility.insurance.provider}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Policy:</span>
                          <span className="font-medium ml-2">{facility.insurance.policyNumber}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Coverage:</span>
                          <span className="font-medium ml-2">{facility.insurance.coverage}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Expires:</span>
                          <span className="font-medium ml-2">
                            {new Date(facility.insurance.expiryDate).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                      <div className="text-sm text-gray-500">
                        Applied: {new Date(facility.applicationDate).toLocaleDateString()}
                      </div>
                      
                      {facility.status === 'pending' && (
                        <div className="flex items-center gap-2">
                          <Button 
                            variant="outline"
                            onClick={() => setSelectedFacility(facility)}
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            Full Review
                          </Button>
                          <Button 
                            onClick={() => handleStatusChange(facility.id, 'approved')}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                          <Button 
                            variant="destructive"
                            onClick={() => {
                              const notes = prompt('Please provide rejection reason:');
                              if (notes) handleStatusChange(facility.id, 'rejected', notes);
                            }}
                          >
                            <XCircle className="w-4 h-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredFacilities.length === 0 && (
            <div className="text-center py-12">
              <Building2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No Applications Found</h3>
              <p className="text-gray-500">
                Try adjusting your search criteria or filters.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
