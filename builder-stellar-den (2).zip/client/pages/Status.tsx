import { Link } from "react-router-dom";
import {
  Brain,
  CheckCircle2,
  AlertCircle,
  Clock,
  Activity,
  Server,
  Database,
  Zap,
  Shield,
  Globe,
  ArrowLeft,
} from "lucide-react";

export default function Status() {
  const systemServices = [
    {
      name: "API Services",
      status: "operational",
      uptime: "99.98%",
      responseTime: "145ms",
      icon: Server,
    },
    {
      name: "Database",
      status: "operational",
      uptime: "99.95%",
      responseTime: "8ms",
      icon: Database,
    },
    {
      name: "AI Matching Engine",
      status: "operational",
      uptime: "99.99%",
      responseTime: "230ms",
      icon: Zap,
    },
    {
      name: "Authentication",
      status: "operational",
      uptime: "99.97%",
      responseTime: "65ms",
      icon: Shield,
    },
    {
      name: "File Storage",
      status: "degraded",
      uptime: "98.2%",
      responseTime: "890ms",
      icon: Database,
    },
    {
      name: "Notifications",
      status: "operational",
      uptime: "99.94%",
      responseTime: "120ms",
      icon: Activity,
    },
  ];

  const recentIncidents = [
    {
      title: "File upload slowdown resolved",
      description: "Temporary slowdown in document uploads has been resolved.",
      date: "Dec 12, 2024 - 14:30 PST",
      status: "resolved",
    },
    {
      title: "Scheduled maintenance completed",
      description: "Routine database maintenance completed successfully.",
      date: "Dec 10, 2024 - 02:00 PST",
      status: "resolved",
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "operational":
        return "text-green-600 bg-green-100";
      case "degraded":
        return "text-yellow-600 bg-yellow-100";
      case "outage":
        return "text-red-600 bg-red-100";
      default:
        return "text-gray-600 bg-gray-100";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "operational":
        return CheckCircle2;
      case "degraded":
        return AlertCircle;
      case "outage":
        return AlertCircle;
      default:
        return Clock;
    }
  };

  const overallStatus = systemServices.every(service => service.status === "operational") 
    ? "operational" 
    : systemServices.some(service => service.status === "outage")
    ? "outage"
    : "degraded";

  return (
    <div className="min-h-screen bg-gradient-to-br from-medical-gray via-white to-blue-50">
      {/* Header */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            <Link
              to="/"
              className="text-gray-600 hover:text-medical-blue transition-colors font-body"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back Link */}
        <Link
          to="/"
          className="inline-flex items-center text-medical-blue hover:text-blue-700 font-medium mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        {/* Page Header */}
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Activity className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
            System Status
          </h1>
          <p className="text-xl text-gray-600 font-body">
            Real-time status and performance of ProLinkAi services
          </p>
        </div>

        {/* Overall Status */}
        <div className={`rounded-2xl p-8 mb-8 ${overallStatus === 'operational' ? 'bg-green-50 border-2 border-green-200' : overallStatus === 'degraded' ? 'bg-yellow-50 border-2 border-yellow-200' : 'bg-red-50 border-2 border-red-200'}`}>
          <div className="flex items-center justify-center">
            {overallStatus === 'operational' ? (
              <CheckCircle2 className="w-8 h-8 text-green-600 mr-3" />
            ) : (
              <AlertCircle className="w-8 h-8 text-yellow-600 mr-3" />
            )}
            <div className="text-center">
              <h2 className={`text-2xl font-header font-bold ${overallStatus === 'operational' ? 'text-green-900' : 'text-yellow-900'}`}>
                {overallStatus === 'operational' ? 'All Systems Operational' : 'Some Systems Degraded'}
              </h2>
              <p className={`${overallStatus === 'operational' ? 'text-green-700' : 'text-yellow-700'}`}>
                {overallStatus === 'operational' 
                  ? 'ProLinkAi is running smoothly across all services'
                  : 'Some services are experiencing issues. We are working to resolve them.'
                }
              </p>
            </div>
          </div>
        </div>

        {/* Service Status */}
        <div className="bg-white rounded-2xl shadow-card border border-gray-200 mb-8">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-xl font-header font-bold text-gray-900">Service Status</h3>
          </div>
          <div className="divide-y divide-gray-200">
            {systemServices.map((service, index) => {
              const StatusIcon = getStatusIcon(service.status);
              return (
                <div key={index} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center mr-4">
                        <service.icon className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{service.name}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                          <span>Uptime: {service.uptime}</span>
                          <span>Response: {service.responseTime}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(service.status)}`}>
                        <StatusIcon className="w-4 h-4 mr-1" />
                        {service.status.charAt(0).toUpperCase() + service.status.slice(1)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Incidents */}
        <div className="bg-white rounded-2xl shadow-card border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-xl font-header font-bold text-gray-900">Recent Incidents</h3>
          </div>
          <div className="divide-y divide-gray-200">
            {recentIncidents.length > 0 ? (
              recentIncidents.map((incident, index) => (
                <div key={index} className="p-6">
                  <div className="flex items-start">
                    <CheckCircle2 className="w-5 h-5 text-green-600 mr-3 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 mb-1">{incident.title}</h4>
                      <p className="text-gray-600 text-sm mb-2">{incident.description}</p>
                      <p className="text-xs text-gray-500">{incident.date}</p>
                    </div>
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                      Resolved
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-6 text-center text-gray-500">
                <Globe className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No recent incidents to report</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-8 text-center text-sm text-gray-600">
          <p>
            Status updates are refreshed every 30 seconds. For real-time support, contact our team at{" "}
            <a href="mailto:support@prolinkAi.com" className="text-medical-blue hover:text-blue-700">
              support@prolinkAi.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
