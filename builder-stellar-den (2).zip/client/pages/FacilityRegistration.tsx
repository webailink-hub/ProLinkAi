import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Brain,
  ArrowLeft,
  Building2,
  Mail,
  Lock,
  Phone,
  MapPin,
  FileText,
  Users,
  Calendar,
  Upload,
  CheckCircle2,
  Eye,
  EyeOff,
  BarChart3,
  DollarSign,
  Clock,
  Shield,
} from "lucide-react";

interface FormData {
  // Facility Information
  facilityName: string;
  facilityType: string;
  licenseNumber: string;
  bedCount: string;
  website: string;

  // Address
  address: string;
  city: string;
  state: string;
  zipCode: string;

  // Contact Information
  primaryContactName: string;
  primaryContactTitle: string;
  primaryContactEmail: string;
  primaryContactPhone: string;

  // Staffing Needs
  departmentsNeeded: string[];
  staffingVolume: string;
  urgentNeeds: string;

  // Account
  password: string;
  confirmPassword: string;

  // Agreements
  termsAccepted: boolean;
  newsletterOptIn: boolean;
}

export default function FacilityRegistration() {
  const [currentStep, setCurrentStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    facilityName: "",
    facilityType: "",
    licenseNumber: "",
    bedCount: "",
    website: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    primaryContactName: "",
    primaryContactTitle: "",
    primaryContactEmail: "",
    primaryContactPhone: "",
    departmentsNeeded: [],
    staffingVolume: "",
    urgentNeeds: "",
    password: "",
    confirmPassword: "",
    termsAccepted: false,
    newsletterOptIn: false,
  });

  const totalSteps = 3;

  const facilityTypes = [
    "Acute Care Hospital",
    "Critical Access Hospital",
    "Specialty Hospital",
    "Rehabilitation Hospital",
    "Long-term Care Facility",
    "Skilled Nursing Facility",
    "Assisted Living",
    "Outpatient Surgery Center",
    "Clinic/Medical Group",
    "Home Health Agency",
    "Hospice",
    "Other",
  ];

  const departmentOptions = [
    "ICU/Critical Care",
    "Emergency Department",
    "Medical-Surgical",
    "Operating Room",
    "Post-Anesthesia Care",
    "Labor & Delivery",
    "NICU",
    "Pediatrics",
    "Oncology",
    "Cardiology",
    "Orthopedics",
    "Psychiatry",
    "Rehabilitation",
    "Telemetry",
    "Step-Down Unit",
    "Dialysis",
  ];

  const volumeOptions = [
    "1-10 shifts per month",
    "11-25 shifts per month",
    "26-50 shifts per month",
    "51-100 shifts per month",
    "100+ shifts per month",
  ];

  const bedCountOptions = [
    "Under 25 beds",
    "25-50 beds",
    "51-100 beds",
    "101-200 beds",
    "201-400 beds",
    "400+ beds",
  ];

  const handleInputChange = (
    field: keyof FormData,
    value: string | boolean | string[],
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleDepartmentToggle = (department: string) => {
    const updatedDepartments = formData.departmentsNeeded.includes(department)
      ? formData.departmentsNeeded.filter((d) => d !== department)
      : [...formData.departmentsNeeded, department];
    handleInputChange("departmentsNeeded", updatedDepartments);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Facility registration data:", formData);
    // Handle registration logic
  };

  const nextStep = () => {
    if (currentStep < totalSteps) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-medical-gray via-white to-blue-50">
      {/* Header */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            <Link
              to="/login"
              className="text-gray-600 hover:text-medical-blue transition-colors font-body"
            >
              Already have an account? Sign in
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back button */}
        <Link
          to="/register"
          className="inline-flex items-center text-medical-blue hover:text-blue-700 font-medium mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Registration Hub
        </Link>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-gradient-to-br from-medical-green to-medical-teal rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Building2 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
            Join 500+ Leading Healthcare Facilities
          </h1>
          <p className="text-xl text-gray-600 font-body max-w-2xl mx-auto">
            Transform your staffing operations with AI-powered solutions,
            predictive analytics, and access to thousands of qualified
            professionals.
          </p>
        </div>

        {/* Progress indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-center">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step <= currentStep
                      ? "bg-medical-green text-white"
                      : "bg-gray-200 text-gray-600"
                  }`}
                >
                  {step < currentStep ? (
                    <CheckCircle2 className="w-5 h-5" />
                  ) : (
                    step
                  )}
                </div>
                {step < 3 && (
                  <div
                    className={`w-16 h-1 mx-2 ${
                      step < currentStep ? "bg-medical-green" : "bg-gray-200"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-center mt-2 text-sm text-gray-600">
            <span>
              Step {currentStep} of {totalSteps}
            </span>
          </div>
        </div>

        {/* Form */}
        <div className="bg-white rounded-2xl shadow-card border border-gray-200 p-8">
          <form onSubmit={handleSubmit}>
            {currentStep === 1 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-header font-bold text-gray-900 mb-6">
                  Facility Information
                </h2>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Facility Name *
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      required
                      value={formData.facilityName}
                      onChange={(e) =>
                        handleInputChange("facilityName", e.target.value)
                      }
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                      placeholder="Enter facility name"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Facility Type *
                    </label>
                    <select
                      required
                      value={formData.facilityType}
                      onChange={(e) =>
                        handleInputChange("facilityType", e.target.value)
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                    >
                      <option value="">Select facility type</option>
                      {facilityTypes.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Bed Count
                    </label>
                    <select
                      value={formData.bedCount}
                      onChange={(e) =>
                        handleInputChange("bedCount", e.target.value)
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                    >
                      <option value="">Select bed count</option>
                      {bedCountOptions.map((count) => (
                        <option key={count} value={count}>
                          {count}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      License Number *
                    </label>
                    <div className="relative">
                      <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        required
                        value={formData.licenseNumber}
                        onChange={(e) =>
                          handleInputChange("licenseNumber", e.target.value)
                        }
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                        placeholder="Facility license number"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Website
                    </label>
                    <input
                      type="url"
                      value={formData.website}
                      onChange={(e) =>
                        handleInputChange("website", e.target.value)
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                      placeholder="https://yourfacility.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Address *
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) =>
                        handleInputChange("address", e.target.value)
                      }
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                      placeholder="Street address"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      City *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.city}
                      onChange={(e) =>
                        handleInputChange("city", e.target.value)
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                      placeholder="City"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      State *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.state}
                      onChange={(e) =>
                        handleInputChange("state", e.target.value)
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                      placeholder="State"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      ZIP Code *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.zipCode}
                      onChange={(e) =>
                        handleInputChange("zipCode", e.target.value)
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                      placeholder="ZIP"
                    />
                  </div>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-header font-bold text-gray-900 mb-6">
                  Primary Contact & Staffing Needs
                </h2>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Contact Name *
                    </label>
                    <div className="relative">
                      <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        required
                        value={formData.primaryContactName}
                        onChange={(e) =>
                          handleInputChange(
                            "primaryContactName",
                            e.target.value,
                          )
                        }
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                        placeholder="Primary contact name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Contact Title *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.primaryContactTitle}
                      onChange={(e) =>
                        handleInputChange("primaryContactTitle", e.target.value)
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                      placeholder="Job title"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Contact Email *
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="email"
                        required
                        value={formData.primaryContactEmail}
                        onChange={(e) =>
                          handleInputChange(
                            "primaryContactEmail",
                            e.target.value,
                          )
                        }
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                        placeholder="Contact email"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Contact Phone *
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="tel"
                        required
                        value={formData.primaryContactPhone}
                        onChange={(e) =>
                          handleInputChange(
                            "primaryContactPhone",
                            e.target.value,
                          )
                        }
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                        placeholder="(555) 123-4567"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-4">
                    Departments Needing Staffing (Select all that apply) *
                  </label>
                  <div className="grid md:grid-cols-3 gap-3">
                    {departmentOptions.map((department) => (
                      <label
                        key={department}
                        className={`flex items-center p-3 rounded-lg border cursor-pointer transition-colors ${
                          formData.departmentsNeeded.includes(department)
                            ? "border-medical-green bg-medical-green/5"
                            : "border-gray-300 hover:border-gray-400"
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={formData.departmentsNeeded.includes(
                            department,
                          )}
                          onChange={() => handleDepartmentToggle(department)}
                          className="w-4 h-4 text-medical-green border-gray-300 rounded focus:ring-medical-green"
                        />
                        <span className="ml-2 text-sm font-body">
                          {department}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Expected Monthly Staffing Volume *
                  </label>
                  <select
                    required
                    value={formData.staffingVolume}
                    onChange={(e) =>
                      handleInputChange("staffingVolume", e.target.value)
                    }
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                  >
                    <option value="">Select expected volume</option>
                    {volumeOptions.map((volume) => (
                      <option key={volume} value={volume}>
                        {volume}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Immediate Staffing Needs
                  </label>
                  <textarea
                    value={formData.urgentNeeds}
                    onChange={(e) =>
                      handleInputChange("urgentNeeds", e.target.value)
                    }
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                    placeholder="Describe any urgent or specific staffing needs..."
                  />
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-header font-bold text-gray-900 mb-6">
                  Account Security
                </h2>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Password *
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={formData.password}
                      onChange={(e) =>
                        handleInputChange("password", e.target.value)
                      }
                      className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                      placeholder="Create a strong password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? (
                        <EyeOff className="w-5 h-5" />
                      ) : (
                        <Eye className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Confirm Password *
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type={showConfirmPassword ? "text" : "password"}
                      required
                      value={formData.confirmPassword}
                      onChange={(e) =>
                        handleInputChange("confirmPassword", e.target.value)
                      }
                      className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-green focus:border-transparent font-body"
                      placeholder="Confirm your password"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="w-5 h-5" />
                      ) : (
                        <Eye className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="flex items-start">
                    <input
                      type="checkbox"
                      required
                      checked={formData.termsAccepted}
                      onChange={(e) =>
                        handleInputChange("termsAccepted", e.target.checked)
                      }
                      className="w-4 h-4 text-medical-green border-gray-300 rounded focus:ring-medical-green mt-1"
                    />
                    <span className="ml-3 text-sm text-gray-600 font-body">
                      I agree to the{" "}
                      <Link
                        to="/terms"
                        className="text-medical-green hover:text-green-700"
                      >
                        Terms of Service
                      </Link>{" "}
                      and{" "}
                      <Link
                        to="/privacy"
                        className="text-medical-green hover:text-green-700"
                      >
                        Privacy Policy
                      </Link>
                      *
                    </span>
                  </label>

                  <label className="flex items-start">
                    <input
                      type="checkbox"
                      checked={formData.newsletterOptIn}
                      onChange={(e) =>
                        handleInputChange("newsletterOptIn", e.target.checked)
                      }
                      className="w-4 h-4 text-medical-green border-gray-300 rounded focus:ring-medical-green mt-1"
                    />
                    <span className="ml-3 text-sm text-gray-600 font-body">
                      Send me updates about platform features and industry
                      insights
                    </span>
                  </label>
                </div>

                {/* Benefits preview */}
                <div className="bg-gradient-to-br from-medical-green/10 to-medical-teal/10 rounded-xl p-6 mt-8">
                  <h3 className="text-lg font-header font-semibold text-gray-900 mb-4">
                    Your ProLinkAi Advantages
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-center">
                      <BarChart3 className="w-5 h-5 text-medical-green mr-3" />
                      <span className="text-gray-700 font-body">
                        50% faster shift filling
                      </span>
                    </div>
                    <div className="flex items-center">
                      <DollarSign className="w-5 h-5 text-medical-teal mr-3" />
                      <span className="text-gray-700 font-body">
                        35% cost reduction
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-5 h-5 text-ai-purple mr-3" />
                      <span className="text-gray-700 font-body">
                        2.3h average fill time
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Shield className="w-5 h-5 text-medical-blue mr-3" />
                      <span className="text-gray-700 font-body">
                        100% compliance assurance
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation buttons */}
            <div className="flex justify-between pt-8 mt-8 border-t border-gray-200">
              <button
                type="button"
                onClick={prevStep}
                disabled={currentStep === 1}
                className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                  currentStep === 1
                    ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Previous
              </button>

              {currentStep < totalSteps ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="bg-gradient-to-r from-medical-green to-medical-teal text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-teal-600 transition-all duration-200 font-medium shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5"
                >
                  Next Step
                </button>
              ) : (
                <button
                  type="submit"
                  className="bg-gradient-to-r from-medical-green to-medical-teal text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-teal-600 transition-all duration-200 font-medium shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5"
                >
                  Create Account
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
