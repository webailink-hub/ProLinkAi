import React, { useState } from 'react';
import { Search, Send, Paperclip, Smile, MoreVertical, Phone, Video, Archive, Star, Trash2, Brain, Languages, Shield, Clock, Check, CheckCheck } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';

interface Message {
  id: string;
  content: string;
  timestamp: string;
  sender: 'user' | 'other';
  status: 'sent' | 'delivered' | 'read';
  translated?: boolean;
  aiSuggestion?: string;
}

interface Conversation {
  id: string;
  name: string;
  avatar: string;
  role: string;
  facility?: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  isOnline: boolean;
  messages: Message[];
}

export default function Messages() {
  const [selectedConversation, setSelectedConversation] = useState<string>('1');
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAiSuggestions, setShowAiSuggestions] = useState(true);
  const [enableTranslation, setEnableTranslation] = useState(true);

  const conversations: Conversation[] = [
    {
      id: '1',
      name: 'Maria Rodriguez',
      avatar: '/api/placeholder/40/40',
      role: 'Facility Coordinator',
      facility: 'SF General Hospital',
      lastMessage: 'Thanks for confirming the shift tomorrow!',
      lastMessageTime: '2 min ago',
      unreadCount: 0,
      isOnline: true,
      messages: [
        {
          id: '1',
          content: 'Hi Sarah! We have an urgent shift opening tomorrow from 7 AM - 7 PM in the ICU. Are you available?',
          timestamp: '10:30 AM',
          sender: 'other',
          status: 'read'
        },
        {
          id: '2',
          content: 'Yes, I can take that shift! I have experience in ICU and my credentials are up to date.',
          timestamp: '10:32 AM',
          sender: 'user',
          status: 'read'
        },
        {
          id: '3',
          content: 'Perfect! The rate is $45/hour with overtime after 8 hours. Please confirm if this works for you.',
          timestamp: '10:35 AM',
          sender: 'other',
          status: 'read'
        },
        {
          id: '4',
          content: 'That sounds great! I confirm my availability for tomorrow 7 AM - 7 PM in ICU.',
          timestamp: '10:37 AM',
          sender: 'user',
          status: 'delivered',
          aiSuggestion: 'AI suggested adding confirmation details'
        },
        {
          id: '5',
          content: 'Thanks for confirming the shift tomorrow!',
          timestamp: '10:40 AM',
          sender: 'other',
          status: 'read'
        }
      ]
    },
    {
      id: '2',
      name: 'Dr. James Chen',
      avatar: '/api/placeholder/40/40',
      role: 'Chief of Nursing',
      facility: 'Stanford Medical',
      lastMessage: 'Your performance review is scheduled...',
      lastMessageTime: '1 hour ago',
      unreadCount: 2,
      isOnline: false,
      messages: [
        {
          id: '1',
          content: 'Hi Sarah, I wanted to follow up on your recent shifts with us.',
          timestamp: '9:15 AM',
          sender: 'other',
          status: 'read'
        },
        {
          id: '2',
          content: 'Your performance review is scheduled for next week. Please let me know your availability.',
          timestamp: '9:20 AM',
          sender: 'other',
          status: 'delivered'
        }
      ]
    },
    {
      id: '3',
      name: 'Lisa Park',
      avatar: '/api/placeholder/40/40',
      role: 'HR Manager',
      facility: 'UCSF Medical Center',
      lastMessage: 'Welcome to our team!',
      lastMessageTime: '3 hours ago',
      unreadCount: 1,
      isOnline: true,
      messages: [
        {
          id: '1',
          content: 'Welcome to our team! We\'re excited to have you join us for upcoming shifts.',
          timestamp: '8:00 AM',
          sender: 'other',
          status: 'delivered'
        }
      ]
    }
  ];

  const aiSuggestions = [
    "I'm available for that shift",
    "Could you provide more details about the requirements?",
    "Thank you for considering me",
    "I need to check my schedule first"
  ];

  const activeConversation = conversations.find(c => c.id === selectedConversation);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    // In a real app, this would send the message via API
    console.log('Sending message:', newMessage);
    setNewMessage('');
  };

  const handleUseSuggestion = (suggestion: string) => {
    setNewMessage(suggestion);
  };

  const filteredConversations = conversations.filter(conv =>
    conv.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    conv.facility?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-[calc(100vh-2rem)] flex">
      {/* Conversations Sidebar */}
      <div className="w-1/3 border-r border-gray-200 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent">
              Messages
            </h1>
            <Badge className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 text-ai-purple border-ai-purple/20">
              AI Enhanced
            </Badge>
          </div>
          
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search conversations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* AI Features Panel */}
        <div className="p-4 bg-gradient-to-r from-ai-purple/5 to-medical-teal/5 border-b border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-4 h-4 text-ai-purple" />
            <span className="text-sm font-semibold text-ai-purple">AI Features</span>
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant={showAiSuggestions ? "default" : "outline"}
              onClick={() => setShowAiSuggestions(!showAiSuggestions)}
              className="text-xs"
            >
              <Brain className="w-3 h-3 mr-1" />
              Smart Replies
            </Button>
            <Button
              size="sm"
              variant={enableTranslation ? "default" : "outline"}
              onClick={() => setEnableTranslation(!enableTranslation)}
              className="text-xs"
            >
              <Languages className="w-3 h-3 mr-1" />
              Translate
            </Button>
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {filteredConversations.map((conversation) => (
            <div
              key={conversation.id}
              onClick={() => setSelectedConversation(conversation.id)}
              className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${
                selectedConversation === conversation.id ? 'bg-medical-blue/5 border-l-4 border-l-medical-blue' : ''
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="relative">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={conversation.avatar} />
                    <AvatarFallback className="bg-gradient-to-br from-medical-blue to-ai-purple text-white text-sm">
                      {conversation.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  {conversation.isOnline && (
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-semibold text-gray-900 truncate">{conversation.name}</h3>
                    <span className="text-xs text-gray-500">{conversation.lastMessageTime}</span>
                  </div>
                  
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm text-medical-blue">{conversation.role}</p>
                    {conversation.unreadCount > 0 && (
                      <Badge className="bg-medical-blue text-white text-xs">
                        {conversation.unreadCount}
                      </Badge>
                    )}
                  </div>
                  
                  <p className="text-sm text-gray-600">{conversation.facility}</p>
                  <p className="text-sm text-gray-500 truncate mt-1">{conversation.lastMessage}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {activeConversation ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-200 bg-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={activeConversation.avatar} />
                      <AvatarFallback className="bg-gradient-to-br from-medical-blue to-ai-purple text-white">
                        {activeConversation.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    {activeConversation.isOnline && (
                      <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                    )}
                  </div>
                  
                  <div>
                    <h2 className="font-semibold text-gray-900">{activeConversation.name}</h2>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <span>{activeConversation.role}</span>
                      <span>•</span>
                      <span>{activeConversation.facility}</span>
                      {activeConversation.isOnline && (
                        <>
                          <span>•</span>
                          <span className="text-green-600">Online</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm">
                    <Phone className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Video className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {activeConversation.messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                      message.sender === 'user'
                        ? 'bg-gradient-to-r from-medical-blue to-ai-purple text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-1 text-xs opacity-70">
                        <Clock className="w-3 h-3" />
                        <span>{message.timestamp}</span>
                        {message.translated && enableTranslation && (
                          <>
                            <Languages className="w-3 h-3 ml-1" />
                            <span>Translated</span>
                          </>
                        )}
                      </div>
                      
                      {message.sender === 'user' && (
                        <div className="flex items-center">
                          {message.status === 'sent' && <Check className="w-3 h-3" />}
                          {message.status === 'delivered' && <CheckCheck className="w-3 h-3" />}
                          {message.status === 'read' && <CheckCheck className="w-3 h-3 text-blue-300" />}
                        </div>
                      )}
                    </div>
                    
                    {message.aiSuggestion && (
                      <div className="mt-2 p-2 bg-white/20 rounded text-xs">
                        <div className="flex items-center gap-1 mb-1">
                          <Brain className="w-3 h-3" />
                          <span>AI Insight</span>
                        </div>
                        <span>{message.aiSuggestion}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* AI Suggestions */}
            {showAiSuggestions && (
              <div className="px-4 py-2 bg-gradient-to-r from-ai-purple/5 to-medical-teal/5 border-t border-gray-200">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="w-4 h-4 text-ai-purple" />
                  <span className="text-sm font-medium text-ai-purple">Smart Replies</span>
                </div>
                <div className="flex gap-2 flex-wrap">
                  {aiSuggestions.map((suggestion, index) => (
                    <button
                      key={index}
                      onClick={() => handleUseSuggestion(suggestion)}
                      className="px-3 py-1 text-xs bg-white border border-ai-purple/20 rounded-full hover:bg-ai-purple/5 transition-colors"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Message Input */}
            <div className="p-4 border-t border-gray-200 bg-white">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm">
                  <Paperclip className="w-4 h-4" />
                </Button>
                
                <div className="flex-1 relative">
                  <Input
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="pr-10"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute right-1 top-1/2 transform -translate-y-1/2"
                  >
                    <Smile className="w-4 h-4" />
                  </Button>
                </div>
                
                <Button 
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim()}
                  className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <Shield className="w-3 h-3" />
                    <span>End-to-end encrypted</span>
                  </div>
                  {enableTranslation && (
                    <div className="flex items-center gap-1">
                      <Languages className="w-3 h-3" />
                      <span>Auto-translate enabled</span>
                    </div>
                  )}
                </div>
                <span>Press Enter to send</span>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Select a conversation
              </h3>
              <p className="text-gray-600">
                Choose a conversation from the sidebar to start messaging
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
