import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Award,
  FileText,
  Upload,
  Download,
  Eye,
  Edit3,
  CheckCircle2,
  AlertCircle,
  Clock,
  Calendar,
  Bell,
  Plus,
  Trash2,
  RefreshCw,
  Zap,
  Brain,
  TrendingUp,
  BookOpen,
  ExternalLink,
  Star,
  Shield,
  AlertTriangle,
  Search,
  Filter,
  MoreHorizontal,
} from "lucide-react";

interface Credential {
  id: string;
  type: string;
  name: string;
  issuingOrganization: string;
  issueDate: string;
  expiryDate: string;
  status: "verified" | "pending" | "expired" | "expiring_soon" | "rejected";
  documentUrl?: string;
  credentialNumber?: string;
  category: "license" | "certification" | "education" | "other";
  isRequired: boolean;
  verifiedBy?: string;
  verifiedDate?: string;
  notes?: string;
  remindersSent: number;
  nextReminderDate?: string;
  renewalInstructions?: string;
}

interface CERecommendation {
  id: string;
  title: string;
  provider: string;
  hours: number;
  category: string;
  deadline: string;
  relevantCredentials: string[];
  difficulty: "beginner" | "intermediate" | "advanced";
  format: "online" | "in_person" | "hybrid";
  cost: number;
  rating: number;
}

export default function MyCredentials() {
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCredential, setSelectedCredential] = useState<Credential | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showCERecommendations, setShowCERecommendations] = useState(false);

  // Mock data - in real app this would come from API
  const credentials: Credential[] = [
    {
      id: "1",
      type: "RN License",
      name: "Registered Nurse License",
      issuingOrganization: "California Board of Registered Nursing",
      issueDate: "Jan 15, 2020",
      expiryDate: "Dec 31, 2024",
      status: "verified",
      credentialNumber: "RN-CA-123456",
      category: "license",
      isRequired: true,
      verifiedBy: "ProLinkAi Verification Team",
      verifiedDate: "Mar 1, 2024",
      remindersSent: 0,
      renewalInstructions: "Complete 30 hours of continuing education and submit renewal application 60 days before expiry.",
    },
    {
      id: "2",
      type: "BLS Certification",
      name: "Basic Life Support",
      issuingOrganization: "American Heart Association",
      issueDate: "Jun 10, 2022",
      expiryDate: "Jun 10, 2024",
      status: "expiring_soon",
      credentialNumber: "BLS-AHA-789012",
      category: "certification",
      isRequired: true,
      verifiedBy: "ProLinkAi Verification Team",
      verifiedDate: "Jun 15, 2022",
      remindersSent: 2,
      nextReminderDate: "May 10, 2024",
      renewalInstructions: "Attend BLS recertification class or complete online renewal course.",
    },
    {
      id: "3",
      type: "ACLS Certification",
      name: "Advanced Cardiovascular Life Support",
      issuingOrganization: "American Heart Association",
      issueDate: "Aug 5, 2023",
      expiryDate: "Aug 5, 2025",
      status: "verified",
      credentialNumber: "ACLS-AHA-345678",
      category: "certification",
      isRequired: true,
      verifiedBy: "ProLinkAi Verification Team",
      verifiedDate: "Aug 10, 2023",
      remindersSent: 0,
      renewalInstructions: "Complete ACLS renewal course 90 days before expiry.",
    },
    {
      id: "4",
      type: "BSN Degree",
      name: "Bachelor of Science in Nursing",
      issuingOrganization: "University of California, San Francisco",
      issueDate: "May 20, 2019",
      expiryDate: "N/A",
      status: "verified",
      category: "education",
      isRequired: false,
      verifiedBy: "ProLinkAi Verification Team",
      verifiedDate: "Feb 1, 2024",
      remindersSent: 0,
    },
    {
      id: "5",
      type: "CCRN Certification",
      name: "Critical Care Registered Nurse",
      issuingOrganization: "AACN Certification Corporation",
      issueDate: "Nov 12, 2021",
      expiryDate: "Nov 12, 2024",
      status: "pending",
      credentialNumber: "CCRN-456789",
      category: "certification",
      isRequired: false,
      remindersSent: 0,
      notes: "Renewal application submitted, awaiting verification",
    },
    {
      id: "6",
      type: "PALS Certification",
      name: "Pediatric Advanced Life Support",
      issuingOrganization: "American Heart Association",
      issueDate: "Mar 8, 2022",
      expiryDate: "Mar 8, 2024",
      status: "expired",
      credentialNumber: "PALS-AHA-567890",
      category: "certification",
      isRequired: false,
      remindersSent: 3,
      renewalInstructions: "Schedule PALS recertification class immediately.",
    },
  ];

  const ceRecommendations: CERecommendation[] = [
    {
      id: "1",
      title: "Advanced ICU Care and Ventilator Management",
      provider: "Nursing Education Institute",
      hours: 8,
      category: "Critical Care",
      deadline: "Dec 15, 2024",
      relevantCredentials: ["RN License", "CCRN Certification"],
      difficulty: "advanced",
      format: "online",
      cost: 199,
      rating: 4.8,
    },
    {
      id: "2",
      title: "Pain Management in Critical Care",
      provider: "American Association of Critical-Care Nurses",
      hours: 4,
      category: "Pain Management",
      deadline: "Nov 30, 2024",
      relevantCredentials: ["RN License"],
      difficulty: "intermediate",
      format: "hybrid",
      cost: 125,
      rating: 4.6,
    },
    {
      id: "3",
      title: "Emergency Response and Trauma Care",
      provider: "Emergency Nurses Association",
      hours: 6,
      category: "Emergency Care",
      deadline: "Oct 31, 2024",
      relevantCredentials: ["BLS Certification", "ACLS Certification"],
      difficulty: "intermediate",
      format: "in_person",
      cost: 175,
      rating: 4.9,
    },
  ];

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      verified: { bg: "bg-green-100", text: "text-green-800", icon: CheckCircle2, label: "Verified" },
      pending: { bg: "bg-yellow-100", text: "text-yellow-800", icon: Clock, label: "Pending" },
      expired: { bg: "bg-red-100", text: "text-red-800", icon: AlertCircle, label: "Expired" },
      expiring_soon: { bg: "bg-orange-100", text: "text-orange-800", icon: AlertTriangle, label: "Expiring Soon" },
      rejected: { bg: "bg-red-100", text: "text-red-800", icon: AlertCircle, label: "Rejected" },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig];
    const IconComponent = config.icon;
    
    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        <IconComponent className="w-3 h-3 mr-1" />
        {config.label}
      </span>
    );
  };

  const getDaysUntilExpiry = (expiryDate: string) => {
    if (expiryDate === "N/A") return null;
    const expiry = new Date(expiryDate);
    const today = new Date();
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const filteredCredentials = credentials.filter(credential => {
    const matchesSearch = credential.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         credential.issuingOrganization.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTab = activeTab === "all" || 
                      (activeTab === "required" && credential.isRequired) ||
                      (activeTab === "expiring" && ["expired", "expiring_soon"].includes(credential.status)) ||
                      credential.category === activeTab;
    return matchesSearch && matchesTab;
  });

  const statusCounts = {
    all: credentials.length,
    required: credentials.filter(c => c.isRequired).length,
    expiring: credentials.filter(c => ["expired", "expiring_soon"].includes(c.status)).length,
    license: credentials.filter(c => c.category === "license").length,
    certification: credentials.filter(c => c.category === "certification").length,
    education: credentials.filter(c => c.category === "education").length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-header font-bold text-gray-900 flex items-center">
            <Award className="w-8 h-8 mr-3 text-medical-blue" />
            Licenses & Certifications
          </h1>
          <p className="text-gray-600 font-body mt-2">
            AI-assisted credential management with automatic renewal reminders
          </p>
        </div>

        <div className="flex items-center gap-3 mt-4 lg:mt-0">
          <button 
            onClick={() => setShowUploadModal(true)}
            className="bg-medical-blue text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Credential
          </button>
          <button 
            onClick={() => setShowCERecommendations(true)}
            className="bg-ai-purple text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center font-medium"
          >
            <Brain className="w-4 h-4 mr-2" />
            CE Recommendations
          </button>
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-br from-ai-purple to-medical-blue rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Zap className="w-6 h-6 mr-3" />
            <h2 className="text-xl font-header font-bold">AI Credential Insights</h2>
          </div>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <Shield className="w-5 h-5 text-white" />
              <span className="text-xs bg-white/20 px-2 py-1 rounded">Compliance</span>
            </div>
            <h3 className="font-semibold mb-1">Compliance Score</h3>
            <p className="text-blue-100 text-sm">94% - Excellent standing</p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <Bell className="w-5 h-5 text-white" />
              <span className="text-xs bg-white/20 px-2 py-1 rounded">Alert</span>
            </div>
            <h3 className="font-semibold mb-1">Renewal Reminders</h3>
            <p className="text-blue-100 text-sm">2 credentials need attention</p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-5 h-5 text-white" />
              <span className="text-xs bg-white/20 px-2 py-1 rounded">Growth</span>
            </div>
            <h3 className="font-semibold mb-1">Career Development</h3>
            <p className="text-blue-100 text-sm">Consider ICU specialization certs</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            {Object.entries(statusCounts).map(([category, count]) => (
              <button
                key={category}
                onClick={() => setActiveTab(category)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  activeTab === category
                    ? "bg-medical-blue text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)} ({count})
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search credentials..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent w-64"
              />
            </div>
            <button className="p-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
              <Filter className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Credentials Grid */}
      <div className="grid gap-6">
        {filteredCredentials.map((credential) => {
          const daysUntilExpiry = getDaysUntilExpiry(credential.expiryDate);
          
          return (
            <div
              key={credential.id}
              className={`bg-white rounded-lg shadow-sm border transition-all hover:shadow-md ${
                credential.status === "expired" ? "border-red-200 bg-red-50/30" :
                credential.status === "expiring_soon" ? "border-orange-200 bg-orange-50/30" :
                "border-gray-200"
              }`}
            >
              <div className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                  <div className="flex items-start space-x-4 mb-4 lg:mb-0">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      credential.category === "license" ? "bg-blue-100" :
                      credential.category === "certification" ? "bg-green-100" :
                      credential.category === "education" ? "bg-purple-100" :
                      "bg-gray-100"
                    }`}>
                      {credential.category === "license" ? (
                        <FileText className="w-6 h-6 text-blue-600" />
                      ) : credential.category === "certification" ? (
                        <Award className="w-6 h-6 text-green-600" />
                      ) : credential.category === "education" ? (
                        <BookOpen className="w-6 h-6 text-purple-600" />
                      ) : (
                        <FileText className="w-6 h-6 text-gray-600" />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">
                          {credential.name}
                        </h3>
                        {credential.isRequired && (
                          <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-medium">
                            Required
                          </span>
                        )}
                        {getStatusBadge(credential.status)}
                      </div>

                      <p className="text-gray-600 mb-2">{credential.issuingOrganization}</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm text-gray-600">
                        <div>
                          <span className="text-gray-500">Issued:</span> {credential.issueDate}
                        </div>
                        <div>
                          <span className="text-gray-500">Expires:</span> 
                          <span className={
                            daysUntilExpiry !== null && daysUntilExpiry < 60 ? "text-red-600 font-medium ml-1" : "ml-1"
                          }>
                            {credential.expiryDate}
                            {daysUntilExpiry !== null && daysUntilExpiry > 0 && (
                              <span className="text-orange-600 ml-1">
                                ({daysUntilExpiry} days)
                              </span>
                            )}
                          </span>
                        </div>
                        {credential.credentialNumber && (
                          <div>
                            <span className="text-gray-500">Number:</span> {credential.credentialNumber}
                          </div>
                        )}
                      </div>

                      {credential.remindersSent > 0 && (
                        <div className="mt-2 flex items-center text-orange-600 text-sm">
                          <Bell className="w-4 h-4 mr-1" />
                          {credential.remindersSent} reminder{credential.remindersSent > 1 ? 's' : ''} sent
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedCredential(credential)}
                      className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium flex items-center"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </button>
                    
                    {credential.documentUrl && (
                      <button className="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center">
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </button>
                    )}
                    
                    {(credential.status === "expired" || credential.status === "expiring_soon") && (
                      <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium flex items-center">
                        <RefreshCw className="w-4 h-4 mr-1" />
                        Renew
                      </button>
                    )}
                    
                    <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredCredentials.length === 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <Award className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No credentials found</h3>
          <p className="text-gray-600 mb-6">
            Start by adding your professional licenses and certifications.
          </p>
          <button 
            onClick={() => setShowUploadModal(true)}
            className="bg-medical-blue text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Add First Credential
          </button>
        </div>
      )}

      {/* CE Recommendations Modal */}
      {showCERecommendations && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-header font-bold text-gray-900 flex items-center">
                <Brain className="w-6 h-6 mr-2 text-ai-purple" />
                AI-Powered CE Recommendations
              </h2>
              <button
                onClick={() => setShowCERecommendations(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                ×
              </button>
            </div>
            
            <div className="p-6">
              <p className="text-gray-600 mb-6">
                Based on your credentials and career goals, here are personalized continuing education recommendations:
              </p>
              
              <div className="space-y-4">
                {ceRecommendations.map((recommendation) => (
                  <div key={recommendation.id} className="border border-gray-200 rounded-lg p-6 hover:border-medical-blue transition-colors">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">
                          {recommendation.title}
                        </h3>
                        <p className="text-gray-600 mb-2">{recommendation.provider}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <span>{recommendation.hours} hours</span>
                          <span>•</span>
                          <span>{recommendation.format}</span>
                          <span>•</span>
                          <span>${recommendation.cost}</span>
                          <span>•</span>
                          <div className="flex items-center">
                            <Star className="w-4 h-4 text-yellow-500 mr-1" />
                            {recommendation.rating}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-red-600 font-medium mb-2">
                          Due: {recommendation.deadline}
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          recommendation.difficulty === "beginner" ? "bg-green-100 text-green-800" :
                          recommendation.difficulty === "intermediate" ? "bg-yellow-100 text-yellow-800" :
                          "bg-red-100 text-red-800"
                        }`}>
                          {recommendation.difficulty}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex flex-wrap gap-2">
                        {recommendation.relevantCredentials.map((cred, index) => (
                          <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                            {cred}
                          </span>
                        ))}
                      </div>
                      <button className="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center">
                        <ExternalLink className="w-4 h-4 mr-1" />
                        Enroll Now
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Credential Detail Modal */}
      {selectedCredential && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-header font-bold text-gray-900">
                Credential Details
              </h2>
              <button
                onClick={() => setSelectedCredential(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                ×
              </button>
            </div>
            
            <div className="p-6">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Name:</span>
                      <div className="font-medium">{selectedCredential.name}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Type:</span>
                      <div className="font-medium">{selectedCredential.type}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Organization:</span>
                      <div className="font-medium">{selectedCredential.issuingOrganization}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Status:</span>
                      <div className="mt-1">{getStatusBadge(selectedCredential.status)}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Dates & Verification</h3>
                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Issue Date:</span>
                      <div className="font-medium">{selectedCredential.issueDate}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Expiry Date:</span>
                      <div className="font-medium">{selectedCredential.expiryDate}</div>
                    </div>
                    {selectedCredential.verifiedBy && (
                      <>
                        <div>
                          <span className="text-gray-600">Verified By:</span>
                          <div className="font-medium">{selectedCredential.verifiedBy}</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Verified Date:</span>
                          <div className="font-medium">{selectedCredential.verifiedDate}</div>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {selectedCredential.renewalInstructions && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Renewal Instructions</h3>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <p className="text-blue-800 text-sm">{selectedCredential.renewalInstructions}</p>
                    </div>
                  </div>
                )}

                {selectedCredential.notes && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Notes</h3>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <p className="text-gray-700 text-sm">{selectedCredential.notes}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200">
                <button
                  onClick={() => setSelectedCredential(null)}
                  className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Close
                </button>
                <button className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                  Edit
                </button>
                <button className="px-6 py-2 bg-medical-blue text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Download Certificate
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
