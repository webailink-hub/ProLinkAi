import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Brain,
  TrendingUp,
  Calendar,
  Clock,
  DollarSign,
  Users,
  Star,
  ChevronRight,
  Award,
  Target,
  Briefcase,
  Plus,
  Eye,
  MessageSquare,
  Building2,
  BarChart3,
  Sparkles,
  CreditCard,
} from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { useAuth } from "../contexts/AuthContext";

// Mock data - in real app this would come from API calls
const mockMetrics = {
  nurse: {
    shiftsCompleted: 47,
    earningsThisMonth: 8240,
    averageRating: 4.8,
    hoursWorked: 184,
    upcomingShifts: 3,
    pendingApplications: 2,
    credentialStatus: 95,
  },
  facility: {
    shiftsPosted: 156,
    applicationsReceived: 89,
    averageFillRate: 94,
    activeNurses: 34,
    pendingApprovals: 7,
    monthlySpend: 45200,
    satisfaction: 4.7,
  },
  admin: {
    totalUsers: 12847,
    monthlyGrowth: 18.5,
    totalShifts: 98654,
    revenue: 2840000,
    activeIssues: 12,
    systemHealth: 99.2,
    pendingVerifications: 23,
  },
};

const mockAIInsights = {
  nurse: [
    "🔥 Peak demand for ICU shifts this weekend - earn 25% more",
    "📈 Your application rate is 15% higher than average",
    "⭐ Complete 3 more shifts to unlock Elite status",
    "💡 Consider adding Pediatric certification for more opportunities",
  ],
  facility: [
    "📊 Your fill rate is 12% above industry average",
    "🎯 Weekend ER shifts have highest demand",
    "💰 Early posting reduces costs by average $45/shift",
    "⚡ Consider premium pricing for last-minute shifts",
  ],
  admin: [
    "📈 User growth accelerating - 23% month-over-month",
    "🎯 California market showing highest engagement",
    "💡 Implement advanced matching to boost fill rates",
    "⚠️ Monitor server capacity with upcoming growth",
  ],
};

const mockRecommendations = {
  nurse: [
    {
      id: 1,
      title: "High-Priority ICU Shift",
      facility: "City General Hospital",
      time: "Tonight 7PM-7AM",
      pay: "$680",
      match: 98,
      urgent: true,
    },
    {
      id: 2,
      title: "Weekend ER Coverage",
      facility: "Metro Medical Center",
      time: "Sat-Sun 6AM-6PM",
      pay: "$1,240",
      match: 95,
      urgent: false,
    },
  ],
  facility: [
    {
      id: 1,
      title: "Post ICU Night Shift",
      urgency: "High",
      suggested: "Offer 20% premium for quick fill",
      action: "Post Now",
    },
    {
      id: 2,
      title: "Schedule Weekend Coverage",
      urgency: "Medium",
      suggested: "Post 5 days ahead for best rates",
      action: "Schedule",
    },
  ],
  admin: [
    {
      id: 1,
      title: "Review System Performance",
      metric: "Response time up 12%",
      action: "Investigate",
      priority: "high",
    },
    {
      id: 2,
      title: "Approve Nurse Verifications",
      metric: "23 pending for 2+ days",
      action: "Review",
      priority: "medium",
    },
  ],
};

export default function DashboardHome() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const { user } = useAuth();

  if (!user) return null;

  const userRole = user.role;
  const metrics = mockMetrics[userRole];
  const insights = mockAIInsights[userRole];
  const recommendations = mockRecommendations[userRole];

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  };

  const getActionButton = () => {
    switch (userRole) {
      case "nurse":
        return (
          <Link to="/dashboard/shifts">
            <Button className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-blue-700 hover:to-purple-600">
              <Briefcase className="w-4 h-4 mr-2" />
              Find Shifts
            </Button>
          </Link>
        );
      case "facility":
        return (
          <Link to="/dashboard/post-shift">
            <Button className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-blue-700 hover:to-purple-600">
              <Plus className="w-4 h-4 mr-2" />
              Post New Shift
            </Button>
          </Link>
        );
      case "admin":
        return (
          <Link to="/dashboard/admin">
            <Button className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-blue-700 hover:to-purple-600">
              <BarChart3 className="w-4 h-4 mr-2" />
              View Analytics
            </Button>
          </Link>
        );
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-medical-blue to-ai-purple rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">
              {getGreeting()}, {user.name}!
            </h1>
            <p className="text-blue-100 mb-4">
              Here's your AI-powered dashboard with personalized insights and
              recommendations.
            </p>
            {getActionButton()}
          </div>
          <div className="hidden lg:block">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
              <Brain className="w-10 h-10 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {userRole === "nurse" && (
          <>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Shifts Completed</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {metrics.shiftsCompleted}
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Briefcase className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="text-xs">
                    +12% this month
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Earnings</p>
                    <p className="text-2xl font-bold text-gray-900">
                      ${metrics.earningsThisMonth.toLocaleString()}
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-green-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="text-xs">
                    This month
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Average Rating</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {metrics.averageRating}/5
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                    <Star className="w-5 h-5 text-yellow-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${i < Math.floor(metrics.averageRating) ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Credential Status</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {metrics.credentialStatus}%
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                    <Award className="w-5 h-5 text-purple-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-purple-600 h-2 rounded-full"
                      style={{ width: `${metrics.credentialStatus}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {userRole === "facility" && (
          <>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Shifts Posted</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {metrics.shiftsPosted}
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="text-xs">
                    This month
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Fill Rate</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {metrics.averageFillRate}%
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <Target className="w-5 h-5 text-green-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-600 h-2 rounded-full"
                      style={{ width: `${metrics.averageFillRate}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Active Nurses</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {metrics.activeNurses}
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                    <Users className="w-5 h-5 text-purple-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="text-xs">
                    Working with you
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Monthly Spend</p>
                    <p className="text-2xl font-bold text-gray-900">
                      ${metrics.monthlySpend.toLocaleString()}
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-green-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="text-xs">
                    8% below budget
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {userRole === "admin" && (
          <>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Users</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {metrics.totalUsers.toLocaleString()}
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Users className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="text-xs">
                    +{metrics.monthlyGrowth}% growth
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Revenue</p>
                    <p className="text-2xl font-bold text-gray-900">
                      ${(metrics.revenue / 1000000).toFixed(1)}M
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="text-xs">
                    +23% MoM
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">System Health</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {metrics.systemHealth}%
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <BarChart3 className="w-5 h-5 text-green-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-600 h-2 rounded-full"
                      style={{ width: `${metrics.systemHealth}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Active Issues</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {metrics.activeIssues}
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-orange-600" />
                  </div>
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="text-xs">
                    2 critical
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* AI Insights */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-r from-medical-blue to-ai-purple rounded-lg flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <CardTitle className="text-lg">AI Insights</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {insights.map((insight, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg"
                >
                  <div className="w-2 h-2 bg-ai-purple rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-gray-700">{insight}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {userRole === "nurse" && (
                <>
                  <Link to="/dashboard/shifts" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <Calendar className="w-4 h-4 mr-2" />
                      Browse Shifts
                    </Button>
                  </Link>
                  <Link to="/dashboard/my-credentials" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <Award className="w-4 h-4 mr-2" />
                      Update Credentials
                    </Button>
                  </Link>
                  <Link to="/dashboard/profile" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <Users className="w-4 h-4 mr-2" />
                      Edit Profile
                    </Button>
                  </Link>
                </>
              )}

              {userRole === "facility" && (
                <>
                  <Link to="/dashboard/post-shift" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <Plus className="w-4 h-4 mr-2" />
                      Post Shift
                    </Button>
                  </Link>
                  <Link to="/dashboard/applicants" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <Users className="w-4 h-4 mr-2" />
                      View Applicants
                    </Button>
                  </Link>
                  <Link to="/dashboard/messages" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Messages
                    </Button>
                  </Link>
                </>
              )}

              {userRole === "admin" && (
                <>
                  <Link to="/dashboard/admin" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      System Analytics
                    </Button>
                  </Link>
                  <Link to="/dashboard/admin/users" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <Users className="w-4 h-4 mr-2" />
                      User Management
                    </Button>
                  </Link>
                  <Link to="/platform-admin" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <Building2 className="w-4 h-4 mr-2" />
                      Platform Admin
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-r from-medical-blue to-ai-purple rounded-lg flex items-center justify-center">
                <Target className="w-4 h-4 text-white" />
              </div>
              <CardTitle className="text-lg">
                {userRole === "nurse"
                  ? "Recommended Shifts"
                  : userRole === "facility"
                    ? "Smart Recommendations"
                    : "System Recommendations"}
              </CardTitle>
            </div>
            <Button variant="outline" size="sm">
              <Eye className="w-4 h-4 mr-1" />
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recommendations.map((rec: any) => (
              <div
                key={rec.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-gray-900">{rec.title}</h4>
                    {rec.urgent && (
                      <Badge variant="destructive" className="text-xs">
                        Urgent
                      </Badge>
                    )}
                    {rec.match && (
                      <Badge variant="secondary" className="text-xs">
                        {rec.match}% match
                      </Badge>
                    )}
                    {rec.urgency && (
                      <Badge
                        variant={
                          rec.urgency === "High"
                            ? "destructive"
                            : rec.urgency === "Medium"
                              ? "default"
                              : "secondary"
                        }
                        className="text-xs"
                      >
                        {rec.urgency}
                      </Badge>
                    )}
                    {rec.priority && (
                      <Badge
                        variant={
                          rec.priority === "high"
                            ? "destructive"
                            : rec.priority === "medium"
                              ? "default"
                              : "secondary"
                        }
                        className="text-xs"
                      >
                        {rec.priority}
                      </Badge>
                    )}
                  </div>
                  {rec.facility && (
                    <p className="text-sm text-gray-600 mb-1">{rec.facility}</p>
                  )}
                  {rec.suggested && (
                    <p className="text-sm text-gray-600">{rec.suggested}</p>
                  )}
                  {rec.metric && (
                    <p className="text-sm text-gray-600">{rec.metric}</p>
                  )}
                  {rec.time && (
                    <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {rec.time}
                      </span>
                      <span className="flex items-center gap-1 text-green-600 font-medium">
                        <DollarSign className="w-3 h-3" />
                        {rec.pay}
                      </span>
                    </div>
                  )}
                </div>
                <Button
                  size="sm"
                  variant={
                    rec.urgency === "High" || rec.priority === "high"
                      ? "default"
                      : "outline"
                  }
                >
                  {rec.action || "Apply"}
                  <ChevronRight className="w-3 h-3 ml-1" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
