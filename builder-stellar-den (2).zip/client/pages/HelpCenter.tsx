import React, { useState } from 'react';
import { Search, Phone, Mail, MessageCircle, Book, Video, FileText, Users, Star, ThumbsUp, ThumbsDown, ExternalLink, Brain, Clock, CheckCircle, AlertCircle, HelpCircle, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
  helpful: number;
  notHelpful: number;
  isOpen?: boolean;
}

interface SupportChannel {
  name: string;
  description: string;
  icon: React.ReactNode;
  status: 'online' | 'busy' | 'offline';
  responseTime: string;
  available: boolean;
}

export default function HelpCenter() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [faqs, setFaqs] = useState<FAQItem[]>([
    {
      id: '1',
      question: 'How do I apply for shifts?',
      answer: 'To apply for shifts, navigate to the "Find Shifts" page from your dashboard. Use our AI-powered search to filter by location, specialty, pay rate, and schedule. Click "Apply" on any shift that matches your preferences. Our AI will automatically match you with the most suitable opportunities based on your profile and past performance.',
      category: 'shifts',
      helpful: 45,
      notHelpful: 2,
      isOpen: false
    },
    {
      id: '2',
      question: 'What credentials do I need to upload?',
      answer: 'Required credentials include: RN/LPN license, BLS certification, and any specialty certifications relevant to your field. Our AI system will automatically verify credentials and send renewal reminders 30 days before expiration. Upload clear photos or PDFs of all documents through the "My Credentials" section.',
      category: 'credentials',
      helpful: 38,
      notHelpful: 1,
      isOpen: false
    },
    {
      id: '3',
      question: 'How and when do I get paid?',
      answer: 'Payments are processed weekly on Fridays for completed shifts. You can track your earnings in real-time through the "Payouts" section. We offer direct deposit, or you can use our instant pay feature (small fee applies). Our AI calculates overtime, bonuses, and deductions automatically.',
      category: 'payments',
      helpful: 52,
      notHelpful: 3,
      isOpen: false
    },
    {
      id: '4',
      question: 'Can I cancel a shift after accepting?',
      answer: 'Yes, but cancellation policies vary by facility. Generally, you can cancel up to 24 hours before the shift without penalty. Last-minute cancellations may affect your reliability score. Our AI will suggest alternative nurses to facilities when you cancel to maintain good relationships.',
      category: 'shifts',
      helpful: 29,
      notHelpful: 8,
      isOpen: false
    },
    {
      id: '5',
      question: 'How does the AI matching work?',
      answer: 'Our AI analyzes your skills, experience, location preferences, availability, and past performance to match you with the most suitable shifts. It considers factors like commute time, facility ratings, pay rates, and specialty requirements. The system learns from your behavior and continuously improves recommendations.',
      category: 'ai',
      helpful: 67,
      notHelpful: 5,
      isOpen: false
    },
    {
      id: '6',
      question: 'What if I have issues with a facility?',
      answer: 'Report any issues immediately through our platform. We have a dedicated support team that investigates all complaints within 24 hours. Our AI monitors facility ratings and automatically flags problematic patterns. We maintain a zero-tolerance policy for harassment or unsafe working conditions.',
      category: 'support',
      helpful: 41,
      notHelpful: 2,
      isOpen: false
    }
  ]);

  const supportChannels: SupportChannel[] = [
    {
      name: 'Live Chat',
      description: 'Get instant help from our AI assistant or human agents',
      icon: <MessageCircle className="w-5 h-5" />,
      status: 'online',
      responseTime: '< 2 minutes',
      available: true
    },
    {
      name: 'Phone Support',
      description: 'Speak directly with our support team',
      icon: <Phone className="w-5 h-5" />,
      status: 'online',
      responseTime: '< 5 minutes',
      available: true
    },
    {
      name: 'Email Support',
      description: 'Send detailed questions via email',
      icon: <Mail className="w-5 h-5" />,
      status: 'online',
      responseTime: '< 2 hours',
      available: true
    },
    {
      name: 'Video Call',
      description: 'Schedule a screen-share session for technical issues',
      icon: <Video className="w-5 h-5" />,
      status: 'busy',
      responseTime: 'Schedule required',
      available: true
    }
  ];

  const categories = [
    { id: 'all', name: 'All Categories', count: faqs.length },
    { id: 'shifts', name: 'Shifts & Applications', count: faqs.filter(f => f.category === 'shifts').length },
    { id: 'credentials', name: 'Credentials', count: faqs.filter(f => f.category === 'credentials').length },
    { id: 'payments', name: 'Payments', count: faqs.filter(f => f.category === 'payments').length },
    { id: 'ai', name: 'AI Features', count: faqs.filter(f => f.category === 'ai').length },
    { id: 'support', name: 'Support', count: faqs.filter(f => f.category === 'support').length }
  ];

  const quickActions = [
    { title: 'Submit Timesheet', icon: <Clock className="w-5 h-5" />, link: '/dashboard/timesheets' },
    { title: 'Update Credentials', icon: <FileText className="w-5 h-5" />, link: '/dashboard/my-credentials' },
    { title: 'Find Shifts', icon: <Search className="w-5 h-5" />, link: '/dashboard/shifts' },
    { title: 'View Earnings', icon: <CheckCircle className="w-5 h-5" />, link: '/dashboard/payouts' }
  ];

  const toggleFaq = (id: string) => {
    setFaqs(faqs.map(faq => 
      faq.id === id ? { ...faq, isOpen: !faq.isOpen } : faq
    ));
  };

  const handleHelpful = (id: string, helpful: boolean) => {
    setFaqs(faqs.map(faq => 
      faq.id === id 
        ? { 
            ...faq, 
            helpful: helpful ? faq.helpful + 1 : faq.helpful,
            notHelpful: !helpful ? faq.notHelpful + 1 : faq.notHelpful
          } 
        : faq
    ));
  };

  const filteredFaqs = faqs.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || faq.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'busy': return 'bg-yellow-500';
      case 'offline': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent mb-4">
          Help Center
        </h1>
        <p className="text-gray-600 text-lg max-w-2xl mx-auto">
          AI-powered support center with instant answers, live chat, and comprehensive guides
        </p>
      </div>

      {/* AI Assistant Banner */}
      <Card className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 border-ai-purple/20">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-br from-ai-purple to-medical-teal rounded-xl">
              <Brain className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-ai-purple mb-2">ProLinkAi Assistant</h3>
              <p className="text-gray-600 mb-4">
                Get instant answers to your questions with our AI-powered assistant. Available 24/7 to help with shifts, payments, credentials, and more.
              </p>
              <Button className="bg-gradient-to-r from-ai-purple to-medical-teal hover:from-ai-purple/90 hover:to-medical-teal/90">
                <MessageCircle className="w-4 h-4 mr-2" />
                Start AI Chat
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search for help articles, FAQs, or topics..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 text-lg h-12"
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {quickActions.map((action, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => window.location.href = action.link}
                >
                  <div className="text-medical-blue mr-3">
                    {action.icon}
                  </div>
                  {action.title}
                </Button>
              ))}
            </CardContent>
          </Card>

          {/* Categories */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Categories</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`w-full flex items-center justify-between p-2 rounded-lg transition-colors ${
                    selectedCategory === category.id
                      ? 'bg-medical-blue text-white'
                      : 'hover:bg-gray-100'
                  }`}
                >
                  <span className="text-sm">{category.name}</span>
                  <Badge className={
                    selectedCategory === category.id
                      ? 'bg-white/20 text-white border-white/30'
                      : 'bg-gray-100 text-gray-600 border-gray-200'
                  }>
                    {category.count}
                  </Badge>
                </button>
              ))}
            </CardContent>
          </Card>

          {/* Support Channels */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Contact Support</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {supportChannels.map((channel, index) => (
                <div
                  key={index}
                  className="p-3 border rounded-lg hover:shadow-sm transition-shadow cursor-pointer"
                >
                  <div className="flex items-start gap-3">
                    <div className="text-medical-blue">
                      {channel.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-sm">{channel.name}</h4>
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(channel.status)}`} />
                      </div>
                      <p className="text-xs text-gray-600 mb-2">{channel.description}</p>
                      <p className="text-xs text-gray-500">{channel.responseTime}</p>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Popular Articles */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500" />
                Popular Articles
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg hover:shadow-sm transition-shadow cursor-pointer">
                  <h4 className="font-medium mb-2">Getting Started Guide</h4>
                  <p className="text-sm text-gray-600 mb-2">Complete setup guide for new nurses</p>
                  <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">Recommended</Badge>
                </div>
                <div className="p-4 border rounded-lg hover:shadow-sm transition-shadow cursor-pointer">
                  <h4 className="font-medium mb-2">AI Matching Explained</h4>
                  <p className="text-sm text-gray-600 mb-2">How our AI finds the perfect shifts for you</p>
                  <Badge className="bg-ai-purple/10 text-ai-purple border-ai-purple/20 text-xs">AI Feature</Badge>
                </div>
                <div className="p-4 border rounded-lg hover:shadow-sm transition-shadow cursor-pointer">
                  <h4 className="font-medium mb-2">Payment & Timesheets</h4>
                  <p className="text-sm text-gray-600 mb-2">Understanding payroll and timesheet submission</p>
                  <Badge className="bg-blue-100 text-blue-800 border-blue-200 text-xs">Essential</Badge>
                </div>
                <div className="p-4 border rounded-lg hover:shadow-sm transition-shadow cursor-pointer">
                  <h4 className="font-medium mb-2">Credential Management</h4>
                  <p className="text-sm text-gray-600 mb-2">Keep your certifications up to date</p>
                  <Badge className="bg-orange-100 text-orange-800 border-orange-200 text-xs">Important</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* FAQs */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5" />
                Frequently Asked Questions
                {filteredFaqs.length !== faqs.length && (
                  <Badge className="bg-blue-100 text-blue-800 border-blue-200">
                    {filteredFaqs.length} results
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {filteredFaqs.map((faq) => (
                <div
                  key={faq.id}
                  className="border rounded-lg p-4 hover:shadow-sm transition-shadow"
                >
                  <button
                    onClick={() => toggleFaq(faq.id)}
                    className="w-full flex items-center justify-between text-left"
                  >
                    <h4 className="font-medium text-gray-900">{faq.question}</h4>
                    {faq.isOpen ? (
                      <ChevronDown className="w-5 h-5 text-gray-400" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    )}
                  </button>
                  
                  {faq.isOpen && (
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <p className="text-gray-600 text-sm leading-relaxed mb-4">
                        {faq.answer}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <span className="text-xs text-gray-500">Was this helpful?</span>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleHelpful(faq.id, true)}
                              className="text-xs"
                            >
                              <ThumbsUp className="w-3 h-3 mr-1" />
                              Yes ({faq.helpful})
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleHelpful(faq.id, false)}
                              className="text-xs"
                            >
                              <ThumbsDown className="w-3 h-3 mr-1" />
                              No ({faq.notHelpful})
                            </Button>
                          </div>
                        </div>
                        
                        <Badge className="bg-gray-100 text-gray-600 border-gray-200 text-xs capitalize">
                          {faq.category}
                        </Badge>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              
              {filteredFaqs.length === 0 && (
                <div className="text-center py-12">
                  <HelpCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">No FAQs Found</h3>
                  <p className="text-gray-500 mb-4">
                    Try adjusting your search terms or browse different categories.
                  </p>
                  <Button className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Ask AI Assistant
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Still Need Help */}
          <Card className="border-medical-blue/20 bg-gradient-to-br from-medical-blue/5 to-ai-purple/5">
            <CardContent className="p-6 text-center">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Still need help?</h3>
              <p className="text-gray-600 mb-4">
                Our support team is here to help you 24/7. Choose your preferred contact method.
              </p>
              <div className="flex justify-center gap-3">
                <Button className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Live Chat
                </Button>
                <Button variant="outline">
                  <Phone className="w-4 h-4 mr-2" />
                  Call Support
                </Button>
                <Button variant="outline">
                  <Mail className="w-4 h-4 mr-2" />
                  Email Us
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
