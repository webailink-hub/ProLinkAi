import React, { useState } from 'react';
import { Bell, Filter, Archive, Trash2, Settings, Clock, Calendar, DollarSign, UserCheck, AlertCircle, CheckCircle, Info, Star, Brain, ChevronDown, MoreHorizontal } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Switch } from '../components/ui/switch';

interface Notification {
  id: string;
  type: 'shift' | 'message' | 'application' | 'payout' | 'system' | 'ai_insight';
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  isStarred: boolean;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  actionable: boolean;
  metadata?: {
    shiftId?: string;
    facilityName?: string;
    amount?: number;
    sender?: string;
    avatar?: string;
  };
}

export default function Notifications() {
  const [filter, setFilter] = useState<'all' | 'unread' | 'starred' | 'archived'>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [aiFiltering, setAiFiltering] = useState(true);
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'shift',
      title: 'New Shift Available',
      message: 'ICU shift at SF General Hospital - $45/hour, 7 AM - 7 PM tomorrow',
      timestamp: '2 minutes ago',
      isRead: false,
      isStarred: false,
      priority: 'high',
      actionable: true,
      metadata: {
        shiftId: 'S123',
        facilityName: 'SF General Hospital',
        amount: 45
      }
    },
    {
      id: '2',
      type: 'ai_insight',
      title: 'AI Recommendation',
      message: 'Based on your preferences, we found 3 perfect matches for this week. 96% compatibility score!',
      timestamp: '5 minutes ago',
      isRead: false,
      isStarred: true,
      priority: 'medium',
      actionable: true
    },
    {
      id: '3',
      type: 'payout',
      title: 'Payment Processed',
      message: 'Your payment of $1,285.50 for last week has been processed and sent to your account.',
      timestamp: '1 hour ago',
      isRead: true,
      isStarred: false,
      priority: 'medium',
      actionable: false,
      metadata: {
        amount: 1285.50
      }
    },
    {
      id: '4',
      type: 'message',
      title: 'New Message from Maria Rodriguez',
      message: 'Thanks for confirming the shift tomorrow! Please arrive 15 minutes early for briefing.',
      timestamp: '2 hours ago',
      isRead: false,
      isStarred: false,
      priority: 'medium',
      actionable: true,
      metadata: {
        sender: 'Maria Rodriguez',
        facilityName: 'SF General Hospital',
        avatar: '/api/placeholder/40/40'
      }
    },
    {
      id: '5',
      type: 'application',
      title: 'Application Status Update',
      message: 'Your application for Stanford Medical Center has been approved! You can now view available shifts.',
      timestamp: '5 hours ago',
      isRead: true,
      isStarred: true,
      priority: 'high',
      actionable: true,
      metadata: {
        facilityName: 'Stanford Medical Center'
      }
    },
    {
      id: '6',
      type: 'system',
      title: 'Credential Renewal Reminder',
      message: 'Your BLS certification expires in 30 days. Renew now to avoid shift restrictions.',
      timestamp: '1 day ago',
      isRead: false,
      isStarred: false,
      priority: 'urgent',
      actionable: true
    },
    {
      id: '7',
      type: 'ai_insight',
      title: 'Weekly Performance Summary',
      message: 'You completed 4 shifts this week with 4.9/5 rating. Your earning potential increased by 12%!',
      timestamp: '2 days ago',
      isRead: true,
      isStarred: false,
      priority: 'low',
      actionable: false
    },
    {
      id: '8',
      type: 'shift',
      title: 'Shift Reminder',
      message: 'You have a shift tomorrow at UCSF Medical Center from 3 PM - 11 PM. Emergency contact updated.',
      timestamp: '1 day ago',
      isRead: true,
      isStarred: false,
      priority: 'high',
      actionable: false,
      metadata: {
        facilityName: 'UCSF Medical Center'
      }
    }
  ]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'shift': return <Calendar className="w-4 h-4" />;
      case 'message': return <Bell className="w-4 h-4" />;
      case 'application': return <UserCheck className="w-4 h-4" />;
      case 'payout': return <DollarSign className="w-4 h-4" />;
      case 'system': return <AlertCircle className="w-4 h-4" />;
      case 'ai_insight': return <Brain className="w-4 h-4" />;
      default: return <Info className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'shift': return 'text-medical-blue';
      case 'message': return 'text-medical-teal';
      case 'application': return 'text-medical-green';
      case 'payout': return 'text-green-600';
      case 'system': return 'text-orange-600';
      case 'ai_insight': return 'text-ai-purple';
      default: return 'text-gray-600';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'border-l-red-500 bg-red-50';
      case 'high': return 'border-l-orange-500 bg-orange-50';
      case 'medium': return 'border-l-blue-500 bg-blue-50';
      case 'low': return 'border-l-gray-500 bg-gray-50';
      default: return 'border-l-gray-300 bg-white';
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent': return <Badge className="bg-red-100 text-red-800 border-red-200">Urgent</Badge>;
      case 'high': return <Badge className="bg-orange-100 text-orange-800 border-orange-200">High</Badge>;
      case 'medium': return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Medium</Badge>;
      case 'low': return <Badge className="bg-gray-100 text-gray-800 border-gray-200">Low</Badge>;
      default: return null;
    }
  };

  const handleMarkAsRead = (id: string) => {
    setNotifications(notifications.map(notif => 
      notif.id === id ? { ...notif, isRead: true } : notif
    ));
  };

  const handleToggleStar = (id: string) => {
    setNotifications(notifications.map(notif => 
      notif.id === id ? { ...notif, isStarred: !notif.isStarred } : notif
    ));
  };

  const handleMarkAllAsRead = () => {
    setNotifications(notifications.map(notif => ({ ...notif, isRead: true })));
  };

  const filteredNotifications = notifications.filter(notif => {
    if (filter === 'unread' && notif.isRead) return false;
    if (filter === 'starred' && !notif.isStarred) return false;
    if (typeFilter !== 'all' && notif.type !== typeFilter) return false;
    return true;
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const starredCount = notifications.filter(n => n.isStarred).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent">
            Notifications
          </h1>
          <p className="text-gray-600 mt-2">
            Smart notifications with AI filtering and personalized insights
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleMarkAllAsRead}>
            Mark All Read
          </Button>
          <Button variant="outline">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>

      {/* AI Filtering Panel */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-ai-purple/10 to-medical-teal/10 rounded-lg">
                <Brain className="w-5 h-5 text-ai-purple" />
              </div>
              <div>
                <h3 className="font-semibold text-ai-purple">AI Smart Filtering</h3>
                <p className="text-sm text-gray-600">Automatically prioritize and organize your notifications</p>
              </div>
            </div>
            <Switch 
              checked={aiFiltering}
              onCheckedChange={setAiFiltering}
            />
          </div>
          
          {aiFiltering && (
            <div className="mt-4 p-3 bg-gradient-to-r from-ai-purple/5 to-medical-teal/5 rounded-lg border border-ai-purple/20">
              <div className="flex items-center gap-2 text-sm text-ai-purple">
                <Brain className="w-4 h-4" />
                <span>AI is actively filtering {notifications.length} notifications based on your behavior patterns</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Filters and Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <Card 
          className={`cursor-pointer transition-colors ${filter === 'all' ? 'ring-2 ring-medical-blue' : ''}`}
          onClick={() => setFilter('all')}
        >
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-medical-blue">{notifications.length}</div>
            <div className="text-sm text-gray-600">Total</div>
          </CardContent>
        </Card>

        <Card 
          className={`cursor-pointer transition-colors ${filter === 'unread' ? 'ring-2 ring-medical-blue' : ''}`}
          onClick={() => setFilter('unread')}
        >
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{unreadCount}</div>
            <div className="text-sm text-gray-600">Unread</div>
          </CardContent>
        </Card>

        <Card 
          className={`cursor-pointer transition-colors ${filter === 'starred' ? 'ring-2 ring-medical-blue' : ''}`}
          onClick={() => setFilter('starred')}
        >
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{starredCount}</div>
            <div className="text-sm text-gray-600">Starred</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <select 
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full text-sm border-0 bg-transparent focus:outline-none"
            >
              <option value="all">All Types</option>
              <option value="shift">Shifts</option>
              <option value="message">Messages</option>
              <option value="application">Applications</option>
              <option value="payout">Payouts</option>
              <option value="system">System</option>
              <option value="ai_insight">AI Insights</option>
            </select>
          </CardContent>
        </Card>
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {filteredNotifications.map((notification) => (
          <Card 
            key={notification.id}
            className={`transition-all hover:shadow-md border-l-4 ${getPriorityColor(notification.priority)} ${
              !notification.isRead ? 'bg-blue-50/50' : ''
            }`}
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                {/* Icon and Type */}
                <div className={`p-2 rounded-lg ${getTypeColor(notification.type)} bg-current/10`}>
                  <div className={getTypeColor(notification.type)}>
                    {getTypeIcon(notification.type)}
                  </div>
                </div>

                {/* Avatar for messages */}
                {notification.type === 'message' && notification.metadata?.avatar && (
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={notification.metadata.avatar} />
                    <AvatarFallback>
                      {notification.metadata.sender?.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                )}

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <h3 className={`font-semibold ${!notification.isRead ? 'text-gray-900' : 'text-gray-700'}`}>
                        {notification.title}
                      </h3>
                      {!notification.isRead && <div className="w-2 h-2 bg-medical-blue rounded-full" />}
                      {notification.isStarred && <Star className="w-4 h-4 text-yellow-500 fill-current" />}
                      {getPriorityBadge(notification.priority)}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">{notification.timestamp}</span>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <p className={`text-sm mb-3 ${!notification.isRead ? 'text-gray-900' : 'text-gray-600'}`}>
                    {notification.message}
                  </p>

                  {/* Metadata */}
                  {notification.metadata && (
                    <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                      {notification.metadata.facilityName && (
                        <span>📍 {notification.metadata.facilityName}</span>
                      )}
                      {notification.metadata.amount && (
                        <span>💰 ${notification.metadata.amount}</span>
                      )}
                      {notification.metadata.sender && (
                        <span>👤 {notification.metadata.sender}</span>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {notification.actionable && (
                      <Button size="sm" className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90">
                        {notification.type === 'shift' && 'View Shift'}
                        {notification.type === 'message' && 'Reply'}
                        {notification.type === 'application' && 'View Application'}
                        {notification.type === 'ai_insight' && 'View Details'}
                        {notification.type === 'system' && 'Take Action'}
                      </Button>
                    )}
                    
                    {!notification.isRead && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleMarkAsRead(notification.id)}
                      >
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Mark Read
                      </Button>
                    )}
                    
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleToggleStar(notification.id)}
                    >
                      <Star className={`w-4 h-4 ${notification.isStarred ? 'text-yellow-500 fill-current' : 'text-gray-400'}`} />
                    </Button>
                    
                    <Button variant="ghost" size="sm">
                      <Archive className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredNotifications.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center mx-auto mb-4">
              <Bell className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No Notifications</h3>
            <p className="text-gray-500">
              {filter === 'unread' && 'All caught up! No unread notifications.'}
              {filter === 'starred' && 'No starred notifications yet.'}
              {filter === 'all' && 'No notifications to display.'}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Load More */}
      {filteredNotifications.length > 0 && (
        <div className="text-center">
          <Button variant="outline">
            Load More Notifications
            <ChevronDown className="w-4 h-4 ml-2" />
          </Button>
        </div>
      )}
    </div>
  );
}
