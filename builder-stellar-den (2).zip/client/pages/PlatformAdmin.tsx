import React, { useState } from 'react';
import { Shield, Users, Building2, ClipboardCheck, TrendingUp, AlertTriangle, CheckCircle, XCircle, Clock, Eye, Calendar, DollarSign, Brain, Filter, Search, FileText, Award } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';

interface PendingItem {
  id: string;
  type: 'nurse' | 'facility' | 'shift' | 'credential';
  name: string;
  submittedDate: string;
  status: 'pending' | 'reviewing' | 'approved' | 'rejected';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  details: any;
}

export default function PlatformAdmin() {
  const [activeTab, setActiveTab] = useState<'overview' | 'nurses' | 'facilities' | 'shifts' | 'credentials'>('overview');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [searchTerm, setSearchTerm] = useState('');

  // Mock data for pending approvals
  const pendingItems: PendingItem[] = [
    {
      id: '1',
      type: 'nurse',
      name: 'Jennifer Martinez, RN',
      submittedDate: '2024-02-10',
      status: 'pending',
      priority: 'high',
      details: {
        email: 'jennifer.martinez@email.com',
        experience: '5 years ICU',
        credentials: ['RN License', 'BLS', 'ACLS'],
        location: 'San Francisco, CA'
      }
    },
    {
      id: '2',
      type: 'facility',
      name: 'Bay Area Medical Center',
      submittedDate: '2024-02-09',
      status: 'pending',
      priority: 'urgent',
      details: {
        type: 'Hospital',
        beds: 250,
        departments: ['ICU', 'Emergency', 'Med-Surg'],
        contact: 'admin@bayareamedical.com'
      }
    },
    {
      id: '3',
      type: 'credential',
      name: 'ACLS Certification - Sarah Johnson',
      submittedDate: '2024-02-08',
      status: 'pending',
      priority: 'medium',
      details: {
        credentialType: 'ACLS Certification',
        nurseId: 'n123',
        issuingOrg: 'American Heart Association',
        expiryDate: '2025-03-15'
      }
    },
    {
      id: '4',
      type: 'shift',
      name: 'ICU Night Shift - SF General',
      submittedDate: '2024-02-07',
      status: 'pending',
      priority: 'medium',
      details: {
        facility: 'SF General Hospital',
        department: 'ICU',
        date: '2024-02-15',
        hourlyRate: 52,
        urgency: 'high'
      }
    }
  ];

  const platformStats = {
    totalUsers: 1247,
    activeNurses: 892,
    activeFacilities: 156,
    pendingApprovals: pendingItems.filter(item => item.status === 'pending').length,
    totalShifts: 3421,
    completedShifts: 3198,
    monthlyRevenue: 284000,
    approvalRate: 94.2
  };

  const filteredItems = pendingItems.filter(item => {
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesSearch = searchTerm === '' || 
      item.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleApproval = (itemId: string, action: 'approve' | 'reject') => {
    // In real app, this would call API
    console.log(`${action} item ${itemId}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'approved': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      case 'reviewing': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'nurse': return <Users className="w-4 h-4" />;
      case 'facility': return <Building2 className="w-4 h-4" />;
      case 'shift': return <Calendar className="w-4 h-4" />;
      case 'credential': return <Award className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-red-600 to-purple-600 bg-clip-text text-transparent">
            Platform Administration
          </h1>
          <p className="text-gray-600 mt-2">
            Business owner dashboard for platform oversight and approvals
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Badge className="bg-red-100 text-red-800 border-red-200">
            <Shield className="w-3 h-3 mr-1" />
            Business Owner
          </Badge>
        </div>
      </div>

      {/* Platform Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{platformStats.totalUsers}</div>
            <div className="text-sm text-gray-600">Total Users</div>
            <div className="text-xs text-green-600 mt-1">+12% this month</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-medical-blue">{platformStats.activeNurses}</div>
            <div className="text-sm text-gray-600">Active Nurses</div>
            <div className="text-xs text-green-600 mt-1">+8% this month</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-medical-teal">{platformStats.activeFacilities}</div>
            <div className="text-sm text-gray-600">Active Facilities</div>
            <div className="text-xs text-green-600 mt-1">+15% this month</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{platformStats.pendingApprovals}</div>
            <div className="text-sm text-gray-600">Pending Approvals</div>
            <div className="text-xs text-red-600 mt-1">Requires attention</div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue and Performance */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">${platformStats.monthlyRevenue.toLocaleString()}</div>
            <div className="text-sm text-gray-600">Monthly Revenue</div>
            <div className="text-xs text-green-600 mt-1">+23% vs last month</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{platformStats.completedShifts}</div>
            <div className="text-sm text-gray-600">Completed Shifts</div>
            <div className="text-xs text-gray-500 mt-1">of {platformStats.totalShifts} total</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{platformStats.approvalRate}%</div>
            <div className="text-sm text-gray-600">Approval Rate</div>
            <div className="text-xs text-green-600 mt-1">Quality standard met</div>
          </CardContent>
        </Card>
      </div>

      {/* AI Platform Insights */}
      <Card className="bg-gradient-to-r from-purple-600/10 to-red-600/10 border-purple-600/20">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-5 h-5 text-purple-600" />
            <h3 className="font-semibold text-purple-600">AI Platform Intelligence</h3>
            <Badge className="bg-purple-600/10 text-purple-600 border-purple-600/20">
              Business Intelligence
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-green-600">Quality Score: 96%</div>
              <p className="text-gray-600">Platform maintains high quality standards</p>
            </div>
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-blue-600">Growth Prediction</div>
              <p className="text-gray-600">35% user growth expected next quarter</p>
            </div>
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-orange-600">Risk Assessment</div>
              <p className="text-gray-600">3 items require immediate review</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tab Navigation */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Approval Queue</CardTitle>
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-1 border border-gray-300 rounded-md text-sm"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
          <div className="flex gap-1 bg-gray-100 p-1 rounded-lg">
            {[
              { id: 'overview', label: 'Overview', icon: TrendingUp },
              { id: 'nurses', label: 'Nurses', icon: Users },
              { id: 'facilities', label: 'Facilities', icon: Building2 },
              { id: 'shifts', label: 'Shifts', icon: Calendar },
              { id: 'credentials', label: 'Credentials', icon: Award }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === tab.id
                      ? 'bg-white text-purple-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredItems.map((item) => (
              <div key={item.id} className="p-4 border rounded-lg hover:shadow-sm transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-gray-100 rounded-lg">
                    {getTypeIcon(item.type)}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-semibold text-gray-900">{item.name}</h4>
                        <p className="text-sm text-gray-600 capitalize">{item.type} Application</p>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${getPriorityColor(item.priority)}`} />
                        <Badge className={getStatusColor(item.status)}>
                          {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                        </Badge>
                      </div>
                    </div>

                    {/* Item Details */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-4">
                      <div>
                        <span className="font-medium">Submitted:</span>
                        <div>{new Date(item.submittedDate).toLocaleDateString()}</div>
                      </div>
                      
                      {item.type === 'nurse' && (
                        <>
                          <div>
                            <span className="font-medium">Experience:</span>
                            <div>{item.details.experience}</div>
                          </div>
                          <div>
                            <span className="font-medium">Location:</span>
                            <div>{item.details.location}</div>
                          </div>
                          <div>
                            <span className="font-medium">Credentials:</span>
                            <div>{item.details.credentials.length} items</div>
                          </div>
                        </>
                      )}
                      
                      {item.type === 'facility' && (
                        <>
                          <div>
                            <span className="font-medium">Type:</span>
                            <div>{item.details.type}</div>
                          </div>
                          <div>
                            <span className="font-medium">Beds:</span>
                            <div>{item.details.beds}</div>
                          </div>
                          <div>
                            <span className="font-medium">Departments:</span>
                            <div>{item.details.departments.length} depts</div>
                          </div>
                        </>
                      )}
                      
                      {item.type === 'shift' && (
                        <>
                          <div>
                            <span className="font-medium">Facility:</span>
                            <div>{item.details.facility}</div>
                          </div>
                          <div>
                            <span className="font-medium">Rate:</span>
                            <div>${item.details.hourlyRate}/hr</div>
                          </div>
                          <div>
                            <span className="font-medium">Date:</span>
                            <div>{new Date(item.details.date).toLocaleDateString()}</div>
                          </div>
                        </>
                      )}
                      
                      {item.type === 'credential' && (
                        <>
                          <div>
                            <span className="font-medium">Type:</span>
                            <div>{item.details.credentialType}</div>
                          </div>
                          <div>
                            <span className="font-medium">Issuer:</span>
                            <div>{item.details.issuingOrg}</div>
                          </div>
                          <div>
                            <span className="font-medium">Expires:</span>
                            <div>{new Date(item.details.expiryDate).toLocaleDateString()}</div>
                          </div>
                        </>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                      <div className="text-xs text-gray-500">
                        Priority: <span className="capitalize">{item.priority}</span>
                      </div>
                      
                      {item.status === 'pending' && (
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4 mr-1" />
                            Review
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleApproval(item.id, 'approve')}
                            className="text-green-600 hover:text-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleApproval(item.id, 'reject')}
                            className="text-red-600 hover:text-red-700"
                          >
                            <XCircle className="w-4 h-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredItems.length === 0 && (
            <div className="text-center py-12">
              <ClipboardCheck className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No Items Found</h3>
              <p className="text-gray-500">
                {statusFilter === 'pending' 
                  ? 'All approvals are up to date!' 
                  : 'Try adjusting your filters.'
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
