import {
  BarChart3,
  TrendingUp,
  Users,
  Building2,
  DollarSign,
  Calendar,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Brain,
  Target,
  Globe,
  Activity,
  Zap,
  Award,
  Settings,
  Download,
  Filter,
  Search,
  MoreHorizontal,
  ArrowUpRight,
  ArrowDownRight,
  Eye,
  Edit3,
  Trash2,
} from "lucide-react";
import { useState } from "react";

export default function AdminDashboard() {
  const [timeRange, setTimeRange] = useState("30d");
  const [selectedMetric, setSelectedMetric] = useState("overview");

  // Mock data for demonstration
  const platformMetrics = {
    totalUsers: 15247,
    totalFacilities: 523,
    totalShifts: 8924,
    revenue: 2100000,
    growth: {
      users: 23.5,
      facilities: 18.2,
      shifts: 45.7,
      revenue: 67.3,
    },
  };

  const recentActivity = [
    {
      type: "user",
      action: "New nurse registered",
      user: "Sarah Johnson, RN",
      time: "2 min ago",
      status: "pending",
    },
    {
      type: "facility",
      action: "Facility verified",
      user: "Metro General Hospital",
      time: "5 min ago",
      status: "completed",
    },
    {
      type: "shift",
      action: "Shift filled",
      user: "ICU Night Shift",
      time: "8 min ago",
      status: "completed",
    },
    {
      type: "alert",
      action: "Compliance alert",
      user: "License expiring soon",
      time: "12 min ago",
      status: "warning",
    },
    {
      type: "revenue",
      action: "Payment processed",
      user: "$12,500 facility payment",
      time: "15 min ago",
      status: "completed",
    },
  ];

  const topFacilities = [
    {
      name: "Metro General Hospital",
      shifts: 234,
      revenue: 145000,
      growth: 12.3,
      satisfaction: 4.8,
    },
    {
      name: "City Medical Center",
      shifts: 189,
      revenue: 118000,
      growth: 8.7,
      satisfaction: 4.9,
    },
    {
      name: "Regional Healthcare",
      shifts: 156,
      revenue: 98000,
      growth: 15.2,
      satisfaction: 4.7,
    },
    {
      name: "St. Mary's Hospital",
      shifts: 143,
      revenue: 89000,
      growth: 6.4,
      satisfaction: 4.6,
    },
    {
      name: "Community Health",
      shifts: 127,
      revenue: 79000,
      growth: 22.1,
      satisfaction: 4.8,
    },
  ];

  const aiInsights = [
    {
      type: "prediction",
      title: "Staffing Surge Predicted",
      description:
        "AI forecasts 35% increase in shift demand next week due to flu season",
      confidence: 94,
      action: "Prepare recruitment campaign",
    },
    {
      type: "opportunity",
      title: "Revenue Optimization",
      description:
        "AI identified $320K additional revenue opportunity in underserved regions",
      confidence: 87,
      action: "Expand to 3 new markets",
    },
    {
      type: "risk",
      title: "Compliance Risk Detected",
      description: "12 nurses have licenses expiring within 30 days",
      confidence: 100,
      action: "Send automated reminders",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-header font-bold text-gray-900">
            Platform Analytics
          </h1>
          <p className="text-gray-600 font-body">
            Real-time insights into ProLinkAi performance and operations
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg font-body focus:ring-2 focus:ring-medical-blue focus:border-transparent"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
            <option value="1y">Last year</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2 bg-medical-blue text-white rounded-lg hover:bg-blue-700 transition-colors font-body">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-medical-blue/10 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-medical-blue" />
            </div>
            <div className="flex items-center text-medical-green text-sm">
              <ArrowUpRight className="w-4 h-4 mr-1" />+
              {platformMetrics.growth.users}%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            {platformMetrics.totalUsers.toLocaleString()}
          </h3>
          <p className="text-gray-600 font-body">
            Total Healthcare Professionals
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-medical-green/10 rounded-xl flex items-center justify-center">
              <Building2 className="w-6 h-6 text-medical-green" />
            </div>
            <div className="flex items-center text-medical-green text-sm">
              <ArrowUpRight className="w-4 h-4 mr-1" />+
              {platformMetrics.growth.facilities}%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            {platformMetrics.totalFacilities.toLocaleString()}
          </h3>
          <p className="text-gray-600 font-body">Active Facilities</p>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-ai-purple/10 rounded-xl flex items-center justify-center">
              <Calendar className="w-6 h-6 text-ai-purple" />
            </div>
            <div className="flex items-center text-medical-green text-sm">
              <ArrowUpRight className="w-4 h-4 mr-1" />+
              {platformMetrics.growth.shifts}%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            {platformMetrics.totalShifts.toLocaleString()}
          </h3>
          <p className="text-gray-600 font-body">Shifts Completed This Month</p>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-medical-teal/10 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-medical-teal" />
            </div>
            <div className="flex items-center text-medical-green text-sm">
              <ArrowUpRight className="w-4 h-4 mr-1" />+
              {platformMetrics.growth.revenue}%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            ${(platformMetrics.revenue / 1000000).toFixed(1)}M
          </h3>
          <p className="text-gray-600 font-body">Monthly Recurring Revenue</p>
        </div>
      </div>

      {/* AI Insights Section */}
      <div className="bg-gradient-to-br from-ai-purple to-medical-blue rounded-2xl p-8 text-white">
        <div className="flex items-center mb-6">
          <Brain className="w-8 h-8 mr-3" />
          <h2 className="text-2xl font-header font-bold">
            AI-Powered Insights
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {aiInsights.map((insight, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur rounded-xl p-6"
            >
              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    insight.type === "prediction"
                      ? "bg-yellow-400/20"
                      : insight.type === "opportunity"
                        ? "bg-green-400/20"
                        : "bg-red-400/20"
                  }`}
                >
                  {insight.type === "prediction" ? (
                    <TrendingUp className="w-5 h-5 text-yellow-300" />
                  ) : insight.type === "opportunity" ? (
                    <Target className="w-5 h-5 text-green-300" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-red-300" />
                  )}
                </div>
                <span className="text-xs bg-white/20 px-2 py-1 rounded">
                  {insight.confidence}% confidence
                </span>
              </div>
              <h3 className="font-header font-semibold mb-2">
                {insight.title}
              </h3>
              <p className="text-blue-100 text-sm mb-3">
                {insight.description}
              </p>
              <button className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded transition-colors">
                {insight.action}
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-header font-bold text-gray-900">
              Recent Activity
            </h2>
            <button className="text-medical-blue hover:text-blue-700 text-sm font-medium">
              View All
            </button>
          </div>

          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors"
              >
                <div className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${
                      activity.type === "user"
                        ? "bg-medical-blue/10"
                        : activity.type === "facility"
                          ? "bg-medical-green/10"
                          : activity.type === "shift"
                            ? "bg-ai-purple/10"
                            : activity.type === "alert"
                              ? "bg-yellow-100"
                              : "bg-medical-teal/10"
                    }`}
                  >
                    {activity.type === "user" ? (
                      <Users className="w-4 h-4 text-medical-blue" />
                    ) : activity.type === "facility" ? (
                      <Building2 className="w-4 h-4 text-medical-green" />
                    ) : activity.type === "shift" ? (
                      <Calendar className="w-4 h-4 text-ai-purple" />
                    ) : activity.type === "alert" ? (
                      <AlertTriangle className="w-4 h-4 text-yellow-600" />
                    ) : (
                      <DollarSign className="w-4 h-4 text-medical-teal" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 text-sm">
                      {activity.action}
                    </p>
                    <p className="text-gray-600 text-xs">{activity.user}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div
                    className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                      activity.status === "completed"
                        ? "bg-medical-green/10 text-medical-green"
                        : activity.status === "pending"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-red-100 text-red-700"
                    }`}
                  >
                    {activity.status}
                  </div>
                  <p className="text-gray-500 text-xs mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Performing Facilities */}
        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-header font-bold text-gray-900">
              Top Performing Facilities
            </h2>
            <button className="text-medical-blue hover:text-blue-700 text-sm font-medium">
              View All
            </button>
          </div>

          <div className="space-y-4">
            {topFacilities.map((facility, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors"
              >
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-gradient-to-br from-medical-blue to-ai-purple rounded-lg flex items-center justify-center mr-3 text-white font-bold text-sm">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 text-sm">
                      {facility.name}
                    </p>
                    <p className="text-gray-600 text-xs">
                      {facility.shifts} shifts • {facility.satisfaction}★ rating
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-gray-900 text-sm">
                    ${(facility.revenue / 1000).toFixed(0)}K
                  </p>
                  <div className="flex items-center text-medical-green text-xs">
                    <ArrowUpRight className="w-3 h-3 mr-1" />+{facility.growth}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Platform Health & System Status */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-header font-semibold text-gray-900">
              System Health
            </h3>
            <div className="w-3 h-3 bg-medical-green rounded-full"></div>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">API Response Time</span>
              <span className="text-sm font-medium text-gray-900">145ms</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Uptime</span>
              <span className="text-sm font-medium text-gray-900">99.98%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Active Sessions</span>
              <span className="text-sm font-medium text-gray-900">2,847</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-header font-semibold text-gray-900">
              AI Performance
            </h3>
            <Zap className="w-5 h-5 text-ai-purple" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Match Accuracy</span>
              <span className="text-sm font-medium text-gray-900">96.7%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">
                Prediction Confidence
              </span>
              <span className="text-sm font-medium text-gray-900">94.2%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Processing Speed</span>
              <span className="text-sm font-medium text-gray-900">
                2.3s avg
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-header font-semibold text-gray-900">
              Compliance Status
            </h3>
            <Shield className="w-5 h-5 text-medical-green" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">HIPAA Compliance</span>
              <CheckCircle2 className="w-4 h-4 text-medical-green" />
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">SOC 2 Type II</span>
              <CheckCircle2 className="w-4 h-4 text-medical-green" />
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">License Validation</span>
              <span className="text-sm text-yellow-600">3 expiring</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-2xl p-6 shadow-card border border-gray-200">
        <h2 className="text-xl font-header font-bold text-gray-900 mb-6">
          Quick Actions
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <Users className="w-8 h-8 text-medical-blue group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">
              User Management
            </span>
          </button>
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <Building2 className="w-8 h-8 text-medical-green group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">
              Facility Oversight
            </span>
          </button>
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <Calendar className="w-8 h-8 text-ai-purple group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">
              Shift Management
            </span>
          </button>
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <BarChart3 className="w-8 h-8 text-medical-teal group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">Analytics</span>
          </button>
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <Shield className="w-8 h-8 text-accent-orange group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">
              Compliance
            </span>
          </button>
          <button className="flex flex-col items-center p-4 hover:bg-gray-50 rounded-lg transition-colors group">
            <Settings className="w-8 h-8 text-gray-600 group-hover:scale-110 transition-transform mb-2" />
            <span className="text-sm font-medium text-gray-900">Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
}
