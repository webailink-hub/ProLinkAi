import "./global.css";

import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// Context
import { AuthProvider } from "./contexts/AuthContext";

// Components
import ProtectedRoute from "./components/ProtectedRoute";

// Public Pages
import Index from "./pages/Index";
import About from "./pages/About";
import Nurses from "./pages/Nurses";
import Facilities from "./pages/Facilities";
import Login from "./pages/Login";
import Register from "./pages/Register";
import RegisterHub from "./pages/RegisterHub";
import NurseRegistration from "./pages/NurseRegistration";
import FacilityRegistration from "./pages/FacilityRegistration";
import ForgotPassword from "./pages/ForgotPassword";
import NotFound from "./pages/NotFound";
import HelpCenter from "./pages/HelpCenter";

// Protected Pages
import ResponsiveDashboardLayout from "./components/ResponsiveDashboardLayout";
import DashboardHome from "./pages/DashboardHome";
import UserProfile from "./pages/UserProfile";
import Settings from "./pages/Settings";
import Messages from "./pages/Messages";
import Notifications from "./pages/Notifications";
import Referrals from "./pages/Referrals";

// Nurse-Specific Pages
import Shifts from "./pages/Shifts";
import Timesheets from "./pages/Timesheets";
import MyCredentials from "./pages/MyCredentials";
import Payouts from "./pages/Payouts";

// Facility-Specific Pages
import PostShift from "./pages/PostShift";
import Applicants from "./pages/Applicants";
import TimesheetApproval from "./pages/TimesheetApproval";

// Admin Pages
import AdminDashboard from "./pages/AdminDashboard";
import UserManagement from "./pages/UserManagement";
import AuditTrail from "./pages/AuditTrail";
import ShiftManagement from "./pages/ShiftManagement";
import PlatformAdmin from "./pages/PlatformAdmin";
import NurseVerification from "./pages/NurseVerification";
import FacilityVerification from "./pages/FacilityVerification";

// Dynamic Pages
import UserProfileDynamic from "./pages/UserProfileDynamic";
import FacilityProfileDynamic from "./pages/FacilityProfileDynamic";

// Utility Pages
import ShiftDetails from "./pages/ShiftDetails";
import ShiftCalendar from "./pages/ShiftCalendar";

const App = () => (
  <AuthProvider>
    <BrowserRouter>
      <Routes>
        {/* Public Pages - No Authentication Required */}
        <Route path="/" element={<Index />} />
        <Route path="/about" element={<About />} />
        <Route path="/nurses" element={<Nurses />} />
        <Route path="/facilities" element={<Facilities />} />
        <Route path="/help" element={<HelpCenter />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/register-hub" element={<RegisterHub />} />
        <Route path="/register/nurse" element={<NurseRegistration />} />
        <Route path="/register/facility" element={<FacilityRegistration />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />

        {/* Protected Dashboard Routes - Authentication Required */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <ResponsiveDashboardLayout />
            </ProtectedRoute>
          }
        >
          {/* Shared Dashboard Pages */}
          <Route index element={<DashboardHome />} />
          <Route path="profile" element={<UserProfile />} />
          <Route path="settings" element={<Settings />} />
          <Route path="messages" element={<Messages />} />
          <Route path="notifications" element={<Notifications />} />
          <Route path="help" element={<HelpCenter />} />
          <Route path="referrals" element={<Referrals />} />

          {/* Nurse-Only Routes */}
          <Route
            path="shifts"
            element={
              <ProtectedRoute allowedRoles={["nurse"]}>
                <Shifts />
              </ProtectedRoute>
            }
          />
          <Route
            path="shift-calendar"
            element={
              <ProtectedRoute allowedRoles={["nurse"]}>
                <ShiftCalendar />
              </ProtectedRoute>
            }
          />
          <Route
            path="timesheets"
            element={
              <ProtectedRoute allowedRoles={["nurse"]}>
                <Timesheets />
              </ProtectedRoute>
            }
          />
          <Route
            path="my-credentials"
            element={
              <ProtectedRoute allowedRoles={["nurse"]}>
                <MyCredentials />
              </ProtectedRoute>
            }
          />
          <Route
            path="payouts"
            element={
              <ProtectedRoute allowedRoles={["nurse"]}>
                <Payouts />
              </ProtectedRoute>
            }
          />

          {/* Facility-Only Routes */}
          <Route
            path="post-shift"
            element={
              <ProtectedRoute allowedRoles={["facility"]}>
                <PostShift />
              </ProtectedRoute>
            }
          />
          <Route
            path="applicants"
            element={
              <ProtectedRoute allowedRoles={["facility"]}>
                <Applicants />
              </ProtectedRoute>
            }
          />
          <Route
            path="timesheet-approval"
            element={
              <ProtectedRoute allowedRoles={["facility"]}>
                <TimesheetApproval />
              </ProtectedRoute>
            }
          />

          {/* Admin-Only Routes */}
          <Route
            path="admin"
            element={
              <ProtectedRoute allowedRoles={["admin"]}>
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="admin/users"
            element={
              <ProtectedRoute allowedRoles={["admin"]}>
                <UserManagement />
              </ProtectedRoute>
            }
          />
          <Route
            path="admin/audit-trail"
            element={
              <ProtectedRoute allowedRoles={["admin"]}>
                <AuditTrail />
              </ProtectedRoute>
            }
          />
          <Route
            path="shift-management"
            element={
              <ProtectedRoute allowedRoles={["admin"]}>
                <ShiftManagement />
              </ProtectedRoute>
            }
          />

          {/* Dynamic Profile Routes */}
          <Route path="user/:userId" element={<UserProfileDynamic />} />
          <Route
            path="facility/:facilityId"
            element={<FacilityProfileDynamic />}
          />
          <Route path="shift/:shiftId" element={<ShiftDetails />} />
        </Route>

        {/* Admin Platform Routes - Admin Only */}
        <Route
          path="/platform-admin"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <PlatformAdmin />
            </ProtectedRoute>
          }
        />
        <Route
          path="/nurse-verification"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <NurseVerification />
            </ProtectedRoute>
          }
        />
        <Route
          path="/facility-verification"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <FacilityVerification />
            </ProtectedRoute>
          }
        />

        {/* Legacy Redirects to Dashboard */}
        <Route
          path="/NurseDashboard"
          element={
            <ProtectedRoute>
              <DashboardHome />
            </ProtectedRoute>
          }
        />
        <Route
          path="/NursesDashboard"
          element={
            <ProtectedRoute>
              <DashboardHome />
            </ProtectedRoute>
          }
        />
        <Route
          path="/FacilityDashboard"
          element={
            <ProtectedRoute>
              <DashboardHome />
            </ProtectedRoute>
          }
        />
        <Route
          path="/FacilitiesDashboard"
          element={
            <ProtectedRoute>
              <DashboardHome />
            </ProtectedRoute>
          }
        />
        <Route
          path="/AdminDashboard"
          element={
            <ProtectedRoute>
              <DashboardHome />
            </ProtectedRoute>
          }
        />

        {/* Catch All - 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  </AuthProvider>
);

// Ensure root is only created once
const rootElement = document.getElementById("root")!;
let root = (rootElement as any)._reactRoot;

if (!root) {
  root = createRoot(rootElement);
  (rootElement as any)._reactRoot = root;
}

root.render(<App />);
