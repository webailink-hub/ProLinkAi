import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";

export type UserRole = "nurse" | "facility" | "admin";

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  avatar?: string;
  isVerified: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Demo users for role-based testing
const DEMO_USERS: Record<string, User> = {
  "nurse.demo": {
    id: "nurse-1",
    email: "nurse.demo@prolinkaid.com",
    role: "nurse",
    name: "Dr. Sarah Johnson",
    avatar: null,
    isVerified: true,
  },
  "facility.demo": {
    id: "facility-1",
    email: "facility.demo@prolinkaid.com",
    role: "facility",
    name: "Memorial Hospital",
    avatar: null,
    isVerified: true,
  },
  "admin.demo": {
    id: "admin-1",
    email: "admin.demo@prolinkaid.com",
    role: "admin",
    name: "System Administrator",
    avatar: null,
    isVerified: true,
  },
};

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored auth on mount
    const storedAuth = localStorage.getItem("prolinkaid_auth");
    if (storedAuth) {
      try {
        const parsedAuth = JSON.parse(storedAuth);
        setUser(parsedAuth.user);
      } catch (error) {
        localStorage.removeItem("prolinkaid_auth");
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);

    // Demo authentication logic
    const normalizedEmail = email.toLowerCase();

    // Check for demo credentials
    if (password === "password") {
      const demoUser = DEMO_USERS[normalizedEmail];
      if (demoUser) {
        setUser(demoUser);
        localStorage.setItem(
          "prolinkaid_auth",
          JSON.stringify({ user: demoUser }),
        );
        setIsLoading(false);
        return true;
      }
    }

    setIsLoading(false);
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("prolinkaid_auth");
  };

  const value: AuthContextType = {
    user,
    login,
    logout,
    isLoading,
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
