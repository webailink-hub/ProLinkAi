import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import {
  Brain,
  Calendar,
  User,
  Settings,
  MessageSquare,
  Bell,
  HelpCircle,
  Users,
  ClipboardList,
  CreditCard,
  Award,
  Plus,
  BarChart3,
  Shield,
  LogOut,
  Menu,
  X,
  Search,
  Home,
  ChevronDown,
  Building2,
  Clock,
  ChevronRight,
  Loader2,
} from "lucide-react";
import { useState, useEffect, Suspense } from "react";
import { useAuth } from "../contexts/AuthContext";

const navigationItems = {
  shared: [
    { path: "/dashboard", icon: Home, label: "Dashboard" },
    { path: "/dashboard/profile", icon: User, label: "Profile" },
    { path: "/dashboard/messages", icon: MessageSquare, label: "Messages" },
    { path: "/dashboard/notifications", icon: Bell, label: "Notifications" },
    { path: "/dashboard/settings", icon: Settings, label: "Settings" },
    { path: "/dashboard/help", icon: HelpCircle, label: "Help" },
  ],
  nurse: [
    { path: "/dashboard/shifts", icon: Calendar, label: "Find Shifts" },
    {
      path: "/dashboard/shift-calendar",
      icon: Calendar,
      label: "Shift Calendar",
    },
    { path: "/dashboard/timesheets", icon: ClipboardList, label: "Timesheets" },
    { path: "/dashboard/my-credentials", icon: Award, label: "Credentials" },
    { path: "/dashboard/payouts", icon: CreditCard, label: "Payouts" },
  ],
  facility: [
    { path: "/dashboard/post-shift", icon: Plus, label: "Post Shift" },
    { path: "/dashboard/applicants", icon: Users, label: "Applicants" },
    {
      path: "/dashboard/timesheet-approval",
      icon: ClipboardList,
      label: "Approve Timesheets",
    },
  ],
  admin: [
    { path: "/dashboard/admin", icon: Shield, label: "Admin Panel" },
    { path: "/dashboard/admin/users", icon: Users, label: "User Management" },
    {
      path: "/dashboard/admin/audit-trail",
      icon: ClipboardList,
      label: "Audit Trail",
    },
    {
      path: "/dashboard/shift-management",
      icon: Calendar,
      label: "Shift Management",
    },
  ],
};

export default function ResponsiveDashboardLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);

    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  // Redirect if no user
  if (!user) {
    navigate("/login");
    return null;
  }

  const currentUserNav = [
    ...navigationItems.shared,
    ...(navigationItems[user.role as keyof typeof navigationItems] || []),
  ];

  const isActive = (path: string) => {
    if (path === "/dashboard") {
      return location.pathname === "/dashboard";
    }
    return location.pathname.startsWith(path);
  };

  const generateBreadcrumbs = () => {
    const pathSegments = location.pathname.split("/").filter(Boolean);
    const breadcrumbs = [{ label: "Dashboard", path: "/dashboard" }];

    let currentPath = "";
    pathSegments.forEach((segment, index) => {
      if (segment === "dashboard") return;

      currentPath += `/${segment}`;
      const fullPath = `/dashboard${currentPath}`;

      const label = segment
        .split("-")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");

      breadcrumbs.push({ label, path: fullPath });
    });

    return breadcrumbs;
  };

  const breadcrumbs = generateBreadcrumbs();

  const LoadingSpinner = () => (
    <div className="flex items-center justify-center h-64">
      <Loader2 className="w-8 h-8 animate-spin text-medical-blue" />
    </div>
  );

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  if (isMobile) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Mobile Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between px-4 py-3">
            <Link to="/dashboard" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" aria-hidden="true" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">
                  ProLink<span className="text-ai-purple">Ai</span>
                </h1>
                <p className="text-xs text-gray-600 capitalize">
                  {user.role} Dashboard
                </p>
              </div>
            </Link>

            <div className="flex items-center gap-2">
              <button
                className="relative p-2 text-gray-600 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-medical-blue rounded-lg"
                aria-label="Notifications"
              >
                <Bell className="w-5 h-5" aria-hidden="true" />
                <div
                  className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"
                  aria-hidden="true"
                ></div>
              </button>
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 text-gray-600 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-medical-blue rounded-lg"
                aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
                aria-expanded={isMobileMenuOpen}
              >
                {isMobileMenuOpen ? (
                  <X className="w-5 h-5" aria-hidden="true" />
                ) : (
                  <Menu className="w-5 h-5" aria-hidden="true" />
                )}
              </button>
            </div>
          </div>

          {/* Breadcrumbs */}
          {breadcrumbs.length > 1 && (
            <div className="px-4 py-2 bg-gray-50 border-b border-gray-200">
              <nav
                aria-label="Breadcrumb"
                className="flex items-center space-x-2 text-sm"
              >
                {breadcrumbs.map((crumb, index) => (
                  <div key={crumb.path} className="flex items-center">
                    {index > 0 && (
                      <ChevronRight
                        className="w-3 h-3 text-gray-400 mx-1"
                        aria-hidden="true"
                      />
                    )}
                    {index === breadcrumbs.length - 1 ? (
                      <span
                        className="text-gray-600 font-medium"
                        aria-current="page"
                      >
                        {crumb.label}
                      </span>
                    ) : (
                      <Link
                        to={crumb.path}
                        className="text-medical-blue hover:text-medical-blue/80 transition-colors"
                      >
                        {crumb.label}
                      </Link>
                    )}
                  </div>
                ))}
              </nav>
            </div>
          )}

          {/* Mobile Navigation Menu */}
          {isMobileMenuOpen && (
            <div className="absolute top-full left-0 right-0 bg-white border-b border-gray-200 max-h-96 overflow-y-auto z-40">
              <div className="p-4">
                <div className="flex items-center gap-3 mb-4 pb-4 border-b border-gray-200">
                  <div className="w-12 h-12 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                    <span className="text-white font-bold">
                      {user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{user.name}</h3>
                    <p className="text-sm text-gray-600 capitalize">
                      {user.role}
                    </p>
                  </div>
                </div>

                <nav
                  className="space-y-1"
                  role="navigation"
                  aria-label="Main navigation"
                >
                  {currentUserNav.map((item) => {
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.path}
                        to={item.path}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={`flex items-center gap-3 px-3 py-3 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-medical-blue ${
                          isActive(item.path)
                            ? "bg-medical-blue text-white"
                            : "text-gray-700 hover:bg-gray-100"
                        }`}
                        aria-current={isActive(item.path) ? "page" : undefined}
                      >
                        <Icon className="w-5 h-5" aria-hidden="true" />
                        <span className="font-medium">{item.label}</span>
                      </Link>
                    );
                  })}
                </nav>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-3 w-full px-3 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="font-medium">Sign Out</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </header>

        {/* Mobile Main Content */}
        <main className="pb-20" role="main">
          <Suspense fallback={<LoadingSpinner />}>
            <Outlet />
          </Suspense>
        </main>

        {/* Mobile Bottom Navigation */}
        <nav
          className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30"
          role="navigation"
          aria-label="Bottom navigation"
        >
          <div className="flex items-center justify-around px-2 py-2">
            {currentUserNav.slice(0, 5).map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors min-w-0 focus:outline-none focus:ring-2 focus:ring-medical-blue ${
                    isActive(item.path) ? "text-medical-blue" : "text-gray-600"
                  }`}
                  aria-current={isActive(item.path) ? "page" : undefined}
                  title={item.label}
                >
                  <Icon className="w-5 h-5" aria-hidden="true" />
                  <span className="text-xs font-medium truncate max-w-[60px]">
                    {item.label.split(" ")[0]}
                  </span>
                </Link>
              );
            })}
          </div>
        </nav>
      </div>
    );
  }

  // Desktop Layout
  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Desktop Sidebar */}
      <aside
        className="w-64 bg-white border-r border-gray-200 flex flex-col"
        role="navigation"
        aria-label="Main navigation"
      >
        {/* Logo */}
        <div className="p-6 border-b border-gray-200">
          <Link
            to="/dashboard"
            className="flex items-center gap-3 focus:outline-none focus:ring-2 focus:ring-medical-blue rounded-lg"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" aria-hidden="true" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </h1>
              <p className="text-sm text-gray-600 capitalize">
                {user.role} Portal
              </p>
            </div>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <div className="space-y-1">
            {currentUserNav.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-3 px-3 py-3 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-medical-blue ${
                    isActive(item.path)
                      ? "bg-medical-blue text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                  aria-current={isActive(item.path) ? "page" : undefined}
                >
                  <Icon className="w-5 h-5" aria-hidden="true" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </div>
        </nav>

        {/* User Profile */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-sm">
                {user.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-gray-900 truncate">
                {user.name}
              </h3>
              <p className="text-sm text-gray-600 capitalize">{user.role}</p>
            </div>
          </div>

          <button
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-medical-blue"
            aria-label="Sign out of your account"
          >
            <LogOut className="w-4 h-4" aria-hidden="true" />
            <span className="text-sm font-medium">Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Desktop Main Content */}
      <main className="flex-1 overflow-hidden flex flex-col" role="main">
        {/* Desktop Breadcrumbs */}
        {breadcrumbs.length > 1 && (
          <div className="bg-white border-b border-gray-200 px-6 py-4">
            <nav
              aria-label="Breadcrumb"
              className="flex items-center space-x-2 text-sm"
            >
              {breadcrumbs.map((crumb, index) => (
                <div key={crumb.path} className="flex items-center">
                  {index > 0 && (
                    <ChevronRight
                      className="w-4 h-4 text-gray-400 mx-2"
                      aria-hidden="true"
                    />
                  )}
                  {index === breadcrumbs.length - 1 ? (
                    <span
                      className="text-gray-600 font-medium"
                      aria-current="page"
                    >
                      {crumb.label}
                    </span>
                  ) : (
                    <Link
                      to={crumb.path}
                      className="text-medical-blue hover:text-medical-blue/80 transition-colors"
                    >
                      {crumb.label}
                    </Link>
                  )}
                </div>
              ))}
            </nav>
          </div>
        )}

        <div className="flex-1 overflow-y-auto">
          <Suspense fallback={<LoadingSpinner />}>
            <Outlet />
          </Suspense>
        </div>
      </main>
    </div>
  );
}
