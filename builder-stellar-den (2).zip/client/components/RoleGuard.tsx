import React from 'react';
import { Navigate } from 'react-router-dom';
import { AlertTriangle, Shield, Users, Building2 } from 'lucide-react';

// Mock user context - in real app this would come from auth context
const getUserRole = (): 'nurse' | 'facility' | 'admin' | null => {
  // For demo purposes, you can change this to test different roles
  return 'admin'; // Change to 'nurse', 'facility', or 'admin' to test
};

interface RoleGuardProps {
  allowedRoles: ('nurse' | 'facility' | 'admin')[];
  children: React.ReactNode;
  fallbackPath?: string;
}

export function RoleGuard({ allowedRoles, children, fallbackPath }: RoleGuardProps) {
  const userRole = getUserRole();

  if (!userRole) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(userRole)) {
    return <UnauthorizedAccess userRole={userRole} />;
  }

  return <>{children}</>;
}

function UnauthorizedAccess({ userRole }: { userRole: string }) {
  const getRoleInfo = (role: string) => {
    switch (role) {
      case 'nurse':
        return {
          icon: <Users className="w-12 h-12 text-medical-blue" />,
          title: 'Nurse Dashboard',
          description: 'You have nurse-level access',
          redirectPath: '/dashboard',
          color: 'medical-blue'
        };
      case 'facility':
        return {
          icon: <Building2 className="w-12 h-12 text-medical-teal" />,
          title: 'Facility Dashboard', 
          description: 'You have facility-level access',
          redirectPath: '/dashboard',
          color: 'medical-teal'
        };
      case 'admin':
        return {
          icon: <Shield className="w-12 h-12 text-red-600" />,
          title: 'Platform Administration',
          description: 'You have administrative access',
          redirectPath: '/platform-admin',
          color: 'red-600'
        };
      default:
        return {
          icon: <AlertTriangle className="w-12 h-12 text-gray-400" />,
          title: 'Access Restricted',
          description: 'Unknown role',
          redirectPath: '/login',
          color: 'gray-400'
        };
    }
  };

  const roleInfo = getRoleInfo(userRole);

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-lg shadow-lg p-8 text-center">
          <div className="mb-6">
            {roleInfo.icon}
          </div>
          
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Access Restricted
          </h2>
          
          <p className="text-gray-600 mb-6">
            This page is not available for your current role level.
          </p>
          
          <div className={`bg-${roleInfo.color}/10 border border-${roleInfo.color}/20 rounded-lg p-4 mb-6`}>
            <h3 className={`font-semibold text-${roleInfo.color} mb-1`}>
              Your Current Access Level
            </h3>
            <p className={`text-sm text-${roleInfo.color}/80`}>
              {roleInfo.description}
            </p>
          </div>

          <button
            onClick={() => window.location.href = roleInfo.redirectPath}
            className={`w-full bg-${roleInfo.color} hover:bg-${roleInfo.color}/90 text-white font-semibold py-2 px-4 rounded-lg transition-colors`}
          >
            Go to {roleInfo.title}
          </button>
          
          <p className="text-xs text-gray-500 mt-4">
            If you believe this is an error, please contact your administrator.
          </p>
        </div>
      </div>
    </div>
  );
}

// Role-based navigation helper
export const getRoleBasedNavigation = (userRole: string) => {
  const baseNav = [
    { path: "/dashboard", icon: "Home", label: "Dashboard" },
    { path: "/dashboard/profile", icon: "User", label: "Profile" },
    { path: "/dashboard/settings", icon: "Settings", label: "Settings" },
    { path: "/dashboard/messages", icon: "MessageSquare", label: "Messages" },
    { path: "/dashboard/notifications", icon: "Bell", label: "Notifications" },
    { path: "/dashboard/help", icon: "HelpCircle", label: "Help" }
  ];

  const roleSpecificNav = {
    nurse: [
      { path: "/dashboard/shifts", icon: "Calendar", label: "Find Shifts" },
      { path: "/dashboard/shift-calendar", icon: "Calendar", label: "Shift Calendar" },
      { path: "/dashboard/timesheets", icon: "ClipboardList", label: "Timesheets" },
      { path: "/dashboard/my-credentials", icon: "Award", label: "My Credentials" },
      { path: "/dashboard/payouts", icon: "CreditCard", label: "Payouts" },
      { path: "/dashboard/referrals", icon: "Users", label: "Referrals" }
    ],
    facility: [
      { path: "/dashboard/post-shift", icon: "Plus", label: "Post Shift" },
      { path: "/dashboard/applicants", icon: "Users", label: "Review Applicants" },
      { path: "/dashboard/timesheet-approval", icon: "ClipboardList", label: "Approve Timesheets" },
      { path: "/dashboard/shift-management", icon: "Calendar", label: "Manage Shifts" },
      { path: "/dashboard/payouts", icon: "CreditCard", label: "Payouts" }
    ],
    admin: [
      { path: "/platform-admin", icon: "Shield", label: "Platform Admin" },
      { path: "/platform-admin/users", icon: "Users", label: "User Management" },
      { path: "/platform-admin/verifications", icon: "CheckCircle", label: "Verifications" },
      { path: "/platform-admin/analytics", icon: "BarChart3", label: "Analytics" },
      { path: "/platform-admin/settings", icon: "Settings", label: "Platform Settings" }
    ]
  };

  return [...baseNav, ...(roleSpecificNav[userRole as keyof typeof roleSpecificNav] || [])];
};

export default RoleGuard;
