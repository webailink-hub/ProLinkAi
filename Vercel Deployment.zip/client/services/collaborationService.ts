import {
  doc,
  collection,
  onSnapshot,
  setDoc,
  updateDoc,
  deleteDoc,
  addDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";
import { db } from "../lib/firebase";

export interface CollaborationDocument {
  id: string;
  title: string;
  content: any;
  projectId: string;
  lastModified: Timestamp;
  lastModifiedBy: string;
  collaborators: string[];
  isLocked: boolean;
  lockedBy?: string;
  version: number;
}

export interface PresenceUser {
  id: string;
  name: string;
  email: string;
  cursor?: { x: number; y: number };
  selection?: any;
  lastSeen: Timestamp;
  projectId: string;
  color: string;
}

class CollaborationService {
  // Real-time document collaboration
  subscribeToDocument(
    documentId: string,
    callback: (doc: CollaborationDocument | null) => void,
  ) {
    const docRef = doc(db, "collaborations", documentId);
    return onSnapshot(docRef, (snapshot) => {
      if (snapshot.exists()) {
        callback({
          id: snapshot.id,
          ...snapshot.data(),
        } as CollaborationDocument);
      } else {
        callback(null);
      }
    });
  }

  // Update document content with operational transform
  async updateDocument(
    documentId: string,
    updates: Partial<CollaborationDocument>,
    userId: string,
  ) {
    const docRef = doc(db, "collaborations", documentId);
    await updateDoc(docRef, {
      ...updates,
      lastModified: serverTimestamp(),
      lastModifiedBy: userId,
      version: (updates.version || 0) + 1,
    });
  }

  // Create new collaboration document
  async createDocument(
    projectId: string,
    title: string,
    userId: string,
  ): Promise<string> {
    const docRef = await addDoc(collection(db, "collaborations"), {
      title,
      content: {},
      projectId,
      lastModified: serverTimestamp(),
      lastModifiedBy: userId,
      collaborators: [userId],
      isLocked: false,
      version: 1,
    });
    return docRef.id;
  }

  // Lock/unlock document for editing
  async lockDocument(documentId: string, userId: string) {
    const docRef = doc(db, "collaborations", documentId);
    await updateDoc(docRef, {
      isLocked: true,
      lockedBy: userId,
    });
  }

  async unlockDocument(documentId: string) {
    const docRef = doc(db, "collaborations", documentId);
    await updateDoc(docRef, {
      isLocked: false,
      lockedBy: null,
    });
  }

  // Presence management
  async updatePresence(
    userId: string,
    projectId: string,
    presenceData: Partial<PresenceUser>,
  ) {
    const presenceRef = doc(db, "presence", userId);
    await setDoc(
      presenceRef,
      {
        ...presenceData,
        id: userId,
        projectId,
        lastSeen: serverTimestamp(),
      },
      { merge: true },
    );
  }

  subscribeToPresence(
    projectId: string,
    callback: (users: PresenceUser[]) => void,
  ) {
    const presenceQuery = query(
      collection(db, "presence"),
      where("projectId", "==", projectId),
      orderBy("lastSeen", "desc"),
    );

    return onSnapshot(presenceQuery, (snapshot) => {
      const users = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as PresenceUser[];
      callback(users);
    });
  }

  async removePresence(userId: string) {
    const presenceRef = doc(db, "presence", userId);
    await deleteDoc(presenceRef);
  }

  // Project collaboration
  subscribeToProjectDocuments(
    projectId: string,
    callback: (documents: CollaborationDocument[]) => void,
  ) {
    const docsQuery = query(
      collection(db, "collaborations"),
      where("projectId", "==", projectId),
      orderBy("lastModified", "desc"),
    );

    return onSnapshot(docsQuery, (snapshot) => {
      const documents = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as CollaborationDocument[];
      callback(documents);
    });
  }
}

export const collaborationService = new CollaborationService();
