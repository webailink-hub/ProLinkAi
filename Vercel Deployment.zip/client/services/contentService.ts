import {
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";
import { db } from "../lib/firebase";

export interface ContentItem {
  id: string;
  title: string;
  type: "page" | "component" | "asset" | "template";
  content: any;
  slug: string;
  status: "draft" | "published" | "archived";
  tags: string[];
  createdAt: Timestamp;
  updatedAt: Timestamp;
  createdBy: string;
  updatedBy: string;
  metadata: {
    description?: string;
    thumbnail?: string;
    version: number;
    parentId?: string;
    order?: number;
  };
}

export interface Project {
  id: string;
  name: string;
  description: string;
  type: "website" | "app" | "component-library";
  settings: {
    theme: any;
    breakpoints: any;
    globals: any;
  };
  createdAt: Timestamp;
  updatedAt: Timestamp;
  members: ProjectMember[];
}

export interface ProjectMember {
  userId: string;
  email: string;
  role: "owner" | "editor" | "viewer";
  joinedAt: Timestamp;
}

class ContentService {
  // Content CRUD operations
  async createContent(
    content: Omit<ContentItem, "id" | "createdAt" | "updatedAt">,
  ): Promise<string> {
    const docRef = await addDoc(collection(db, "content"), {
      ...content,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  }

  async getContent(contentId: string): Promise<ContentItem | null> {
    const docRef = doc(db, "content", contentId);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as ContentItem;
    }
    return null;
  }

  async updateContent(
    contentId: string,
    updates: Partial<ContentItem>,
  ): Promise<void> {
    const docRef = doc(db, "content", contentId);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: serverTimestamp(),
      "metadata.version": (updates.metadata?.version || 0) + 1,
    });
  }

  async deleteContent(contentId: string): Promise<void> {
    const docRef = doc(db, "content", contentId);
    await deleteDoc(docRef);
  }

  // Query content
  async getContentByType(
    type: ContentItem["type"],
    maxResults = 50,
  ): Promise<ContentItem[]> {
    const q = query(
      collection(db, "content"),
      where("type", "==", type),
      orderBy("updatedAt", "desc"),
      limit(maxResults),
    );

    const snapshot = await getDocs(q);
    return snapshot.docs.map(
      (doc) => ({ id: doc.id, ...doc.data() }) as ContentItem,
    );
  }

  async getContentByStatus(
    status: ContentItem["status"],
    maxResults = 50,
  ): Promise<ContentItem[]> {
    const q = query(
      collection(db, "content"),
      where("status", "==", status),
      orderBy("updatedAt", "desc"),
      limit(maxResults),
    );

    const snapshot = await getDocs(q);
    return snapshot.docs.map(
      (doc) => ({ id: doc.id, ...doc.data() }) as ContentItem,
    );
  }

  async searchContent(searchTerm: string): Promise<ContentItem[]> {
    // Note: This is a simple implementation. For production, use Algolia or similar
    const q = query(collection(db, "content"), orderBy("updatedAt", "desc"));

    const snapshot = await getDocs(q);
    const allContent = snapshot.docs.map(
      (doc) => ({ id: doc.id, ...doc.data() }) as ContentItem,
    );

    return allContent.filter(
      (item) =>
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.tags.some((tag) =>
          tag.toLowerCase().includes(searchTerm.toLowerCase()),
        ) ||
        (item.metadata.description &&
          item.metadata.description
            .toLowerCase()
            .includes(searchTerm.toLowerCase())),
    );
  }

  // Real-time subscriptions
  subscribeToContent(callback: (content: ContentItem[]) => void) {
    const q = query(collection(db, "content"), orderBy("updatedAt", "desc"));

    return onSnapshot(q, (snapshot) => {
      const content = snapshot.docs.map(
        (doc) => ({ id: doc.id, ...doc.data() }) as ContentItem,
      );
      callback(content);
    });
  }

  subscribeToContentItem(
    contentId: string,
    callback: (content: ContentItem | null) => void,
  ) {
    const docRef = doc(db, "content", contentId);
    return onSnapshot(docRef, (snapshot) => {
      if (snapshot.exists()) {
        callback({ id: snapshot.id, ...snapshot.data() } as ContentItem);
      } else {
        callback(null);
      }
    });
  }

  // Project management
  async createProject(
    project: Omit<Project, "id" | "createdAt" | "updatedAt">,
  ): Promise<string> {
    const docRef = await addDoc(collection(db, "projects"), {
      ...project,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  }

  async getProject(projectId: string): Promise<Project | null> {
    const docRef = doc(db, "projects", projectId);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as Project;
    }
    return null;
  }

  async updateProject(
    projectId: string,
    updates: Partial<Project>,
  ): Promise<void> {
    const docRef = doc(db, "projects", projectId);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: serverTimestamp(),
    });
  }

  async getUserProjects(userId: string): Promise<Project[]> {
    const q = query(
      collection(db, "projects"),
      where("members", "array-contains", { userId }),
      orderBy("updatedAt", "desc"),
    );

    const snapshot = await getDocs(q);
    return snapshot.docs.map(
      (doc) => ({ id: doc.id, ...doc.data() }) as Project,
    );
  }

  // Component library management
  async getComponentLibrary(): Promise<ContentItem[]> {
    return this.getContentByType("component");
  }

  async getTemplates(): Promise<ContentItem[]> {
    return this.getContentByType("template");
  }

  // Publishing
  async publishContent(contentId: string, userId: string): Promise<void> {
    await this.updateContent(contentId, {
      status: "published",
      updatedBy: userId,
    });
  }

  async unpublishContent(contentId: string, userId: string): Promise<void> {
    await this.updateContent(contentId, {
      status: "draft",
      updatedBy: userId,
    });
  }

  // Duplication
  async duplicateContent(contentId: string, userId: string): Promise<string> {
    const original = await this.getContent(contentId);
    if (!original) throw new Error("Content not found");

    const duplicate = {
      ...original,
      title: `${original.title} (Copy)`,
      slug: `${original.slug}-copy-${Date.now()}`,
      status: "draft" as const,
      createdBy: userId,
      updatedBy: userId,
      metadata: {
        ...original.metadata,
        version: 1,
        parentId: original.id,
      },
    };

    // Remove the id since we're creating a new document
    const { id, createdAt, updatedAt, ...contentToCreate } = duplicate;

    return this.createContent(contentToCreate);
  }
}

export const contentService = new ContentService();
