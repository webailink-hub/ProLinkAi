import { initializeApp } from "firebase/app";
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore";
import { getAuth, connectAuthEmulator } from "firebase/auth";
import { getStorage, connectStorageEmulator } from "firebase/storage";
import { getFunctions, connectFunctionsEmulator } from "firebase/functions";

// Your Firebase config with actual credentials
const firebaseConfig = {
  apiKey:
    import.meta.env.VITE_FIREBASE_API_KEY ||
    "AIzaSyCeBx_7IXk5IDBCuPVWmc_T3Pry9Za3Xys",
  authDomain: "regdev15-30zxb.firebaseapp.com",
  projectId: "regdev15-30zxb",
  storageBucket: "regdev15-30zxb.appspot.com",
  messagingSenderId:
    import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "990079922500",
  appId:
    import.meta.env.VITE_FIREBASE_APP_ID ||
    "1:990079922500:web:39d3ce683482d99e7d6711",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const functions = getFunctions(app);

// Export initialization status
export const isFirebaseInitialized = () => {
  return !!(app && db && auth && storage && functions);
};

// Track emulator connection status
const emulatorConnected = {
  firestore: false,
  auth: false,
  storage: false,
  functions: false,
};

// Connect to emulators in development (only if explicitly enabled)
const useEmulators = import.meta.env.VITE_USE_FIREBASE_EMULATORS === "true";

if (import.meta.env.DEV && typeof window !== "undefined" && useEmulators) {
  console.log("🔧 Connecting to Firebase emulators...");

  // Connect to Firestore emulator
  if (!emulatorConnected.firestore) {
    try {
      connectFirestoreEmulator(db, "localhost", 8080);
      emulatorConnected.firestore = true;
      console.log("✅ Connected to Firestore emulator");
    } catch (error) {
      console.log(
        "❌ Firestore emulator connection failed or already connected:",
        error,
      );
    }
  }

  // Connect to Auth emulator
  if (!emulatorConnected.auth) {
    try {
      connectAuthEmulator(auth, "http://localhost:9099");
      emulatorConnected.auth = true;
      console.log("✅ Connected to Auth emulator");
    } catch (error) {
      console.log(
        "❌ Auth emulator connection failed or already connected:",
        error,
      );
    }
  }

  // Connect to Storage emulator
  if (!emulatorConnected.storage) {
    try {
      connectStorageEmulator(storage, "localhost", 9199);
      emulatorConnected.storage = true;
      console.log("✅ Connected to Storage emulator");
    } catch (error) {
      console.log(
        "❌ Storage emulator connection failed or already connected:",
        error,
      );
    }
  }

  // Connect to Functions emulator
  if (!emulatorConnected.functions) {
    try {
      connectFunctionsEmulator(functions, "localhost", 5001);
      emulatorConnected.functions = true;
      console.log("✅ Connected to Functions emulator");
    } catch (error) {
      console.log(
        "❌ Functions emulator connection failed or already connected:",
        error,
      );
    }
  }
} else {
  console.log(
    "🌐 Using production Firebase services for project: regdev15-30zxb",
  );
}

export default app;
