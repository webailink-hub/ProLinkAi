import { Outlet, Link, useLocation } from "react-router-dom";
import {
  Brain,
  Calendar,
  User,
  Settings,
  MessageSquare,
  Bell,
  HelpCircle,
  Users,
  ClipboardList,
  CreditCard,
  Award,
  Plus,
  BarChart3,
  Shield,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";

// Mock user data - in real app this would come from context/auth
const mockUser = {
  role: "nurse", // 'nurse', 'facility', 'admin'
  name: "Dr. Sarah Johnson",
  avatar: null,
};

export default function DashboardLayout() {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const isActive = (path: string) => {
    return (
      location.pathname === path || location.pathname.startsWith(path + "/")
    );
  };

  const navItems = {
    shared: [
      { path: "/dashboard", icon: BarChart3, label: "Dashboard", exact: true },
      { path: "/dashboard/messages", icon: MessageSquare, label: "Messages" },
      { path: "/dashboard/notifications", icon: Bell, label: "Notifications" },
      { path: "/dashboard/profile", icon: User, label: "Profile" },
      { path: "/dashboard/settings", icon: Settings, label: "Settings" },
      { path: "/dashboard/help", icon: HelpCircle, label: "AI Support" },
      { path: "/dashboard/referrals", icon: Users, label: "Referrals" },
    ],
    nurse: [
      { path: "/dashboard/shifts", icon: Calendar, label: "Find Shifts" },
      {
        path: "/dashboard/shift-calendar",
        icon: Calendar,
        label: "Shift Calendar",
      },
      {
        path: "/dashboard/timesheets",
        icon: ClipboardList,
        label: "Timesheets",
      },
      { path: "/dashboard/my-credentials", icon: Award, label: "Credentials" },
      { path: "/dashboard/payouts", icon: CreditCard, label: "Payouts" },
    ],
    facility: [
      { path: "/dashboard/post-shift", icon: Plus, label: "Post Shift" },
      { path: "/dashboard/applicants", icon: Users, label: "Applicants" },
      {
        path: "/dashboard/timesheet-approval",
        icon: ClipboardList,
        label: "Approve Timesheets",
      },
    ],
    admin: [
      { path: "/dashboard/admin", icon: Shield, label: "Admin Panel" },
      { path: "/dashboard/admin/users", icon: Users, label: "User Management" },
      {
        path: "/dashboard/admin/audit-trail",
        icon: ClipboardList,
        label: "Audit Trail",
      },
      {
        path: "/dashboard/shift-management",
        icon: Calendar,
        label: "Shift Management",
      },
    ],
  };

  const getNavItems = () => {
    const items = [...navItems.shared];
    if (mockUser.role === "nurse") items.splice(1, 0, ...navItems.nurse);
    if (mockUser.role === "facility") items.splice(1, 0, ...navItems.facility);
    if (mockUser.role === "admin") items.push(...navItems.admin);
    return items;
  };

  return (
    <div className="min-h-screen bg-medical-gray safe-area-padding">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden touch-manipulation"
          onClick={() => setSidebarOpen(false)}
          onTouchEnd={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-64 sm:w-72 bg-white shadow-lg transform transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:inset-0 lg:w-64 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between h-16 px-4 sm:px-6 border-b border-gray-200">
            <Link to="/" className="flex items-center">
              <div className="w-8 h-8 bg-gradient-to-br from-medical-blue to-ai-purple rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <span className="ml-2 text-lg font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1 rounded-lg hover:bg-gray-100 touch-manipulation"
              aria-label="Close sidebar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* User info */}
          <div className="p-4 sm:p-6 border-b border-gray-200">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {mockUser.name}
                </p>
                <p className="text-xs text-gray-500 capitalize">
                  {mockUser.role}
                </p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-3 sm:px-4 py-4 space-y-1 sm:space-y-2 overflow-y-auto">
            {getNavItems().map((item) => {
              const Icon = item.icon;
              const active = item.exact
                ? location.pathname === item.path
                : isActive(item.path);

              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center px-3 py-3 sm:py-2 text-sm font-medium rounded-lg transition-colors touch-manipulation ${
                    active
                      ? "bg-gradient-to-r from-medical-blue to-ai-purple text-white"
                      : "text-gray-600 hover:bg-gray-100 hover:text-gray-900 active:bg-gray-200"
                  }`}
                  onClick={() => setSidebarOpen(false)}
                >
                  <Icon
                    className={`w-5 h-5 mr-3 flex-shrink-0 ${active ? "text-white" : "text-gray-400"}`}
                  />
                  <span className="truncate">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Logout */}
          <div className="p-3 sm:p-4 border-t border-gray-200">
            <Link
              to="/login"
              className="flex items-center px-3 py-3 sm:py-2 text-sm font-medium text-gray-600 rounded-lg hover:bg-gray-100 hover:text-gray-900 active:bg-gray-200 transition-colors touch-manipulation"
              onClick={() => setSidebarOpen(false)}
            >
              <LogOut className="w-5 h-5 mr-3 text-gray-400 flex-shrink-0" />
              <span className="truncate">Sign Out</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:ml-64">
        {/* Top navigation */}
        <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-10">
          <div className="flex items-center justify-between h-16 px-4 sm:px-6">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg hover:bg-gray-100 active:bg-gray-200 transition-colors touch-manipulation"
              aria-label="Open sidebar"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-4">
              {/* Quick actions could go here */}
              <div className="text-sm text-gray-500 hidden sm:block">
                Welcome back, {mockUser.name.split(" ")[1]}
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 sm:p-6 min-h-screen bg-medical-gray">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
