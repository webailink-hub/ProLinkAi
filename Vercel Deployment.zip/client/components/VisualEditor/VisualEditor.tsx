import React, { useState, useRef, useCallback, useEffect } from "react";
import {
  Layers,
  Type,
  Square,
  Circle,
  Image,
  Undo,
  Redo,
  Save,
  Users,
  Eye,
  EyeOff,
  Lock,
  Unlock,
} from "lucide-react";
import { Button } from "../ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import {
  collaborationService,
  PresenceUser,
} from "../../services/collaborationService";
import { useFirebase } from "../../contexts/FirebaseContext";

interface EditorElement {
  id: string;
  type: "text" | "rectangle" | "circle" | "image";
  x: number;
  y: number;
  width: number;
  height: number;
  content?: string;
  style: {
    backgroundColor?: string;
    color?: string;
    fontSize?: number;
    fontWeight?: string;
    border?: string;
    borderRadius?: number;
  };
  locked?: boolean;
  lockedBy?: string;
}

interface VisualEditorProps {
  projectId: string;
  documentId: string;
}

export const VisualEditor: React.FC<VisualEditorProps> = ({
  projectId,
  documentId,
}) => {
  const { user } = useFirebase();
  const canvasRef = useRef<HTMLDivElement>(null);

  const [elements, setElements] = useState<EditorElement[]>([]);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [collaborators, setCollaborators] = useState<PresenceUser[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentTool, setCurrentTool] = useState<
    "select" | "text" | "rectangle" | "circle"
  >("select");
  const [showGrid, setShowGrid] = useState(true);
  const [zoom, setZoom] = useState(1);

  // Real-time collaboration
  useEffect(() => {
    if (!user || !projectId) return;

    // Subscribe to document changes
    const unsubscribeDoc = collaborationService.subscribeToDocument(
      documentId,
      (doc) => {
        if (doc && doc.content && doc.content.elements) {
          setElements(doc.content.elements);
        }
      },
    );

    // Subscribe to presence
    const unsubscribePresence = collaborationService.subscribeToPresence(
      projectId,
      setCollaborators,
    );

    // Update own presence
    collaborationService.updatePresence(user.uid, projectId, {
      name: user.displayName || user.email || "Anonymous",
      email: user.email || "",
      color: generateUserColor(user.uid),
    });

    return () => {
      unsubscribeDoc();
      unsubscribePresence();
      collaborationService.removePresence(user.uid);
    };
  }, [user, projectId, documentId]);

  const generateUserColor = (userId: string) => {
    const colors = [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#96CEB4",
      "#FFEAA7",
      "#DDA0DD",
      "#98D8C8",
    ];
    const index =
      userId.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0) %
      colors.length;
    return colors[index];
  };

  const saveDocument = useCallback(async () => {
    if (!user) return;

    await collaborationService.updateDocument(
      documentId,
      {
        content: { elements },
      },
      user.uid,
    );
  }, [elements, documentId, user]);

  const addElement = useCallback(
    (type: EditorElement["type"], x: number, y: number) => {
      const newElement: EditorElement = {
        id: `element_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        type,
        x,
        y,
        width: type === "text" ? 200 : 100,
        height: type === "text" ? 50 : 100,
        content: type === "text" ? "Double click to edit" : undefined,
        style: {
          backgroundColor: type === "text" ? "transparent" : "#e2e8f0",
          color: "#1f2937",
          fontSize: 16,
          fontWeight: "normal",
          border: "1px solid #d1d5db",
          borderRadius: type === "circle" ? 50 : 4,
        },
      };

      setElements((prev) => [...prev, newElement]);
      setSelectedElement(newElement.id);
    },
    [],
  );

  const updateElement = useCallback(
    (id: string, updates: Partial<EditorElement>) => {
      setElements((prev) =>
        prev.map((el) => (el.id === id ? { ...el, ...updates } : el)),
      );
    },
    [],
  );

  const deleteElement = useCallback((id: string) => {
    setElements((prev) => prev.filter((el) => el.id !== id));
    setSelectedElement(null);
  }, []);

  const handleCanvasClick = useCallback(
    (e: React.MouseEvent) => {
      if (!canvasRef.current) return;

      const rect = canvasRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left) / zoom;
      const y = (e.clientY - rect.top) / zoom;

      if (currentTool !== "select") {
        addElement(currentTool as EditorElement["type"], x, y);
        setCurrentTool("select");
      } else {
        setSelectedElement(null);
      }
    },
    [currentTool, zoom, addElement],
  );

  const handleElementClick = useCallback(
    (e: React.MouseEvent, elementId: string) => {
      e.stopPropagation();
      setSelectedElement(elementId);
    },
    [],
  );

  // Auto-save every 5 seconds
  useEffect(() => {
    const interval = setInterval(saveDocument, 5000);
    return () => clearInterval(interval);
  }, [saveDocument]);

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Toolbar */}
      <div className="w-16 bg-white border-r border-gray-200 flex flex-col items-center py-4 space-y-2">
        <Button
          variant={currentTool === "select" ? "default" : "ghost"}
          size="sm"
          onClick={() => setCurrentTool("select")}
          className="w-10 h-10 p-0"
        >
          <Layers className="w-4 h-4" />
        </Button>

        <Button
          variant={currentTool === "text" ? "default" : "ghost"}
          size="sm"
          onClick={() => setCurrentTool("text")}
          className="w-10 h-10 p-0"
        >
          <Type className="w-4 h-4" />
        </Button>

        <Button
          variant={currentTool === "rectangle" ? "default" : "ghost"}
          size="sm"
          onClick={() => setCurrentTool("rectangle")}
          className="w-10 h-10 p-0"
        >
          <Square className="w-4 h-4" />
        </Button>

        <Button
          variant={currentTool === "circle" ? "default" : "ghost"}
          size="sm"
          onClick={() => setCurrentTool("circle")}
          className="w-10 h-10 p-0"
        >
          <Circle className="w-4 h-4" />
        </Button>

        <div className="border-t border-gray-200 pt-2 space-y-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowGrid(!showGrid)}
            className="w-10 h-10 p-0"
          >
            {showGrid ? (
              <Eye className="w-4 h-4" />
            ) : (
              <EyeOff className="w-4 h-4" />
            )}
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={saveDocument}
            className="w-10 h-10 p-0"
          >
            <Save className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 flex flex-col">
        {/* Top bar */}
        <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h2 className="font-semibold text-gray-900">Visual Editor</h2>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-500">Zoom:</span>
              <select
                value={zoom}
                onChange={(e) => setZoom(Number(e.target.value))}
                className="text-sm border border-gray-300 rounded px-2 py-1"
              >
                <option value={0.5}>50%</option>
                <option value={0.75}>75%</option>
                <option value={1}>100%</option>
                <option value={1.25}>125%</option>
                <option value={1.5}>150%</option>
                <option value={2}>200%</option>
              </select>
            </div>
          </div>

          {/* Collaborators */}
          <div className="flex items-center space-x-2">
            <Users className="w-4 h-4 text-gray-500" />
            <div className="flex -space-x-2">
              {collaborators.slice(0, 5).map((collaborator) => (
                <div
                  key={collaborator.id}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium text-white border-2 border-white"
                  style={{ backgroundColor: collaborator.color }}
                  title={collaborator.name}
                >
                  {collaborator.name.charAt(0).toUpperCase()}
                </div>
              ))}
              {collaborators.length > 5 && (
                <div className="w-8 h-8 rounded-full bg-gray-400 flex items-center justify-center text-xs font-medium text-white border-2 border-white">
                  +{collaborators.length - 5}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Canvas area */}
        <div
          ref={canvasRef}
          className="flex-1 relative overflow-auto bg-white"
          onClick={handleCanvasClick}
          style={{
            backgroundImage: showGrid
              ? "radial-gradient(circle, #e5e7eb 1px, transparent 1px)"
              : "none",
            backgroundSize: showGrid ? "20px 20px" : "auto",
            transform: `scale(${zoom})`,
            transformOrigin: "top left",
          }}
        >
          {/* Render elements */}
          {elements.map((element) => (
            <div
              key={element.id}
              className={`absolute cursor-pointer border-2 ${
                selectedElement === element.id
                  ? "border-blue-500"
                  : "border-transparent hover:border-gray-300"
              }`}
              style={{
                left: element.x,
                top: element.y,
                width: element.width,
                height: element.height,
                backgroundColor: element.style.backgroundColor,
                color: element.style.color,
                fontSize: element.style.fontSize,
                fontWeight: element.style.fontWeight,
                borderRadius: element.style.borderRadius,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
              onClick={(e) => handleElementClick(e, element.id)}
            >
              {element.type === "text" && (
                <div className="w-full h-full p-2 outline-none" contentEditable>
                  {element.content}
                </div>
              )}

              {element.locked && (
                <div className="absolute top-1 right-1">
                  <Lock className="w-3 h-3 text-red-500" />
                </div>
              )}
            </div>
          ))}

          {/* Collaborator cursors */}
          {collaborators.map(
            (collaborator) =>
              collaborator.cursor && (
                <div
                  key={`cursor-${collaborator.id}`}
                  className="absolute pointer-events-none z-50"
                  style={{
                    left: collaborator.cursor.x,
                    top: collaborator.cursor.y,
                    transform: "translate(-2px, -2px)",
                  }}
                >
                  <div
                    className="w-4 h-4 rounded-full border-2 border-white"
                    style={{ backgroundColor: collaborator.color }}
                  />
                  <div
                    className="text-xs px-2 py-1 rounded mt-1 text-white whitespace-nowrap"
                    style={{ backgroundColor: collaborator.color }}
                  >
                    {collaborator.name}
                  </div>
                </div>
              ),
          )}
        </div>
      </div>

      {/* Properties panel */}
      {selectedElement && (
        <div className="w-80 bg-white border-l border-gray-200 p-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Properties</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {(() => {
                const element = elements.find(
                  (el) => el.id === selectedElement,
                );
                if (!element) return null;

                return (
                  <>
                    <div>
                      <label className="text-sm font-medium text-gray-700">
                        Type
                      </label>
                      <p className="text-sm text-gray-500 capitalize">
                        {element.type}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-sm font-medium text-gray-700">
                          X
                        </label>
                        <input
                          type="number"
                          value={element.x}
                          onChange={(e) =>
                            updateElement(element.id, {
                              x: Number(e.target.value),
                            })
                          }
                          className="w-full text-sm border border-gray-300 rounded px-2 py-1"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700">
                          Y
                        </label>
                        <input
                          type="number"
                          value={element.y}
                          onChange={(e) =>
                            updateElement(element.id, {
                              y: Number(e.target.value),
                            })
                          }
                          className="w-full text-sm border border-gray-300 rounded px-2 py-1"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-sm font-medium text-gray-700">
                          Width
                        </label>
                        <input
                          type="number"
                          value={element.width}
                          onChange={(e) =>
                            updateElement(element.id, {
                              width: Number(e.target.value),
                            })
                          }
                          className="w-full text-sm border border-gray-300 rounded px-2 py-1"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700">
                          Height
                        </label>
                        <input
                          type="number"
                          value={element.height}
                          onChange={(e) =>
                            updateElement(element.id, {
                              height: Number(e.target.value),
                            })
                          }
                          className="w-full text-sm border border-gray-300 rounded px-2 py-1"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-700">
                        Background Color
                      </label>
                      <input
                        type="color"
                        value={element.style.backgroundColor || "#e2e8f0"}
                        onChange={(e) =>
                          updateElement(element.id, {
                            style: {
                              ...element.style,
                              backgroundColor: e.target.value,
                            },
                          })
                        }
                        className="w-full h-8 border border-gray-300 rounded"
                      />
                    </div>

                    {element.type === "text" && (
                      <>
                        <div>
                          <label className="text-sm font-medium text-gray-700">
                            Font Size
                          </label>
                          <input
                            type="number"
                            value={element.style.fontSize || 16}
                            onChange={(e) =>
                              updateElement(element.id, {
                                style: {
                                  ...element.style,
                                  fontSize: Number(e.target.value),
                                },
                              })
                            }
                            className="w-full text-sm border border-gray-300 rounded px-2 py-1"
                          />
                        </div>

                        <div>
                          <label className="text-sm font-medium text-gray-700">
                            Text Color
                          </label>
                          <input
                            type="color"
                            value={element.style.color || "#1f2937"}
                            onChange={(e) =>
                              updateElement(element.id, {
                                style: {
                                  ...element.style,
                                  color: e.target.value,
                                },
                              })
                            }
                            className="w-full h-8 border border-gray-300 rounded"
                          />
                        </div>
                      </>
                    )}

                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteElement(element.id)}
                      className="w-full"
                    >
                      Delete Element
                    </Button>
                  </>
                );
              })()}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};
