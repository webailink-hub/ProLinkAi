import React, { useState, useEffect } from "react";
import {
  Plus,
  Search,
  Filter,
  Grid,
  List,
  Eye,
  Edit,
  Trash2,
  Copy,
  Upload,
  Download,
  Tag,
  Calendar,
  User,
  Globe,
  Archive,
} from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { contentService, ContentItem } from "../../services/contentService";
import { useFirebase } from "../../contexts/FirebaseContext";

interface ContentManagerProps {
  projectId?: string;
}

export const ContentManager: React.FC<ContentManagerProps> = ({
  projectId,
}) => {
  const { user } = useFirebase();
  const [content, setContent] = useState<ContentItem[]>([]);
  const [filteredContent, setFilteredContent] = useState<ContentItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<ContentItem["type"] | "all">(
    "all",
  );
  const [filterStatus, setFilterStatus] = useState<
    ContentItem["status"] | "all"
  >("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [loading, setLoading] = useState(true);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);

  // Load content
  useEffect(() => {
    const unsubscribe = contentService.subscribeToContent((newContent) => {
      setContent(newContent);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  // Filter content
  useEffect(() => {
    let filtered = content;

    if (searchTerm) {
      filtered = filtered.filter(
        (item) =>
          item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.tags.some((tag) =>
            tag.toLowerCase().includes(searchTerm.toLowerCase()),
          ),
      );
    }

    if (filterType !== "all") {
      filtered = filtered.filter((item) => item.type === filterType);
    }

    if (filterStatus !== "all") {
      filtered = filtered.filter((item) => item.status === filterStatus);
    }

    setFilteredContent(filtered);
  }, [content, searchTerm, filterType, filterStatus]);

  const handleCreateContent = async (type: ContentItem["type"]) => {
    if (!user) return;

    const newContent = {
      title: `New ${type.charAt(0).toUpperCase() + type.slice(1)}`,
      type,
      content: type === "page" ? { blocks: [] } : {},
      slug: `new-${type}-${Date.now()}`,
      status: "draft" as const,
      tags: [],
      createdBy: user.uid,
      updatedBy: user.uid,
      metadata: {
        description: "",
        version: 1,
        order: 0,
      },
    };

    try {
      await contentService.createContent(newContent);
    } catch (error) {
      console.error("Error creating content:", error);
    }
  };

  const handleDuplicate = async (contentId: string) => {
    if (!user) return;

    try {
      await contentService.duplicateContent(contentId, user.uid);
    } catch (error) {
      console.error("Error duplicating content:", error);
    }
  };

  const handleDelete = async (contentId: string) => {
    if (!confirm("Are you sure you want to delete this item?")) return;

    try {
      await contentService.deleteContent(contentId);
    } catch (error) {
      console.error("Error deleting content:", error);
    }
  };

  const handlePublish = async (contentId: string) => {
    if (!user) return;

    try {
      await contentService.publishContent(contentId, user.uid);
    } catch (error) {
      console.error("Error publishing content:", error);
    }
  };

  const handleUnpublish = async (contentId: string) => {
    if (!user) return;

    try {
      await contentService.unpublishContent(contentId, user.uid);
    } catch (error) {
      console.error("Error unpublishing content:", error);
    }
  };

  const getStatusColor = (status: ContentItem["status"]) => {
    switch (status) {
      case "published":
        return "bg-green-100 text-green-800";
      case "draft":
        return "bg-yellow-100 text-yellow-800";
      case "archived":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: ContentItem["type"]) => {
    switch (type) {
      case "page":
        return <Globe className="w-4 h-4" />;
      case "component":
        return <Grid className="w-4 h-4" />;
      case "template":
        return <Copy className="w-4 h-4" />;
      case "asset":
        return <Upload className="w-4 h-4" />;
      default:
        return <Grid className="w-4 h-4" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Content Manager</h1>
          <p className="text-gray-600">
            Manage your pages, components, templates, and assets
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={() => handleCreateContent("page")}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Page
          </Button>

          <div className="relative group">
            <Button variant="outline" className="w-10 h-10 p-0">
              <Plus className="w-4 h-4" />
            </Button>

            <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
              <div className="py-1">
                <button
                  onClick={() => handleCreateContent("component")}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Grid className="w-4 h-4 mr-3" />
                  New Component
                </button>
                <button
                  onClick={() => handleCreateContent("template")}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Copy className="w-4 h-4 mr-3" />
                  New Template
                </button>
                <button
                  onClick={() => handleCreateContent("asset")}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Upload className="w-4 h-4 mr-3" />
                  Upload Asset
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search content..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={filterType}
            onChange={(e) =>
              setFilterType(e.target.value as ContentItem["type"] | "all")
            }
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Types</option>
            <option value="page">Pages</option>
            <option value="component">Components</option>
            <option value="template">Templates</option>
            <option value="asset">Assets</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) =>
              setFilterStatus(e.target.value as ContentItem["status"] | "all")
            }
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Status</option>
            <option value="published">Published</option>
            <option value="draft">Draft</option>
            <option value="archived">Archived</option>
          </select>

          <div className="flex border border-gray-300 rounded-md">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className="rounded-r-none"
            >
              <Grid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="rounded-l-none"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Content Display */}
      {viewMode === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredContent.map((item) => (
            <Card key={item.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    {getTypeIcon(item.type)}
                    <CardTitle className="text-base truncate">
                      {item.title}
                    </CardTitle>
                  </div>
                  <Badge className={getStatusColor(item.status)}>
                    {item.status}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-3">
                {item.metadata.description && (
                  <p className="text-sm text-gray-600 line-clamp-2">
                    {item.metadata.description}
                  </p>
                )}

                {item.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {item.tags.slice(0, 3).map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {item.tags.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{item.tags.length - 3}
                      </Badge>
                    )}
                  </div>
                )}

                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>v{item.metadata.version}</span>
                  <span>
                    {item.updatedAt?.toDate
                      ? item.updatedAt.toDate().toLocaleDateString()
                      : "Recently"}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Eye className="w-3 h-3" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Edit className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => handleDuplicate(item.id)}
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                    onClick={() => handleDelete(item.id)}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>

                  {item.status === "draft" ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-green-600"
                      onClick={() => handlePublish(item.id)}
                    >
                      <Globe className="w-3 h-3" />
                    </Button>
                  ) : (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-orange-600"
                      onClick={() => handleUnpublish(item.id)}
                    >
                      <Archive className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg border">
          <div className="p-4 border-b bg-gray-50">
            <div className="grid grid-cols-12 gap-4 text-sm font-medium text-gray-700">
              <div className="col-span-4">Name</div>
              <div className="col-span-2">Type</div>
              <div className="col-span-2">Status</div>
              <div className="col-span-2">Updated</div>
              <div className="col-span-1">Version</div>
              <div className="col-span-1">Actions</div>
            </div>
          </div>

          <div className="divide-y">
            {filteredContent.map((item) => (
              <div key={item.id} className="p-4 hover:bg-gray-50">
                <div className="grid grid-cols-12 gap-4 items-center">
                  <div className="col-span-4 flex items-center gap-3">
                    {getTypeIcon(item.type)}
                    <div>
                      <p className="font-medium text-gray-900">{item.title}</p>
                      {item.metadata.description && (
                        <p className="text-sm text-gray-500 truncate">
                          {item.metadata.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="col-span-2">
                    <Badge variant="outline" className="capitalize">
                      {item.type}
                    </Badge>
                  </div>

                  <div className="col-span-2">
                    <Badge className={getStatusColor(item.status)}>
                      {item.status}
                    </Badge>
                  </div>

                  <div className="col-span-2 text-sm text-gray-500">
                    {item.updatedAt?.toDate
                      ? item.updatedAt.toDate().toLocaleDateString()
                      : "Recently"}
                  </div>

                  <div className="col-span-1 text-sm text-gray-500">
                    v{item.metadata.version}
                  </div>

                  <div className="col-span-1 flex items-center gap-1">
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <Eye className="w-3 h-3" />
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0"
                      onClick={() => handleDuplicate(item.id)}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {filteredContent.length === 0 && (
        <div className="text-center py-12">
          <Grid className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No content found
          </h3>
          <p className="text-gray-500 mb-4">
            {searchTerm || filterType !== "all" || filterStatus !== "all"
              ? "Try adjusting your filters or search terms."
              : "Get started by creating your first piece of content."}
          </p>
          {!searchTerm && filterType === "all" && filterStatus === "all" && (
            <Button onClick={() => handleCreateContent("page")}>
              <Plus className="w-4 h-4 mr-2" />
              Create your first page
            </Button>
          )}
        </div>
      )}
    </div>
  );
};
