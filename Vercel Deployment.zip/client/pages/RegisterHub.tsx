import {
  Brain,
  Users,
  Building2,
  ArrowRight,
  CheckCircle2,
  Shield,
  Clock,
  Award,
  Star,
  Zap,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function RegisterHub() {
  return (
    <div className="min-h-screen bg-medical-gray">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            <div className="hidden md:flex items-center space-x-8">
              <Link
                to="/nurses"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                For Nurses
              </Link>
              <Link
                to="/facilities"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                For Facilities
              </Link>
              <Link
                to="/about"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                About
              </Link>
              <Link
                to="/login"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Sign In
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center bg-ai-purple/10 text-ai-purple px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Zap className="w-4 h-4 mr-2" />
              Join 15,000+ Healthcare Professionals
            </div>
            <h1 className="text-4xl lg:text-6xl font-header font-bold text-gray-900 leading-tight mb-6">
              Choose Your Path to
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-medical-blue to-ai-purple block">
                AI-Enhanced Healthcare
              </span>
            </h1>
            <p className="text-xl text-gray-600 font-body leading-relaxed max-w-3xl mx-auto">
              Join the future of healthcare staffing. Select your role below to
              start your personalized onboarding experience with AI-powered
              matching and career growth.
            </p>
          </div>

          {/* Registration Options */}
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Nurse Registration */}
            <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1 border-2 border-transparent hover:border-medical-blue/20">
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-br from-medical-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Users className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-2xl lg:text-3xl font-header font-bold text-gray-900 mb-4">
                  Healthcare Professional
                </h2>
                <p className="text-gray-600 font-body text-lg">
                  RNs, LPNs, CNAs, and other healthcare professionals seeking
                  flexible, rewarding career opportunities
                </p>
              </div>

              {/* Benefits for Nurses */}
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    AI-powered shift matching based on your skills
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    24-hour guaranteed payouts
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    Automated credential management
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    Career growth insights and recommendations
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    Flexible scheduling with work-life balance
                  </span>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-4 p-4 bg-medical-blue/5 rounded-xl mb-8">
                <div className="text-center">
                  <div className="text-lg font-bold text-medical-blue">$52</div>
                  <div className="text-xs text-gray-600">Avg Hourly Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-medical-green">
                    98%
                  </div>
                  <div className="text-xs text-gray-600">Satisfaction Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-ai-purple">5x</div>
                  <div className="text-xs text-gray-600">Faster Matching</div>
                </div>
              </div>

              {/* What to Expect */}
              <div className="mb-8">
                <h3 className="font-header font-semibold text-gray-900 mb-4">
                  What to Expect:
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-600">
                    <Clock className="w-4 h-4 text-medical-blue mr-2" />
                    5-minute signup process
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Shield className="w-4 h-4 text-medical-green mr-2" />
                    Instant credential verification
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Award className="w-4 h-4 text-ai-purple mr-2" />
                    AI profile optimization
                  </div>
                </div>
              </div>

              <Link
                to="/register/nurse"
                className="w-full bg-gradient-to-r from-medical-blue to-ai-purple text-white py-4 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 flex items-center justify-center group"
              >
                Start as Healthcare Professional
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            {/* Facility Registration */}
            <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1 border-2 border-transparent hover:border-medical-green/20">
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-br from-medical-green to-medical-teal rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Building2 className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-2xl lg:text-3xl font-header font-bold text-gray-900 mb-4">
                  Healthcare Facility
                </h2>
                <p className="text-gray-600 font-body text-lg">
                  Hospitals, clinics, long-term care facilities, and other
                  healthcare organizations needing qualified staff
                </p>
              </div>

              {/* Benefits for Facilities */}
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    Fill shifts 50% faster with AI matching
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    Reduce overtime costs by 35%
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    100% verified credentials and compliance
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    Real-time analytics and cost optimization
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-medical-green mr-3 flex-shrink-0" />
                  <span className="text-gray-700 font-body">
                    Predictive staffing recommendations
                  </span>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-4 p-4 bg-medical-green/5 rounded-xl mb-8">
                <div className="text-center">
                  <div className="text-lg font-bold text-medical-green">
                    50%
                  </div>
                  <div className="text-xs text-gray-600">Faster Fill Times</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-medical-blue">
                    $2.1M
                  </div>
                  <div className="text-xs text-gray-600">
                    Avg Annual Savings
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-ai-purple">500+</div>
                  <div className="text-xs text-gray-600">
                    Trusted Facilities
                  </div>
                </div>
              </div>

              {/* What to Expect */}
              <div className="mb-8">
                <h3 className="font-header font-semibold text-gray-900 mb-4">
                  What to Expect:
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-600">
                    <Clock className="w-4 h-4 text-medical-blue mr-2" />
                    10-minute setup process
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Shield className="w-4 h-4 text-medical-green mr-2" />
                    Facility verification and onboarding
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Award className="w-4 h-4 text-ai-purple mr-2" />
                    Custom AI configuration
                  </div>
                </div>
              </div>

              <Link
                to="/register/facility"
                className="w-full bg-gradient-to-r from-medical-green to-medical-teal text-white py-4 rounded-xl hover:from-green-600 hover:to-teal-600 transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 flex items-center justify-center group"
              >
                Start as Healthcare Facility
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>

          {/* Additional Info */}
          <div className="text-center mt-16">
            <p className="text-gray-600 font-body mb-4">
              Already have an account?
              <Link
                to="/login"
                className="text-medical-blue hover:text-blue-700 font-medium ml-1"
              >
                Sign in here
              </Link>
            </p>
            <p className="text-sm text-gray-500 font-body">
              By registering, you agree to our Terms of Service and Privacy
              Policy. Your data is protected with enterprise-grade security.
            </p>
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-header font-bold text-gray-900 mb-4">
              Trusted by Healthcare Leaders Nationwide
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl mx-auto mb-4 flex items-center justify-center">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <p className="font-medium text-gray-900">HIPAA Compliant</p>
              <p className="text-sm text-gray-600">Enterprise Security</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-green to-medical-teal rounded-xl mx-auto mb-4 flex items-center justify-center">
                <Award className="w-8 h-8 text-white" />
              </div>
              <p className="font-medium text-gray-900">Joint Commission</p>
              <p className="text-sm text-gray-600">Partner</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-ai-purple to-accent-orange rounded-xl mx-auto mb-4 flex items-center justify-center">
                <Users className="w-8 h-8 text-white" />
              </div>
              <p className="font-medium text-gray-900">ANA Endorsed</p>
              <p className="text-sm text-gray-600">Nurse Association</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-accent-orange to-medical-green rounded-xl mx-auto mb-4 flex items-center justify-center">
                <Star className="w-8 h-8 text-white" />
              </div>
              <p className="font-medium text-gray-900">4.9/5 Rating</p>
              <p className="text-sm text-gray-600">User Satisfaction</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <span className="ml-3 text-xl font-header font-bold">
                  ProLink<span className="text-ai-purple">Ai</span>
                </span>
              </div>
              <p className="text-gray-400 font-body leading-relaxed mb-6">
                Join the AI revolution in healthcare staffing. Better matches,
                faster fills, smarter careers.
              </p>
              <div className="text-sm text-gray-400 font-body">
                © 2024 ProLinkAi. All rights reserved.
              </div>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-4">Support</h3>
              <ul className="space-y-2 font-body">
                <li>
                  <Link
                    to="/help"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link
                    to="/contact"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/demo"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Request Demo
                  </Link>
                </li>
                <li>
                  <Link
                    to="/status"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    System Status
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 font-body">
                <li>
                  <Link
                    to="/privacy"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link
                    to="/terms"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link
                    to="/security"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Security
                  </Link>
                </li>
                <li>
                  <Link
                    to="/compliance"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Compliance
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
