import React, { useState } from 'react';
import { Plus, Upload, Eye, Download, CheckCircle, AlertTriangle, Clock, Calendar, Award, FileText, Shield, Brain, Filter, Search, RefreshCw, Bell, ExternalLink } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';

interface Credential {
  id: string;
  type: 'license' | 'certification' | 'education' | 'insurance';
  name: string;
  category: string;
  issuingOrganization: string;
  credentialNumber: string;
  issueDate: string;
  expiryDate: string;
  status: 'verified' | 'pending' | 'expired' | 'expiring_soon' | 'rejected';
  verificationLevel: 'basic' | 'enhanced' | 'premium';
  documentUrl?: string;
  thumbnailUrl?: string;
  isRequired: boolean;
  autoRenewal: boolean;
  remindersSent: number;
  nextReminderDate?: string;
  renewalInstructions?: string;
  verifiedBy?: string;
  verifiedDate?: string;
  notes?: string;
  tags: string[];
}

export default function EnhancedCredentials() {
  const [activeTab, setActiveTab] = useState<'overview' | 'licenses' | 'certifications' | 'education' | 'documents'>('overview');
  const [statusFilter, setStatusFilter] = useState<'all' | 'verified' | 'pending' | 'expired' | 'expiring_soon'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showUploadModal, setShowUploadModal] = useState(false);

  const [credentials, setCredentials] = useState<Credential[]>([
    {
      id: '1',
      type: 'license',
      name: 'Registered Nurse License',
      category: 'State Nursing License',
      issuingOrganization: 'California Board of Nursing',
      credentialNumber: 'RN123456',
      issueDate: '2019-05-01',
      expiryDate: '2025-05-01',
      status: 'verified',
      verificationLevel: 'enhanced',
      documentUrl: '/documents/rn-license.pdf',
      thumbnailUrl: 'https://cdn.builder.io/api/v1/image/assets%2F62e0bb8da89646138e5c2294ae392e48%2Fd9f565ec4bf248428543a2af94f806fd?format=webp&width=800',
      isRequired: true,
      autoRenewal: true,
      remindersSent: 0,
      nextReminderDate: '2025-02-01',
      renewalInstructions: 'Complete 30 hours of continuing education and submit renewal application',
      verifiedBy: 'ProLinkAi Verification Team',
      verifiedDate: '2024-02-01',
      tags: ['Primary License', 'California', 'Active']
    },
    {
      id: '2',
      type: 'certification',
      name: 'Basic Life Support (BLS)',
      category: 'CPR/BLS Certification',
      issuingOrganization: 'American Heart Association',
      credentialNumber: 'BLS789012',
      issueDate: '2023-08-15',
      expiryDate: '2025-08-15',
      status: 'verified',
      verificationLevel: 'basic',
      documentUrl: '/documents/bls-cert.pdf',
      isRequired: true,
      autoRenewal: false,
      remindersSent: 0,
      nextReminderDate: '2025-05-15',
      tags: ['AHA', 'Required', 'Current']
    },
    {
      id: '3',
      type: 'certification',
      name: 'Advanced Cardiovascular Life Support (ACLS)',
      category: 'Advanced Life Support',
      issuingOrganization: 'American Heart Association',
      credentialNumber: 'ACLS345678',
      issueDate: '2023-09-20',
      expiryDate: '2025-09-20',
      status: 'verified',
      verificationLevel: 'basic',
      documentUrl: '/documents/acls-cert.pdf',
      isRequired: false,
      autoRenewal: true,
      remindersSent: 0,
      nextReminderDate: '2025-06-20',
      tags: ['AHA', 'ICU', 'Emergency']
    },
    {
      id: '4',
      type: 'certification',
      name: 'Pediatric Advanced Life Support (PALS)',
      category: 'Pediatric Life Support',
      issuingOrganization: 'American Heart Association',
      credentialNumber: 'PALS901234',
      issueDate: '2024-01-10',
      expiryDate: '2026-01-10',
      status: 'verified',
      verificationLevel: 'basic',
      documentUrl: '/documents/pals-cert.pdf',
      isRequired: false,
      autoRenewal: false,
      remindersSent: 0,
      nextReminderDate: '2025-10-10',
      tags: ['Pediatrics', 'Specialty', 'Optional']
    },
    {
      id: '5',
      type: 'education',
      name: 'Bachelor of Science in Nursing',
      category: 'Nursing Degree',
      issuingOrganization: 'University of California, San Francisco',
      credentialNumber: 'BSN-2019-4567',
      issueDate: '2019-05-15',
      expiryDate: 'N/A',
      status: 'verified',
      verificationLevel: 'premium',
      documentUrl: '/documents/bsn-diploma.pdf',
      isRequired: true,
      autoRenewal: false,
      remindersSent: 0,
      verifiedBy: 'National Student Clearinghouse',
      verifiedDate: '2024-02-01',
      tags: ['Bachelor\'s Degree', 'UCSF', 'Nursing']
    },
    {
      id: '6',
      type: 'insurance',
      name: 'Professional Liability Insurance',
      category: 'Malpractice Insurance',
      issuingOrganization: 'Nurses Service Organization',
      credentialNumber: 'NSO-567890',
      issueDate: '2024-01-01',
      expiryDate: '2024-12-31',
      status: 'expiring_soon',
      verificationLevel: 'basic',
      documentUrl: '/documents/liability-insurance.pdf',
      isRequired: true,
      autoRenewal: true,
      remindersSent: 2,
      nextReminderDate: '2024-11-01',
      renewalInstructions: 'Contact NSO to renew policy before expiration',
      tags: ['Insurance', 'Liability', 'Annual']
    }
  ]);

  const getCredentialsByType = (type: string) => {
    return credentials.filter(cred => type === 'all' || cred.type === type);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified': return 'bg-green-100 text-green-800 border-green-200';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'expired': return 'bg-red-100 text-red-800 border-red-200';
      case 'expiring_soon': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'verified': return <CheckCircle className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'expired': return <AlertTriangle className="w-4 h-4" />;
      case 'expiring_soon': return <AlertTriangle className="w-4 h-4" />;
      case 'rejected': return <AlertTriangle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getVerificationLevel = (level: string) => {
    switch (level) {
      case 'premium': return { color: 'text-purple-600', bg: 'bg-purple-100', border: 'border-purple-200', label: 'Premium Verified' };
      case 'enhanced': return { color: 'text-blue-600', bg: 'bg-blue-100', border: 'border-blue-200', label: 'Enhanced Verified' };
      case 'basic': return { color: 'text-green-600', bg: 'bg-green-100', border: 'border-green-200', label: 'Basic Verified' };
      default: return { color: 'text-gray-600', bg: 'bg-gray-100', border: 'border-gray-200', label: 'Not Verified' };
    }
  };

  const filteredCredentials = credentials.filter(cred => {
    const matchesStatus = statusFilter === 'all' || cred.status === statusFilter;
    const matchesSearch = searchTerm === '' || 
      cred.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cred.issuingOrganization.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cred.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    return matchesStatus && matchesSearch;
  });

  const stats = {
    total: credentials.length,
    verified: credentials.filter(c => c.status === 'verified').length,
    pending: credentials.filter(c => c.status === 'pending').length,
    expiring: credentials.filter(c => c.status === 'expiring_soon').length,
    expired: credentials.filter(c => c.status === 'expired').length,
    completionRate: Math.round((credentials.filter(c => c.status === 'verified').length / credentials.length) * 100)
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent">
            My Credentials
          </h1>
          <p className="text-gray-600 mt-2">
            Manage your professional credentials and certifications with AI-powered verification
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Sync
          </Button>
          <Button 
            onClick={() => setShowUploadModal(true)}
            className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Credential
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
            <div className="text-sm text-gray-600">Total</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{stats.verified}</div>
            <div className="text-sm text-gray-600">Verified</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
            <div className="text-sm text-gray-600">Pending</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{stats.expiring}</div>
            <div className="text-sm text-gray-600">Expiring Soon</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">{stats.expired}</div>
            <div className="text-sm text-gray-600">Expired</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{stats.completionRate}%</div>
            <div className="text-sm text-gray-600">Complete</div>
          </CardContent>
        </Card>
      </div>

      {/* Completion Progress */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Credential Portfolio Completion</h3>
            <Badge className="bg-green-100 text-green-800 border-green-200">
              {stats.completionRate}% Complete
            </Badge>
          </div>
          <Progress value={stats.completionRate} className="h-3 mb-2" />
          <p className="text-sm text-gray-600">
            {stats.verified} of {stats.total} credentials verified. Keep your credentials up-to-date to maintain shift eligibility.
          </p>
        </CardContent>
      </Card>

      {/* AI Insights */}
      <Card className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 border-ai-purple/20">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-5 h-5 text-ai-purple" />
            <h3 className="font-semibold text-ai-purple">AI Credential Insights</h3>
            <Badge className="bg-ai-purple/10 text-ai-purple border-ai-purple/20">
              Smart Monitoring
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-green-600">Portfolio Strength: 94%</div>
              <p className="text-gray-600">Your credentials meet 94% of facility requirements</p>
            </div>
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-orange-600">1 Renewal Due</div>
              <p className="text-gray-600">Professional liability insurance expires in 45 days</p>
            </div>
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-blue-600">Opportunity Detected</div>
              <p className="text-gray-600">Critical Care certification could unlock 23% more shifts</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4 justify-between">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search credentials, organizations, or tags..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
              >
                <option value="all">All Status</option>
                <option value="verified">Verified</option>
                <option value="pending">Pending</option>
                <option value="expiring_soon">Expiring Soon</option>
                <option value="expired">Expired</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Credentials Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCredentials.map((credential) => {
          const verification = getVerificationLevel(credential.verificationLevel);
          const daysUntilExpiry = credential.expiryDate !== 'N/A' 
            ? Math.ceil((new Date(credential.expiryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24))
            : null;

          return (
            <Card key={credential.id} className="hover:shadow-lg transition-shadow group relative overflow-hidden">
              {credential.isRequired && (
                <div className="absolute top-2 right-2">
                  <Badge className="bg-red-100 text-red-800 border-red-200 text-xs">
                    Required
                  </Badge>
                </div>
              )}
              
              <CardContent className="p-6">
                {/* Credential Header */}
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-medical-blue/10 to-ai-purple/10 rounded-lg flex items-center justify-center border">
                    {credential.thumbnailUrl ? (
                      <img 
                        src={credential.thumbnailUrl} 
                        alt={credential.name}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    ) : (
                      <Award className="w-8 h-8 text-medical-blue" />
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 mb-1 group-hover:text-medical-blue transition-colors">
                      {credential.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-2">{credential.category}</p>
                    <Badge className={getStatusColor(credential.status)} size="sm">
                      <div className="flex items-center gap-1">
                        {getStatusIcon(credential.status)}
                        {credential.status.replace('_', ' ').toUpperCase()}
                      </div>
                    </Badge>
                  </div>
                </div>

                {/* Verification Level */}
                <div className={`p-2 rounded-lg ${verification.bg} ${verification.border} border mb-4`}>
                  <div className="flex items-center gap-2">
                    <Shield className={`w-4 h-4 ${verification.color}`} />
                    <span className={`text-sm font-medium ${verification.color}`}>
                      {verification.label}
                    </span>
                  </div>
                </div>

                {/* Credential Details */}
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Issuer:</span>
                    <span className="font-medium text-right">{credential.issuingOrganization}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Number:</span>
                    <span className="font-medium">{credential.credentialNumber}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Issued:</span>
                    <span className="font-medium">{new Date(credential.issueDate).toLocaleDateString()}</span>
                  </div>
                  {credential.expiryDate !== 'N/A' && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Expires:</span>
                      <span className={`font-medium ${
                        daysUntilExpiry && daysUntilExpiry < 90 ? 'text-orange-600' : 
                        daysUntilExpiry && daysUntilExpiry < 30 ? 'text-red-600' : ''
                      }`}>
                        {new Date(credential.expiryDate).toLocaleDateString()}
                        {daysUntilExpiry && daysUntilExpiry > 0 && (
                          <span className="text-xs ml-1">({daysUntilExpiry} days)</span>
                        )}
                      </span>
                    </div>
                  )}
                </div>

                {/* Tags */}
                {credential.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-4">
                    {credential.tags.slice(0, 3).map((tag, index) => (
                      <Badge key={index} className="bg-gray-100 text-gray-700 border-gray-200 text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {credential.tags.length > 3 && (
                      <Badge className="bg-gray-100 text-gray-700 border-gray-200 text-xs">
                        +{credential.tags.length - 3}
                      </Badge>
                    )}
                  </div>
                )}

                {/* Auto Renewal */}
                {credential.autoRenewal && (
                  <div className="flex items-center gap-2 mb-4 p-2 bg-blue-50 rounded-lg">
                    <RefreshCw className="w-4 h-4 text-blue-600" />
                    <span className="text-sm text-blue-700">Auto-renewal enabled</span>
                  </div>
                )}

                {/* Next Reminder */}
                {credential.nextReminderDate && (
                  <div className="flex items-center gap-2 mb-4 p-2 bg-yellow-50 rounded-lg">
                    <Bell className="w-4 h-4 text-yellow-600" />
                    <span className="text-sm text-yellow-700">
                      Next reminder: {new Date(credential.nextReminderDate).toLocaleDateString()}
                    </span>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" className="flex-1">
                    <Eye className="w-4 h-4 mr-1" />
                    View
                  </Button>
                  <Button variant="ghost" size="sm" className="flex-1">
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                  {credential.renewalInstructions && (
                    <Button variant="ghost" size="sm">
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredCredentials.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Award className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No Credentials Found</h3>
            <p className="text-gray-500 mb-4">
              {searchTerm 
                ? 'Try adjusting your search terms or filters.' 
                : 'Start building your credential portfolio by adding your first credential.'
              }
            </p>
            <Button 
              onClick={() => setShowUploadModal(true)}
              className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add First Credential
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Tips Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Tips for Managing Credentials</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Required Documents</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• State nursing license (current and valid)</li>
                <li>• CPR/BLS certification</li>
                <li>• Professional liability insurance</li>
                <li>• TB test or chest x-ray</li>
                <li>• Drug screening results</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Best Practices</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Upload clear, high-quality scans</li>
                <li>• Renew credentials before expiration</li>
                <li>• Keep digital copies in a secure location</li>
                <li>• Set up renewal reminders</li>
                <li>• Review credentials monthly</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
