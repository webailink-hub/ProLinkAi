import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Brain,
  Search,
  Filter,
  Users,
  Star,
  MapPin,
  Clock,
  Calendar,
  Award,
  FileText,
  CheckCircle2,
  X,
  Eye,
  MessageSquare,
  Download,
  ArrowUpRight,
  ArrowDownRight,
  AlertCircle,
  Shield,
  TrendingUp,
  User,
  Phone,
  Mail,
  ExternalLink,
  ChevronDown,
  SortAsc,
  MoreHorizontal,
} from "lucide-react";

interface Applicant {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  experience: string;
  specialties: string[];
  certifications: string[];
  location: string;
  distance: string;
  hourlyRate: number;
  appliedDate: string;
  shiftTitle: string;
  shiftDate: string;
  shiftTime: string;
  status: "pending" | "interviewed" | "accepted" | "rejected";
  compatibilityScore: number;
  backgroundCheck: "verified" | "pending" | "expired";
  availability: string;
  lastShift: string;
  phoneNumber: string;
  email: string;
  notes?: string;
}

export default function Applicants() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("compatibility");
  const [selectedApplicant, setSelectedApplicant] = useState<Applicant | null>(null);

  // Mock data - in real app this would come from API
  const applicants: Applicant[] = [
    {
      id: "1",
      name: "Sarah Johnson",
      avatar: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=64&h=64&fit=crop&crop=face",
      rating: 4.9,
      experience: "8 years",
      specialties: ["ICU", "Critical Care", "Ventilator Management"],
      certifications: ["RN", "BLS", "ACLS", "CCRN"],
      location: "San Francisco, CA",
      distance: "2.3 miles",
      hourlyRate: 58,
      appliedDate: "2 hours ago",
      shiftTitle: "ICU Night Nurse",
      shiftDate: "Jan 15, 2024",
      shiftTime: "7:00 PM - 7:00 AM",
      status: "pending",
      compatibilityScore: 96,
      backgroundCheck: "verified",
      availability: "Available immediately",
      lastShift: "2 days ago",
      phoneNumber: "(555) 123-4567",
      email: "sarah.johnson@email.com",
      notes: "Highly experienced ICU nurse with excellent reviews."
    },
    {
      id: "2",
      name: "Michael Chen",
      avatar: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=64&h=64&fit=crop&crop=face",
      rating: 4.7,
      experience: "5 years",
      specialties: ["Emergency", "Trauma", "Fast-paced Environment"],
      certifications: ["RN", "BLS", "ACLS", "TNCC"],
      location: "Oakland, CA",
      distance: "8.1 miles",
      hourlyRate: 52,
      appliedDate: "4 hours ago",
      shiftTitle: "ER Day Shift",
      shiftDate: "Jan 16, 2024",
      shiftTime: "7:00 AM - 7:00 PM",
      status: "interviewed",
      compatibilityScore: 89,
      backgroundCheck: "verified",
      availability: "Flexible schedule",
      lastShift: "1 week ago",
      phoneNumber: "(555) 234-5678",
      email: "michael.chen@email.com",
    },
    {
      id: "3",
      name: "Lisa Rodriguez",
      avatar: "https://images.unsplash.com/photo-1594824475314-6234dd2a0cf4?w=64&h=64&fit=crop&crop=face",
      rating: 4.8,
      experience: "6 years",
      specialties: ["Medical-Surgical", "Patient Education", "Wound Care"],
      certifications: ["RN", "BLS", "CWCN"],
      location: "Berkeley, CA",
      distance: "12.5 miles",
      hourlyRate: 48,
      appliedDate: "1 day ago",
      shiftTitle: "Med-Surg Evening",
      shiftDate: "Jan 17, 2024",
      shiftTime: "3:00 PM - 11:00 PM",
      status: "pending",
      compatibilityScore: 84,
      backgroundCheck: "pending",
      availability: "Weekends preferred",
      lastShift: "3 days ago",
      phoneNumber: "(555) 345-6789",
      email: "lisa.rodriguez@email.com",
    },
    {
      id: "4",
      name: "David Wilson",
      avatar: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=64&h=64&fit=crop&crop=face",
      rating: 4.6,
      experience: "12 years",
      specialties: ["Operating Room", "Surgical Procedures", "Anesthesia"],
      certifications: ["RN", "BLS", "ACLS", "CNOR"],
      location: "San Jose, CA",
      distance: "25.3 miles",
      hourlyRate: 65,
      appliedDate: "2 days ago",
      shiftTitle: "OR Circulating Nurse",
      shiftDate: "Jan 18, 2024",
      shiftTime: "6:00 AM - 4:00 PM",
      status: "accepted",
      compatibilityScore: 92,
      backgroundCheck: "verified",
      availability: "Day shifts only",
      lastShift: "1 day ago",
      phoneNumber: "(555) 456-7890",
      email: "david.wilson@email.com",
    },
    {
      id: "5",
      name: "Amanda Taylor",
      avatar: "https://images.unsplash.com/photo-1527716950837-8c97e4e17b0b?w=64&h=64&fit=crop&crop=face",
      rating: 4.4,
      experience: "3 years",
      specialties: ["Pediatrics", "NICU", "Family Care"],
      certifications: ["RN", "BLS", "PALS", "NRP"],
      location: "Fremont, CA",
      distance: "18.7 miles",
      hourlyRate: 45,
      appliedDate: "3 days ago",
      shiftTitle: "NICU Night Nurse",
      shiftDate: "Jan 19, 2024",
      shiftTime: "11:00 PM - 7:00 AM",
      status: "rejected",
      compatibilityScore: 76,
      backgroundCheck: "verified",
      availability: "Night shifts preferred",
      lastShift: "1 week ago",
      phoneNumber: "(555) 567-8901",
      email: "amanda.taylor@email.com",
    },
  ];

  const filteredApplicants = applicants
    .filter(applicant => {
      const matchesSearch = applicant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           applicant.specialties.some(specialty => specialty.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesStatus = statusFilter === "all" || applicant.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "compatibility":
          return b.compatibilityScore - a.compatibilityScore;
        case "rating":
          return b.rating - a.rating;
        case "date":
          return new Date(b.appliedDate).getTime() - new Date(a.appliedDate).getTime();
        case "rate":
          return b.hourlyRate - a.hourlyRate;
        default:
          return 0;
      }
    });

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { bg: "bg-yellow-100", text: "text-yellow-800", label: "Pending Review" },
      interviewed: { bg: "bg-blue-100", text: "text-blue-800", label: "Interviewed" },
      accepted: { bg: "bg-green-100", text: "text-green-800", label: "Accepted" },
      rejected: { bg: "bg-red-100", text: "text-red-800", label: "Rejected" },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig];
    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        {config.label}
      </span>
    );
  };

  const getCompatibilityColor = (score: number) => {
    if (score >= 90) return "text-green-600 bg-green-100";
    if (score >= 80) return "text-blue-600 bg-blue-100";
    if (score >= 70) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  const handleStatusChange = (applicantId: string, newStatus: string) => {
    // In real app, this would call an API
    console.log(`Changing status of ${applicantId} to ${newStatus}`);
  };

  const statusCounts = {
    all: applicants.length,
    pending: applicants.filter(a => a.status === "pending").length,
    interviewed: applicants.filter(a => a.status === "interviewed").length,
    accepted: applicants.filter(a => a.status === "accepted").length,
    rejected: applicants.filter(a => a.status === "rejected").length,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center space-x-4 mb-4 lg:mb-0">
              <div className="w-12 h-12 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-header font-bold text-gray-900">
                  Review Applicants
                </h1>
                <p className="text-gray-600 font-body">
                  AI-powered screening with intelligent ranking and compatibility scores
                </p>
              </div>
            </div>

            <Link
              to="/dashboard"
              className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors font-medium"
            >
              Back to Dashboard
            </Link>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
            {Object.entries(statusCounts).map(([status, count]) => (
              <div
                key={status}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                  statusFilter === status
                    ? "border-medical-blue bg-medical-blue/5"
                    : "border-gray-200 hover:border-gray-300"
                }`}
                onClick={() => setStatusFilter(status)}
              >
                <div className="text-2xl font-bold text-gray-900">{count}</div>
                <div className="text-sm text-gray-600 capitalize">
                  {status === "all" ? "Total" : status.replace("_", " ")}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters and Search */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex flex-col sm:flex-row gap-4 flex-1">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search by name or specialty..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent"
                />
              </div>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent"
              >
                <option value="compatibility">Sort by Compatibility</option>
                <option value="rating">Sort by Rating</option>
                <option value="date">Sort by Applied Date</option>
                <option value="rate">Sort by Hourly Rate</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                <Filter className="w-4 h-4" />
                More Filters
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-medical-blue text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Download className="w-4 h-4" />
                Export
              </button>
            </div>
          </div>
        </div>

        {/* Applicant List */}
        <div className="grid gap-6">
          {filteredApplicants.map((applicant) => (
            <div
              key={applicant.id}
              className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
            >
              <div className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                  <div className="flex items-start space-x-4 mb-4 lg:mb-0">
                    <img
                      src={applicant.avatar}
                      alt={applicant.name}
                      className="w-16 h-16 rounded-xl object-cover"
                    />
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">
                          {applicant.name}
                        </h3>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-500 mr-1" />
                          <span className="text-sm font-medium">{applicant.rating}</span>
                        </div>
                        {applicant.backgroundCheck === "verified" && (
                          <Shield className="w-4 h-4 text-green-600" />
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-sm text-gray-600 mb-3">
                        <div className="flex items-center">
                          <Award className="w-4 h-4 mr-2" />
                          {applicant.experience} experience
                        </div>
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-2" />
                          {applicant.distance} away
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-2" />
                          Applied {applicant.appliedDate}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2" />
                          {applicant.availability}
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2 mb-3">
                        {applicant.specialties.slice(0, 3).map((specialty, index) => (
                          <span
                            key={index}
                            className="bg-medical-blue/10 text-medical-blue px-2 py-1 rounded-full text-xs font-medium"
                          >
                            {specialty}
                          </span>
                        ))}
                        {applicant.specialties.length > 3 && (
                          <span className="text-xs text-gray-500">
                            +{applicant.specialties.length - 3} more
                          </span>
                        )}
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className={`px-3 py-1 rounded-full text-sm font-medium ${getCompatibilityColor(applicant.compatibilityScore)}`}>
                          {applicant.compatibilityScore}% match
                        </div>
                        {getStatusBadge(applicant.status)}
                        <span className="text-sm font-medium text-gray-900">
                          ${applicant.hourlyRate}/hr
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col space-y-2 lg:items-end">
                    <div className="flex items-center space-x-2">
                      {applicant.status === "pending" && (
                        <>
                          <button
                            onClick={() => handleStatusChange(applicant.id, "accepted")}
                            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
                          >
                            Accept
                          </button>
                          <button
                            onClick={() => handleStatusChange(applicant.id, "interviewed")}
                            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                          >
                            Interview
                          </button>
                          <button
                            onClick={() => handleStatusChange(applicant.id, "rejected")}
                            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors text-sm font-medium"
                          >
                            Reject
                          </button>
                        </>
                      )}
                      
                      <button
                        onClick={() => setSelectedApplicant(applicant)}
                        className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium flex items-center"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View Profile
                      </button>
                      
                      <button className="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center">
                        <MessageSquare className="w-4 h-4 mr-1" />
                        Message
                      </button>
                    </div>

                    <div className="text-xs text-gray-500">
                      Applied for: {applicant.shiftTitle}
                    </div>
                    <div className="text-xs text-gray-500">
                      {applicant.shiftDate} • {applicant.shiftTime}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredApplicants.length === 0 && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No applicants found</h3>
            <p className="text-gray-600">
              Try adjusting your search criteria or filters to see more results.
            </p>
          </div>
        )}
      </div>

      {/* Applicant Detail Modal */}
      {selectedApplicant && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-header font-bold text-gray-900">
                {selectedApplicant.name}
              </h2>
              <button
                onClick={() => setSelectedApplicant(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <Mail className="w-5 h-5 text-gray-400 mr-3" />
                      <span>{selectedApplicant.email}</span>
                    </div>
                    <div className="flex items-center">
                      <Phone className="w-5 h-5 text-gray-400 mr-3" />
                      <span>{selectedApplicant.phoneNumber}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="w-5 h-5 text-gray-400 mr-3" />
                      <span>{selectedApplicant.location}</span>
                    </div>
                  </div>

                  <h3 className="text-lg font-semibold text-gray-900 mt-8 mb-4">Certifications</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedApplicant.certifications.map((cert, index) => (
                      <span
                        key={index}
                        className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium"
                      >
                        {cert}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Application Details</h3>
                  <div className="space-y-3">
                    <div>
                      <span className="text-gray-600">Applied for:</span>
                      <div className="font-medium">{selectedApplicant.shiftTitle}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Shift Date & Time:</span>
                      <div className="font-medium">{selectedApplicant.shiftDate} • {selectedApplicant.shiftTime}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Hourly Rate:</span>
                      <div className="font-medium">${selectedApplicant.hourlyRate}/hr</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Compatibility Score:</span>
                      <div className={`font-medium ${getCompatibilityColor(selectedApplicant.compatibilityScore).replace('bg-', 'text-').replace('-100', '-600')}`}>
                        {selectedApplicant.compatibilityScore}% match
                      </div>
                    </div>
                  </div>

                  <h3 className="text-lg font-semibold text-gray-900 mt-8 mb-4">Specialties</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedApplicant.specialties.map((specialty, index) => (
                      <span
                        key={index}
                        className="bg-medical-blue/10 text-medical-blue px-3 py-1 rounded-full text-sm font-medium"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {selectedApplicant.notes && (
                <div className="mt-8">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Notes</h3>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-gray-700">{selectedApplicant.notes}</p>
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200">
                <button
                  onClick={() => setSelectedApplicant(null)}
                  className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Close
                </button>
                <button className="px-6 py-2 bg-medical-blue text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Send Message
                </button>
                {selectedApplicant.status === "pending" && (
                  <button
                    onClick={() => {
                      handleStatusChange(selectedApplicant.id, "accepted");
                      setSelectedApplicant(null);
                    }}
                    className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    Accept Applicant
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
