import { useState } from "react";
import {
  BarChart3,
  TrendingUp,
  Users,
  Clock,
  DollarSign,
  Calendar,
  Filter,
  Download,
} from "lucide-react";

// Mock analytics data
const analyticsData = {
  overview: {
    totalShifts: 1247,
    shiftsThisMonth: 89,
    averageFillTime: "2.3 hours",
    fillRate: 94.2,
    averageRating: 4.7,
    totalNurses: 156,
  },
  monthlyData: [
    { month: "Jan", shifts: 98, fillRate: 92, avgTime: 2.8 },
    { month: "Feb", shifts: 112, fillRate: 95, avgTime: 2.1 },
    { month: "Mar", shifts: 105, fillRate: 89, avgTime: 3.2 },
    { month: "Apr", shifts: 134, fillRate: 97, avgTime: 1.9 },
    { month: "May", shifts: 89, fillRate: 94, avgTime: 2.3 },
    { month: "Jun", shifts: 76, fillRate: 91, avgTime: 2.7 },
  ],
  departmentData: [
    { name: "ICU", shifts: 234, fillRate: 98, avgPay: 65 },
    { name: "Emergency", shifts: 189, fillRate: 95, avgPay: 62 },
    { name: "Med-Surg", shifts: 156, fillRate: 92, avgPay: 55 },
    { name: "OR", shifts: 123, fillRate: 89, avgPay: 70 },
    { name: "Pediatrics", shifts: 98, fillRate: 96, avgPay: 58 },
  ],
  topNurses: [
    { name: "Sarah Johnson", shifts: 23, rating: 4.9, dept: "ICU" },
    { name: "Michael Chen", shifts: 21, rating: 4.8, dept: "Emergency" },
    { name: "Emily Davis", shifts: 19, rating: 4.9, dept: "Med-Surg" },
    { name: "David Wilson", shifts: 18, rating: 4.7, dept: "ICU" },
    { name: "Lisa Garcia", shifts: 17, rating: 4.8, dept: "OR" },
  ],
};

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("6months");

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Analytics Dashboard
            </h1>
            <p className="text-gray-600 mt-1">
              Insights into your facility's staffing performance
            </p>
          </div>

          <div className="flex gap-3 mt-4 sm:mt-0">
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent"
            >
              <option value="1month">Last Month</option>
              <option value="3months">Last 3 Months</option>
              <option value="6months">Last 6 Months</option>
              <option value="1year">Last Year</option>
            </select>

            <button className="flex items-center px-4 py-2 bg-medical-blue text-white rounded-lg hover:bg-blue-700 transition-colors">
              <Download className="w-4 h-4 mr-2" />
              Export
            </button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Shifts Posted</p>
                <p className="text-3xl font-bold text-gray-900">
                  {analyticsData.overview.totalShifts}
                </p>
                <p className="text-sm text-green-600">
                  +{analyticsData.overview.shiftsThisMonth} this month
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-medical-blue" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Fill Rate</p>
                <p className="text-3xl font-bold text-gray-900">
                  {analyticsData.overview.fillRate}%
                </p>
                <p className="text-sm text-green-600">+2.1% from last month</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Fill Time</p>
                <p className="text-3xl font-bold text-gray-900">
                  {analyticsData.overview.averageFillTime}
                </p>
                <p className="text-sm text-green-600">
                  -0.5 hrs from last month
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Nurses</p>
                <p className="text-3xl font-bold text-gray-900">
                  {analyticsData.overview.totalNurses}
                </p>
                <p className="text-sm text-blue-600">+12 new this month</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Average Rating</p>
                <p className="text-3xl font-bold text-gray-900">
                  {analyticsData.overview.averageRating}
                </p>
                <p className="text-sm text-yellow-600">★★★★★</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Monthly Trends */}
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Monthly Trends
            </h3>
            <div className="space-y-4">
              {analyticsData.monthlyData.map((month, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700 w-12">
                    {month.month}
                  </span>
                  <div className="flex-1 mx-4">
                    <div className="flex items-center justify-between text-xs text-gray-600 mb-1">
                      <span>Shifts: {month.shifts}</span>
                      <span>Fill: {month.fillRate}%</span>
                      <span>Time: {month.avgTime}h</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-medical-blue h-2 rounded-full"
                        style={{ width: `${month.fillRate}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Department Performance */}
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Department Performance
            </h3>
            <div className="space-y-4">
              {analyticsData.departmentData.map((dept, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                >
                  <div>
                    <h4 className="font-medium text-gray-900">{dept.name}</h4>
                    <p className="text-sm text-gray-600">
                      {dept.shifts} shifts
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">
                      {dept.fillRate}% filled
                    </p>
                    <p className="text-sm text-gray-600">
                      ${dept.avgPay}/hr avg
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top Performers */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Top Performing Nurses
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-medium text-gray-700">
                    Nurse
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">
                    Department
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">
                    Shifts
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">
                    Rating
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {analyticsData.topNurses.map((nurse, index) => (
                  <tr key={index} className="border-b border-gray-100">
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-gradient-to-br from-medical-blue to-ai-purple rounded-full flex items-center justify-center text-white text-sm font-bold mr-3">
                          {nurse.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </div>
                        {nurse.name}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{nurse.dept}</td>
                    <td className="py-3 px-4">{nurse.shifts}</td>
                    <td className="py-3 px-4">
                      <span className="flex items-center">
                        {nurse.rating} ⭐
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <button className="text-medical-blue hover:text-blue-700 text-sm font-medium">
                        View Profile
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
