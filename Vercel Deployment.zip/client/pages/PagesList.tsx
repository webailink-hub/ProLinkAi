import React, { useState } from 'react';
import { ExternalLink, Search, Filter, Home, Settings, Users, Calendar, Clock, FileText, CreditCard, Building2, Shield, BarChart3, UserCheck } from 'lucide-react';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/card';

interface RouteInfo {
  path: string;
  name: string;
  description: string;
  category: 'public' | 'auth' | 'dashboard' | 'admin' | 'dynamic';
  access: 'all' | 'nurse' | 'facility' | 'admin';
  status: 'live' | 'new' | 'updated';
  icon: React.ReactNode;
}

const routes: RouteInfo[] = [
  // Public Routes
  {
    path: '/',
    name: 'Landing Page',
    description: 'Main homepage with hero section and key features',
    category: 'public',
    access: 'all',
    status: 'live',
    icon: <Home className="w-4 h-4" />
  },
  {
    path: '/about',
    name: 'About Us',
    description: 'Company information and team details',
    category: 'public',
    access: 'all',
    status: 'live',
    icon: <Building2 className="w-4 h-4" />
  },

  // Authentication Routes
  {
    path: '/login',
    name: 'Login Page',
    description: 'User authentication and sign-in',
    category: 'auth',
    access: 'all',
    status: 'live',
    icon: <Shield className="w-4 h-4" />
  },
  {
    path: '/register',
    name: 'Registration Hub',
    description: 'Choose registration type (nurse or facility)',
    category: 'auth',
    access: 'all',
    status: 'live',
    icon: <UserCheck className="w-4 h-4" />
  },
  {
    path: '/register/nurse',
    name: 'Nurse Registration',
    description: 'Complete nurse profile setup and verification',
    category: 'auth',
    access: 'all',
    status: 'live',
    icon: <Users className="w-4 h-4" />
  },
  {
    path: '/register/facility',
    name: 'Facility Registration',
    description: 'Healthcare facility onboarding and setup',
    category: 'auth',
    access: 'all',
    status: 'live',
    icon: <Building2 className="w-4 h-4" />
  },
  {
    path: '/forgot-password',
    name: 'Forgot Password',
    description: 'Password reset and recovery',
    category: 'auth',
    access: 'all',
    status: 'live',
    icon: <Shield className="w-4 h-4" />
  },

  // Dashboard Routes
  {
    path: '/dashboard',
    name: 'Dashboard Home',
    description: 'Role-dependent dashboard with key metrics and actions',
    category: 'dashboard',
    access: 'all',
    status: 'live',
    icon: <BarChart3 className="w-4 h-4" />
  },
  {
    path: '/dashboard/profile',
    name: 'My Profile',
    description: 'User profile management and settings',
    category: 'dashboard',
    access: 'all',
    status: 'live',
    icon: <Users className="w-4 h-4" />
  },
  {
    path: '/dashboard/settings',
    name: 'Settings',
    description: 'Account preferences and configuration',
    category: 'dashboard',
    access: 'all',
    status: 'live',
    icon: <Settings className="w-4 h-4" />
  },
  {
    path: '/dashboard/messages',
    name: 'Messages',
    description: 'Internal messaging and communication',
    category: 'dashboard',
    access: 'all',
    status: 'live',
    icon: <FileText className="w-4 h-4" />
  },
  {
    path: '/dashboard/notifications',
    name: 'Notifications',
    description: 'System alerts and updates',
    category: 'dashboard',
    access: 'all',
    status: 'live',
    icon: <Settings className="w-4 h-4" />
  },
  {
    path: '/dashboard/help',
    name: 'Help Center',
    description: 'Support documentation and contact',
    category: 'dashboard',
    access: 'all',
    status: 'live',
    icon: <Shield className="w-4 h-4" />
  },
  {
    path: '/dashboard/referrals',
    name: 'Referrals',
    description: 'Referral program and tracking',
    category: 'dashboard',
    access: 'all',
    status: 'live',
    icon: <Users className="w-4 h-4" />
  },

  // Nurse-Specific Routes
  {
    path: '/dashboard/shifts',
    name: 'Find & Manage Shifts',
    description: 'AI-powered shift discovery with intelligent filtering and matching',
    category: 'dashboard',
    access: 'nurse',
    status: 'new',
    icon: <Calendar className="w-4 h-4" />
  },
  {
    path: '/dashboard/timesheets',
    name: 'Timesheets',
    description: 'Smart time tracking with photo verification and AI anomaly detection',
    category: 'dashboard',
    access: 'nurse',
    status: 'new',
    icon: <Clock className="w-4 h-4" />
  },
  {
    path: '/dashboard/my-credentials',
    name: 'My Credentials',
    description: 'AI-assisted credential management with automatic renewal reminders',
    category: 'dashboard',
    access: 'nurse',
    status: 'new',
    icon: <FileText className="w-4 h-4" />
  },
  {
    path: '/dashboard/payouts',
    name: 'Payouts',
    description: 'Earnings tracking and payment management',
    category: 'dashboard',
    access: 'nurse',
    status: 'live',
    icon: <CreditCard className="w-4 h-4" />
  },

  // Facility-Specific Routes
  {
    path: '/dashboard/post-shift',
    name: 'Post a Shift',
    description: 'Create and manage shift postings',
    category: 'dashboard',
    access: 'facility',
    status: 'live',
    icon: <Calendar className="w-4 h-4" />
  },
  {
    path: '/dashboard/applicants',
    name: 'Review Applicants',
    description: 'AI-powered applicant screening and management',
    category: 'dashboard',
    access: 'facility',
    status: 'updated',
    icon: <UserCheck className="w-4 h-4" />
  },
  {
    path: '/dashboard/shift-management',
    name: 'Shift Management',
    description: 'Advanced shift scheduling and management tools',
    category: 'dashboard',
    access: 'facility',
    status: 'live',
    icon: <Calendar className="w-4 h-4" />
  },

  // Admin Routes
  {
    path: '/dashboard/admin',
    name: 'Admin Dashboard',
    description: 'System administration and oversight',
    category: 'admin',
    access: 'admin',
    status: 'live',
    icon: <Shield className="w-4 h-4" />
  },
  {
    path: '/dashboard/admin/users',
    name: 'User Management',
    description: 'User accounts and permissions administration',
    category: 'admin',
    access: 'admin',
    status: 'live',
    icon: <Users className="w-4 h-4" />
  },
  {
    path: '/dashboard/admin/audit-trail',
    name: 'Audit Trail',
    description: 'System activity logs and compliance tracking',
    category: 'admin',
    access: 'admin',
    status: 'live',
    icon: <FileText className="w-4 h-4" />
  },

  // Dynamic Routes
  {
    path: '/dashboard/user/[id]',
    name: 'Nurse Profile View',
    description: 'Detailed nurse profile (Example: /dashboard/user/user-1)',
    category: 'dynamic',
    access: 'facility',
    status: 'live',
    icon: <Users className="w-4 h-4" />
  },
  {
    path: '/dashboard/facility/[id]',
    name: 'Facility Profile View',
    description: 'Detailed facility profile (Example: /dashboard/facility/user-2)',
    category: 'dynamic',
    access: 'nurse',
    status: 'live',
    icon: <Building2 className="w-4 h-4" />
  },

  // New Pages
  {
    path: '/dashboard/shift/[id]',
    name: 'Shift Details',
    description: 'Comprehensive shift details with AI matching and application features',
    category: 'dynamic',
    access: 'nurse',
    status: 'new',
    icon: <Calendar className="w-4 h-4" />
  },
  {
    path: '/dashboard/shift-calendar',
    name: 'Shift Calendar',
    description: 'Visual calendar view of available shifts with AI recommendations',
    category: 'dashboard',
    access: 'nurse',
    status: 'new',
    icon: <Calendar className="w-4 h-4" />
  },
  {
    path: '/dashboard/timesheet-approval',
    name: 'Timesheet Approval',
    description: 'Review and approve submitted timesheets with AI anomaly detection',
    category: 'dashboard',
    access: 'facility',
    status: 'new',
    icon: <Clock className="w-4 h-4" />
  }
];

export default function PagesList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedAccess, setSelectedAccess] = useState<string>('all');

  const filteredRoutes = routes.filter(route => {
    const matchesSearch = route.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         route.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         route.path.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || route.category === selectedCategory;
    const matchesAccess = selectedAccess === 'all' || route.access === selectedAccess;
    
    return matchesSearch && matchesCategory && matchesAccess;
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'public': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'auth': return 'bg-green-100 text-green-800 border-green-200';
      case 'dashboard': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'admin': return 'bg-red-100 text-red-800 border-red-200';
      case 'dynamic': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getAccessColor = (access: string) => {
    switch (access) {
      case 'all': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'nurse': return 'bg-medical-blue/10 text-medical-blue border-medical-blue/20';
      case 'facility': return 'bg-medical-teal/10 text-medical-teal border-medical-teal/20';
      case 'admin': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-green-100 text-green-800 border-green-200';
      case 'new': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'updated': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const categoryStats = routes.reduce((acc, route) => {
    acc[route.category] = (acc[route.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="min-h-screen bg-gradient-to-br from-medical-blue/5 via-ai-purple/5 to-medical-teal/5">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent mb-4">
            ProLinkAi Routes Directory
          </h1>
          <p className="text-gray-600 text-lg max-w-3xl mx-auto">
            Interactive directory of all application routes with filtering and detailed descriptions. 
            Perfect for developers, designers, and stakeholders to understand the platform structure.
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-medical-blue">{routes.length}</div>
              <div className="text-sm text-gray-600">Total Routes</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{categoryStats.public || 0}</div>
              <div className="text-sm text-gray-600">Public</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{categoryStats.dashboard || 0}</div>
              <div className="text-sm text-gray-600">Dashboard</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-red-600">{categoryStats.admin || 0}</div>
              <div className="text-sm text-gray-600">Admin</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-yellow-600">{categoryStats.dynamic || 0}</div>
              <div className="text-sm text-gray-600">Dynamic</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filters & Search
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Search Routes</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    type="text"
                    placeholder="Search by name, description, or path..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
                >
                  <option value="all">All Categories</option>
                  <option value="public">Public</option>
                  <option value="auth">Authentication</option>
                  <option value="dashboard">Dashboard</option>
                  <option value="admin">Admin</option>
                  <option value="dynamic">Dynamic</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Access Level</label>
                <select
                  value={selectedAccess}
                  onChange={(e) => setSelectedAccess(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
                >
                  <option value="all">All Access Levels</option>
                  <option value="all">Public Access</option>
                  <option value="nurse">Nurse Only</option>
                  <option value="facility">Facility Only</option>
                  <option value="admin">Admin Only</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Routes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRoutes.map((route, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow group">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-gradient-to-br from-medical-blue/10 to-ai-purple/10 rounded-lg">
                      {route.icon}
                    </div>
                    <div>
                      <CardTitle className="text-lg group-hover:text-medical-blue transition-colors">
                        {route.name}
                      </CardTitle>
                      <p className="text-sm font-mono text-gray-500 mt-1">{route.path}</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => window.open(route.path.replace('[id]', 'example-id'), '_blank')}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {route.description}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  <Badge className={getCategoryColor(route.category)}>
                    {route.category}
                  </Badge>
                  <Badge className={getAccessColor(route.access)}>
                    {route.access}
                  </Badge>
                  <Badge className={getStatusColor(route.status)}>
                    {route.status}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* No Results */}
        {filteredRoutes.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <div className="text-gray-400 mb-4">
                <Search className="w-12 h-12 mx-auto" />
              </div>
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No Routes Found</h3>
              <p className="text-gray-500">
                Try adjusting your search criteria or filters to find what you're looking for.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Footer */}
        <div className="mt-12 text-center text-gray-500 text-sm">
          <p>
            This interactive directory helps designers and developers navigate the ProLinkAi platform structure.
            <br />
            For technical support or route issues, contact the development team.
          </p>
        </div>
      </div>
    </div>
  );
}
