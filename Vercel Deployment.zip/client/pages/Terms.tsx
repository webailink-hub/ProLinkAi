export default function Terms() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">
            Terms of Service
          </h1>

          <div className="space-y-6 text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                1. Acceptance of Terms
              </h2>
              <p>
                By accessing and using ProLinkAi's healthcare staffing platform,
                you accept and agree to be bound by the terms and provision of
                this agreement.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                2. Use License
              </h2>
              <p>
                Permission is granted to temporarily download one copy of
                ProLinkAi's materials for personal, non-commercial transitory
                viewing only.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                3. User Responsibilities
              </h2>
              <ul className="list-disc list-inside space-y-2">
                <li>Provide accurate and up-to-date information</li>
                <li>
                  Maintain the confidentiality of your account credentials
                </li>
                <li>Comply with all applicable laws and regulations</li>
                <li>Respect other users and maintain professional conduct</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                4. Healthcare Compliance
              </h2>
              <p>
                All users must comply with HIPAA regulations and maintain
                patient confidentiality at all times when using our platform.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                5. Platform Usage
              </h2>
              <p>
                ProLinkAi serves as a connection platform between healthcare
                professionals and facilities. We do not employ nurses or operate
                healthcare facilities.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                6. Contact Information
              </h2>
              <p>
                For questions about these Terms of Service, please contact us at
                legal@prolinkaid.com
              </p>
            </section>
          </div>

          <div className="mt-8 text-sm text-gray-500">
            Last updated: January 2024
          </div>
        </div>
      </div>
    </div>
  );
}
