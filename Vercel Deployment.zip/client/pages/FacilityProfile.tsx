import { useState } from "react";
import { Link } from "react-router-dom";
import {
  MapPin,
  Mail,
  Phone,
  Globe,
  Calendar,
  Star,
  User,
  Edit3,
  MessageSquare,
  Camera,
  ExternalLink,
  Users,
  TrendingUp,
  Plus,
  Building2,
} from "lucide-react";
import { useAuth } from "../contexts/AuthContext";

// Mock data for facility profile
const mockFacilityProfile = {
  avatarUrl:
    "https://images.unsplash.com/photo-1632833239869-a37e3a5806d2?w=150&h=150&fit=crop",
  city: "Downtown",
  state: "Medville, CA",
  rating: 4.8,
  legalName: "Medville Health Systems, Inc.",
  fullAddress: "123 Health St, Downtown, Medville, CA 90210",
  phoneNumber: "555-987-6543",
  website: "https://memorialhospital.com",
  contactPerson: "John Smith",
  healthSystem: "Medville Health",
  memberSince: "January 15, 2023",
  facilityType: "Acute Care Hospital",
  bedCount: 450,
  totalShifts: 892,
  fillRate: 94,
  avgResponseTime: "2.3 hours",
  openShifts: [
    {
      position: "ICU Nurse",
      department: "ICU",
      date: "Jan 15, 2024",
      time: "7:00 AM - 7:00 PM",
      pay: 55,
      urgent: true,
    },
    {
      position: "ER Nurse",
      department: "Emergency",
      date: "Jan 16, 2024",
      time: "3:00 PM - 11:00 PM",
      pay: 52,
      urgent: false,
    },
    {
      position: "Med-Surg Nurse",
      department: "Medical-Surgical",
      date: "Jan 17, 2024",
      time: "11:00 PM - 7:00 AM",
      pay: 48,
      urgent: false,
    },
  ],
  reviews: [
    {
      nurseName: "Sarah Johnson",
      rating: 5,
      comment:
        "Great facility to work at. Staff is supportive and management is professional.",
      date: "Jan 12, 2024",
    },
    {
      nurseName: "Michael Chen",
      rating: 4,
      comment:
        "Well-organized facility with good resources. Positive work environment.",
      date: "Jan 10, 2024",
    },
  ],
};

export default function FacilityProfile() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");

  if (!user || user.role !== "facility") {
    return <div>Access denied. This page is for facilities only.</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Profile Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center space-x-6">
              {/* Avatar */}
              <div className="relative">
                <img
                  className="w-24 h-24 rounded-2xl object-cover border-4 border-white shadow-lg"
                  src={mockFacilityProfile.avatarUrl}
                  alt={user.name}
                />
                <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-medical-blue text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors">
                  <Camera className="w-4 h-4" />
                </button>
              </div>

              {/* Basic Info */}
              <div>
                <div className="flex items-center space-x-3 mb-2">
                  <h1 className="text-3xl font-header font-bold text-gray-900">
                    {user.name}
                  </h1>
                  <div className="flex items-center bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                    <Building2 className="w-4 h-4 mr-1" />
                    Verified Facility
                  </div>
                </div>

                <p className="text-lg text-gray-600 mb-2">
                  {mockFacilityProfile.facilityType}
                </p>

                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-1" />
                    {mockFacilityProfile.city}, {mockFacilityProfile.state}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    Member since {mockFacilityProfile.memberSince}
                  </div>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 mr-1 text-yellow-500" />
                    {mockFacilityProfile.rating} rating
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-6 lg:mt-0 flex flex-col sm:flex-row gap-3">
              <Link
                to="/dashboard/messages"
                className="bg-medical-blue text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Messages
              </Link>
              <button className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center">
                <Edit3 className="w-4 h-4 mr-2" />
                Edit Profile
              </button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-gray-900">
                {mockFacilityProfile.totalShifts}
              </div>
              <div className="text-sm text-gray-600">Total Shifts</div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {mockFacilityProfile.rating}
              </div>
              <div className="text-sm text-gray-600">Average Rating</div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">
                {mockFacilityProfile.fillRate}%
              </div>
              <div className="text-sm text-gray-600">Fill Rate</div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">
                {mockFacilityProfile.avgResponseTime}
              </div>
              <div className="text-sm text-gray-600">Avg Response</div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tab Navigation */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="-mb-px flex space-x-8">
            {["overview", "contact", "shifts", "reviews"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab
                    ? "border-medical-blue text-medical-blue"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {activeTab === "overview" && (
              <div className="space-y-6">
                {/* Facility Details */}
                <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Facility Details
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Legal Name:</span>
                      <span className="font-medium">
                        {mockFacilityProfile.legalName}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Facility Type:</span>
                      <span className="font-medium">
                        {mockFacilityProfile.facilityType}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Bed Count:</span>
                      <span className="font-medium">
                        {mockFacilityProfile.bedCount} beds
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Health System:</span>
                      <span className="font-medium">
                        {mockFacilityProfile.healthSystem}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Open Shifts */}
                <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      Open Shifts
                    </h3>
                    <Link
                      to="/dashboard/post-shift"
                      className="text-medical-blue hover:text-blue-700 text-sm font-medium"
                    >
                      Post New Shift
                    </Link>
                  </div>
                  <div className="space-y-4">
                    {mockFacilityProfile.openShifts.map((shift, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                      >
                        <div>
                          <div className="flex items-center space-x-2">
                            <h4 className="font-medium text-gray-900">
                              {shift.position}
                            </h4>
                            {shift.urgent && (
                              <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">
                                Urgent
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600">
                            {shift.department} • {shift.date}
                          </p>
                          <p className="text-sm text-gray-600">{shift.time}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">
                            ${shift.pay}/hr
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === "contact" && (
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">
                  Contact Information
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <Mail className="w-5 h-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-medium">{user.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <Phone className="w-5 h-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-600">Phone</p>
                      <p className="font-medium">
                        {mockFacilityProfile.phoneNumber}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <MapPin className="w-5 h-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-600">Address</p>
                      <p className="font-medium">
                        {mockFacilityProfile.fullAddress}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <Globe className="w-5 h-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-600">Website</p>
                      <a
                        href={mockFacilityProfile.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium text-medical-blue hover:text-blue-700 flex items-center"
                      >
                        {mockFacilityProfile.website}
                        <ExternalLink className="w-4 h-4 ml-1" />
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <User className="w-5 h-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-600">Primary Contact</p>
                      <p className="font-medium">
                        {mockFacilityProfile.contactPerson}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "shifts" && (
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">
                  All Open Shifts
                </h3>
                <div className="space-y-4">
                  {mockFacilityProfile.openShifts.map((shift, index) => (
                    <div
                      key={index}
                      className="p-4 border border-gray-200 rounded-lg hover:border-medical-blue transition-colors"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium text-gray-900">
                            {shift.position}
                          </h4>
                          {shift.urgent && (
                            <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">
                              Urgent
                            </span>
                          )}
                        </div>
                        <span className="text-lg font-bold text-gray-900">
                          ${shift.pay}/hr
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                        <div>
                          <p>
                            <strong>Department:</strong> {shift.department}
                          </p>
                          <p>
                            <strong>Date:</strong> {shift.date}
                          </p>
                        </div>
                        <div>
                          <p>
                            <strong>Time:</strong> {shift.time}
                          </p>
                          <p>
                            <strong>Duration:</strong> 12 hours
                          </p>
                        </div>
                      </div>
                      <div className="mt-3 flex justify-end">
                        <button className="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                          Edit Shift
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "reviews" && (
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">
                  Reviews & Feedback
                </h3>
                <div className="space-y-6">
                  {mockFacilityProfile.reviews.map((review, index) => (
                    <div
                      key={index}
                      className="border-b border-gray-200 pb-6 last:border-b-0"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-medical-blue to-ai-purple rounded-full flex items-center justify-center text-white text-sm font-bold">
                            {review.nurseName.charAt(0)}
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-900">
                              {review.nurseName}
                            </h4>
                            <p className="text-sm text-gray-600">
                              {review.date}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating
                                  ? "text-yellow-500 fill-current"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-gray-700">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Quick Actions
              </h3>
              <div className="space-y-3">
                <Link
                  to="/dashboard/post-shift"
                  className="w-full bg-medical-blue text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Post New Shift
                </Link>
                <Link
                  to="/dashboard/applicants"
                  className="w-full bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center"
                >
                  <Users className="w-4 h-4 mr-2" />
                  Review Applicants
                </Link>
                <Link
                  to="/dashboard/analytics"
                  className="w-full bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center"
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  View Analytics
                </Link>
              </div>
            </div>

            {/* Facility Stats */}
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Facility Stats
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Shifts Posted</span>
                  <span className="font-medium text-gray-900">892</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Average Fill Time</span>
                  <span className="font-medium text-green-600">2.3 hours</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Nurse Retention</span>
                  <span className="font-medium text-green-600">87%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
