import React from "react";
import { Link } from "react-router-dom";
import {
  Brain,
  Stethoscope,
  Building2,
  Users,
  ArrowRight,
  CheckCircle,
  Clock,
  Shield,
  Star,
  Award,
  DollarSign,
  Calendar,
  TrendingUp,
  Heart,
  ChevronRight,
} from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";

export default function Register() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-medical-gray via-white to-ai-light">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            {/* Navigation Links */}
            <div className="flex items-center space-x-6">
              <Link
                to="/"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Home
              </Link>
              <Link
                to="/about"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                About
              </Link>
              <Link
                to="/login"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Sign In
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-header font-bold text-gray-900 mb-6">
              Choose Your Path to Success
            </h1>
            <p className="text-xl text-gray-600 font-body max-w-3xl mx-auto mb-8">
              Join thousands of healthcare professionals and facilities who
              trust ProLinkAi for smarter staffing solutions powered by
              artificial intelligence.
            </p>
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <Badge className="bg-green-100 text-green-800 px-4 py-2">
                <CheckCircle className="w-4 h-4 mr-2" />
                Free to Join
              </Badge>
              <Badge className="bg-blue-100 text-blue-800 px-4 py-2">
                <Shield className="w-4 h-4 mr-2" />
                Verified Platform
              </Badge>
              <Badge className="bg-purple-100 text-purple-800 px-4 py-2">
                <Brain className="w-4 h-4 mr-2" />
                AI-Powered Matching
              </Badge>
            </div>
          </div>

          {/* Registration Options */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Nurse Registration */}
            <Card className="relative overflow-hidden border-2 hover:border-medical-blue transition-all duration-300 hover:shadow-xl group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-medical-blue/20 to-ai-purple/20 rounded-full -mr-16 -mt-16"></div>
              <CardHeader className="pb-4">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Stethoscope className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-gray-900">
                      Healthcare Professionals
                    </CardTitle>
                    <p className="text-gray-600">
                      For Nurses, CNAs, and Healthcare Staff
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-gray-700 leading-relaxed">
                  Find high-paying shifts that match your skills, schedule, and
                  location preferences. Our AI technology connects you with the
                  best opportunities in your area.
                </p>

                {/* Benefits */}
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      Flexible scheduling that fits your life
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <DollarSign className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      Competitive rates + premium pay opportunities
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Brain className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      AI-powered job matching
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      Professional liability coverage
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      Same-day pay available
                    </span>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-medical-blue">
                      $72
                    </div>
                    <div className="text-xs text-gray-600">
                      Avg. Hourly Rate
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-medical-blue">
                      4.9★
                    </div>
                    <div className="text-xs text-gray-600">Platform Rating</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-medical-blue">
                      15k+
                    </div>
                    <div className="text-xs text-gray-600">Active Nurses</div>
                  </div>
                </div>

                <Link to="/register/nurse" className="block">
                  <Button className="w-full bg-gradient-to-r from-medical-blue to-ai-purple hover:from-blue-700 hover:to-purple-600 text-white h-12 text-lg font-semibold group">
                    Start as Healthcare Professional
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>

                <div className="text-center">
                  <p className="text-sm text-gray-500">
                    Join in 3 minutes • License verification included
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Facility Registration */}
            <Card className="relative overflow-hidden border-2 hover:border-medical-green transition-all duration-300 hover:shadow-xl group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-medical-green/20 to-ai-purple/20 rounded-full -mr-16 -mt-16"></div>
              <CardHeader className="pb-4">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-medical-green to-ai-purple rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Building2 className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-gray-900">
                      Healthcare Facilities
                    </CardTitle>
                    <p className="text-gray-600">
                      For Hospitals, Clinics, and Care Centers
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-gray-700 leading-relaxed">
                  Fill your staffing needs quickly with qualified, verified
                  healthcare professionals. Our intelligent matching system
                  ensures you get the right staff every time.
                </p>

                {/* Benefits */}
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      Fill shifts 3x faster than traditional methods
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      Access to 15,000+ verified professionals
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Brain className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      AI-powered candidate matching
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Award className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      Quality assurance & compliance tracking
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <TrendingUp className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">
                      Detailed analytics & reporting
                    </span>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-medical-green">
                      94%
                    </div>
                    <div className="text-xs text-gray-600">Fill Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-medical-green">
                      2.1hr
                    </div>
                    <div className="text-xs text-gray-600">Avg. Fill Time</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-medical-green">
                      500+
                    </div>
                    <div className="text-xs text-gray-600">
                      Partner Facilities
                    </div>
                  </div>
                </div>

                <Link to="/register/facility" className="block">
                  <Button className="w-full bg-gradient-to-r from-medical-green to-ai-purple hover:from-green-700 hover:to-purple-600 text-white h-12 text-lg font-semibold group">
                    Start as Healthcare Facility
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>

                <div className="text-center">
                  <p className="text-sm text-gray-500">
                    Setup in 5 minutes • Facility verification included
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Trust Indicators */}
          <div className="mt-16 text-center">
            <p className="text-gray-600 mb-8">
              Trusted by leading healthcare organizations
            </p>
            <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
              <div className="flex items-center gap-2">
                <Building2 className="w-6 h-6 text-gray-400" />
                <span className="text-gray-600 font-semibold">UCSF Health</span>
              </div>
              <div className="flex items-center gap-2">
                <Heart className="w-6 h-6 text-gray-400" />
                <span className="text-gray-600 font-semibold">
                  Kaiser Permanente
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-6 h-6 text-gray-400" />
                <span className="text-gray-600 font-semibold">
                  Sutter Health
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-6 h-6 text-gray-400" />
                <span className="text-gray-600 font-semibold">
                  Stanford Health
                </span>
              </div>
            </div>
          </div>

          {/* Already have an account */}
          <div className="mt-12 text-center">
            <p className="text-gray-600">
              Already have an account?{" "}
              <Link
                to="/login"
                className="text-medical-blue hover:text-blue-700 font-semibold"
              >
                Sign in here
              </Link>
            </p>
          </div>
        </div>
      </div>

      {/* How it Works Section */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-header font-bold text-gray-900 mb-4">
              How ProLinkAi Works
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our AI-powered platform makes healthcare staffing simple,
              efficient, and reliable.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Sign Up & Verify
              </h3>
              <p className="text-gray-600">
                Create your profile and complete our quick verification process.
                We'll verify your credentials and professional background.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Get Matched
              </h3>
              <p className="text-gray-600">
                Our AI analyzes your skills, preferences, and availability to
                match you with the perfect opportunities or candidates.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Start Working
              </h3>
              <p className="text-gray-600">
                Connect, communicate, and get to work. Our platform handles
                payments, scheduling, and compliance automatically.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer CTA */}
      <div className="bg-gradient-to-r from-medical-blue to-ai-purple py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-header font-bold text-white mb-4">
            Ready to Transform Your Healthcare Career?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of healthcare professionals who have already made the
            switch to smarter staffing.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register/nurse">
              <Button className="bg-white text-medical-blue hover:bg-gray-100 px-8 py-3 text-lg font-semibold w-full sm:w-auto">
                Join as Healthcare Professional
              </Button>
            </Link>
            <Link to="/register/facility">
              <Button className="bg-white/20 text-white hover:bg-white/30 border border-white/30 px-8 py-3 text-lg font-semibold w-full sm:w-auto">
                Join as Healthcare Facility
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
