import React, { useState } from 'react';
import { Calendar, Clock, Users, MapPin, DollarSign, Filter, Search, Plus, Edit, Trash2, Eye, CheckCircle, AlertCircle, XCircle, Brain, TrendingUp, BarChart3, Download } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Progress } from '../components/ui/progress';

interface Shift {
  id: string;
  title: string;
  department: string;
  facility: string;
  date: string;
  startTime: string;
  endTime: string;
  hourlyRate: number;
  status: 'draft' | 'published' | 'filled' | 'completed' | 'cancelled';
  applications: number;
  assignedNurse?: {
    id: string;
    name: string;
    avatar?: string;
    rating: number;
  };
  urgency: 'low' | 'normal' | 'high' | 'urgent';
  requirements: string[];
  location: string;
  postedBy: string;
  postedDate: string;
  completionRate?: number;
  aiMatchScore?: number;
}

interface ShiftMetrics {
  totalShifts: number;
  fillRate: number;
  avgResponseTime: number;
  avgRating: number;
  revenue: number;
  growthRate: number;
}

export default function ShiftManagement() {
  const [selectedView, setSelectedView] = useState<'list' | 'calendar' | 'analytics'>('list');
  const [statusFilter, setStatusFilter] = useState<'all' | 'draft' | 'published' | 'filled' | 'completed' | 'cancelled'>('all');
  const [urgencyFilter, setUrgencyFilter] = useState<'all' | 'low' | 'normal' | 'high' | 'urgent'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedShifts, setSelectedShifts] = useState<string[]>([]);

  const [shifts, setShifts] = useState<Shift[]>([
    {
      id: '1',
      title: 'ICU Night Shift Nurse',
      department: 'ICU',
      facility: 'SF General Hospital',
      date: '2024-02-10',
      startTime: '19:00',
      endTime: '07:00',
      hourlyRate: 52,
      status: 'filled',
      applications: 23,
      assignedNurse: {
        id: 'n1',
        name: 'Sarah Johnson',
        avatar: '/api/placeholder/40/40',
        rating: 4.9
      },
      urgency: 'high',
      requirements: ['RN License', 'BLS', 'ICU Experience'],
      location: 'San Francisco, CA',
      postedBy: 'Maria Rodriguez',
      postedDate: '2024-02-05',
      completionRate: 98,
      aiMatchScore: 96
    },
    {
      id: '2',
      title: 'Emergency Department RN',
      department: 'Emergency',
      facility: 'Stanford Medical Center',
      date: '2024-02-12',
      startTime: '07:00',
      endTime: '19:00',
      hourlyRate: 48,
      status: 'published',
      applications: 15,
      urgency: 'urgent',
      requirements: ['RN License', 'BLS', 'ACLS', 'Trauma Experience'],
      location: 'Stanford, CA',
      postedBy: 'Dr. Chen',
      postedDate: '2024-02-06',
      aiMatchScore: 87
    },
    {
      id: '3',
      title: 'Medical-Surgical Day Shift',
      department: 'Med-Surg',
      facility: 'UCSF Medical Center',
      date: '2024-02-15',
      startTime: '07:00',
      endTime: '19:00',
      hourlyRate: 45,
      status: 'completed',
      applications: 31,
      assignedNurse: {
        id: 'n2',
        name: 'Jennifer Wilson',
        avatar: '/api/placeholder/40/40',
        rating: 4.7
      },
      urgency: 'normal',
      requirements: ['RN License', 'BLS', 'Medical-Surgical Experience'],
      location: 'San Francisco, CA',
      postedBy: 'Lisa Park',
      postedDate: '2024-01-28',
      completionRate: 100,
      aiMatchScore: 92
    },
    {
      id: '4',
      title: 'Pediatric ICU Specialist',
      department: 'PICU',
      facility: 'Children\'s Hospital',
      date: '2024-02-08',
      startTime: '15:00',
      endTime: '03:00',
      hourlyRate: 55,
      status: 'cancelled',
      applications: 8,
      urgency: 'high',
      requirements: ['RN License', 'BLS', 'PICU Certification', 'Pediatric Experience'],
      location: 'Oakland, CA',
      postedBy: 'Dr. Martinez',
      postedDate: '2024-02-03',
      aiMatchScore: 78
    },
    {
      id: '5',
      title: 'Operating Room Nurse',
      department: 'OR',
      facility: 'SF General Hospital',
      date: '2024-02-14',
      startTime: '06:00',
      endTime: '14:00',
      hourlyRate: 50,
      status: 'draft',
      applications: 0,
      urgency: 'low',
      requirements: ['RN License', 'BLS', 'OR Experience', 'Surgical Instruments'],
      location: 'San Francisco, CA',
      postedBy: 'Maria Rodriguez',
      postedDate: '2024-02-07',
      aiMatchScore: 85
    }
  ]);

  const metrics: ShiftMetrics = {
    totalShifts: shifts.length,
    fillRate: (shifts.filter(s => s.status === 'filled' || s.status === 'completed').length / shifts.length) * 100,
    avgResponseTime: 4.2,
    avgRating: 4.6,
    revenue: 125420,
    growthRate: 12.5
  };

  const filteredShifts = shifts.filter(shift => {
    const matchesSearch = shift.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         shift.facility.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         shift.department.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || shift.status === statusFilter;
    const matchesUrgency = urgencyFilter === 'all' || shift.urgency === urgencyFilter;
    
    return matchesSearch && matchesStatus && matchesUrgency;
  });

  const handleSelectShift = (shiftId: string) => {
    setSelectedShifts(prev => 
      prev.includes(shiftId)
        ? prev.filter(id => id !== shiftId)
        : [...prev, shiftId]
    );
  };

  const handleShiftAction = (shiftId: string, action: 'edit' | 'delete' | 'publish' | 'cancel' | 'duplicate') => {
    console.log(`${action} shift ${shiftId}`);
    // In a real app, this would call the appropriate API
    
    if (action === 'publish') {
      setShifts(shifts.map(shift => 
        shift.id === shiftId ? { ...shift, status: 'published' as const } : shift
      ));
    } else if (action === 'cancel') {
      setShifts(shifts.map(shift => 
        shift.id === shiftId ? { ...shift, status: 'cancelled' as const } : shift
      ));
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'published': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'filled': return 'bg-green-100 text-green-800 border-green-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'draft': return <Edit className="w-4 h-4" />;
      case 'published': return <Clock className="w-4 h-4" />;
      case 'filled': return <CheckCircle className="w-4 h-4" />;
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'cancelled': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'low': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'normal': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getAIScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent">
            Shift Management
          </h1>
          <p className="text-gray-600 mt-2">
            Platform shift oversight with AI analytics and optimization
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90">
            <Plus className="w-4 h-4 mr-2" />
            Create Shift
          </Button>
        </div>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-medical-blue">{metrics.totalShifts}</div>
            <div className="text-sm text-gray-600">Total Shifts</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{metrics.fillRate.toFixed(1)}%</div>
            <div className="text-sm text-gray-600">Fill Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{metrics.avgResponseTime}h</div>
            <div className="text-sm text-gray-600">Avg Response</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{metrics.avgRating}</div>
            <div className="text-sm text-gray-600">Avg Rating</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">${metrics.revenue.toLocaleString()}</div>
            <div className="text-sm text-gray-600">Revenue</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center gap-1">
              <div className="text-2xl font-bold text-green-600">+{metrics.growthRate}%</div>
              <TrendingUp className="w-4 h-4 text-green-600" />
            </div>
            <div className="text-sm text-gray-600">Growth</div>
          </CardContent>
        </Card>
      </div>

      {/* AI Analytics Panel */}
      <Card className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 border-ai-purple/20">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-5 h-5 text-ai-purple" />
            <h3 className="font-semibold text-ai-purple">AI Shift Analytics</h3>
            <Badge className="bg-ai-purple/10 text-ai-purple border-ai-purple/20">
              Real-time
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-white/50 rounded-lg border border-ai-purple/10">
              <div className="text-xl font-bold text-ai-purple">94%</div>
              <div className="text-sm text-gray-600">Optimal Match Rate</div>
              <div className="text-xs text-gray-500 mt-1">AI finds perfect nurse-shift pairs</div>
            </div>
            <div className="p-4 bg-white/50 rounded-lg border border-ai-purple/10">
              <div className="text-xl font-bold text-ai-purple">23 min</div>
              <div className="text-sm text-gray-600">Avg Fill Time</div>
              <div className="text-xs text-gray-500 mt-1">From posting to acceptance</div>
            </div>
            <div className="p-4 bg-white/50 rounded-lg border border-ai-purple/10">
              <div className="text-xl font-bold text-ai-purple">8.7/10</div>
              <div className="text-sm text-gray-600">Satisfaction Score</div>
              <div className="text-xs text-gray-500 mt-1">Facility + nurse combined rating</div>
            </div>
            <div className="p-4 bg-white/50 rounded-lg border border-ai-purple/10">
              <div className="text-xl font-bold text-ai-purple">$127K</div>
              <div className="text-sm text-gray-600">Revenue Optimized</div>
              <div className="text-xs text-gray-500 mt-1">AI-driven pricing recommendations</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* View Toggle and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4 justify-between">
            <div className="flex items-center gap-2">
              <Button
                variant={selectedView === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedView('list')}
              >
                List View
              </Button>
              <Button
                variant={selectedView === 'calendar' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedView('calendar')}
              >
                Calendar View
              </Button>
              <Button
                variant={selectedView === 'analytics' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedView('analytics')}
              >
                <BarChart3 className="w-4 h-4 mr-1" />
                Analytics
              </Button>
            </div>

            <div className="flex gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search shifts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
              >
                <option value="all">All Status</option>
                <option value="draft">Draft</option>
                <option value="published">Published</option>
                <option value="filled">Filled</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
              
              <select
                value={urgencyFilter}
                onChange={(e) => setUrgencyFilter(e.target.value as any)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
              >
                <option value="all">All Urgency</option>
                <option value="urgent">Urgent</option>
                <option value="high">High</option>
                <option value="normal">Normal</option>
                <option value="low">Low</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Shifts List */}
      {selectedView === 'list' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Shifts ({filteredShifts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredShifts.map((shift) => (
                <div
                  key={shift.id}
                  className={`p-4 border rounded-lg transition-all hover:shadow-sm ${
                    selectedShifts.includes(shift.id) ? 'border-medical-blue bg-medical-blue/5' : ''
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <input
                      type="checkbox"
                      checked={selectedShifts.includes(shift.id)}
                      onChange={() => handleSelectShift(shift.id)}
                      className="mt-1"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-gray-900 text-lg">{shift.title}</h4>
                          <p className="text-medical-blue font-medium">{shift.facility}</p>
                          <p className="text-sm text-gray-600">{shift.department} • {shift.location}</p>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Badge className={getStatusColor(shift.status)}>
                            <div className="flex items-center gap-1">
                              {getStatusIcon(shift.status)}
                              {shift.status.charAt(0).toUpperCase() + shift.status.slice(1)}
                            </div>
                          </Badge>
                          <Badge className={getUrgencyColor(shift.urgency)}>
                            {shift.urgency.charAt(0).toUpperCase() + shift.urgency.slice(1)}
                          </Badge>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 text-sm mb-4">
                        <div>
                          <span className="text-gray-600">Date & Time:</span>
                          <div className="font-medium">
                            {new Date(shift.date).toLocaleDateString()}
                          </div>
                          <div className="text-gray-500">
                            {shift.startTime} - {shift.endTime}
                          </div>
                        </div>
                        
                        <div>
                          <span className="text-gray-600">Rate:</span>
                          <div className="font-medium text-green-600">
                            ${shift.hourlyRate}/hour
                          </div>
                        </div>
                        
                        <div>
                          <span className="text-gray-600">Applications:</span>
                          <div className="font-medium">{shift.applications}</div>
                        </div>
                        
                        <div>
                          <span className="text-gray-600">Posted By:</span>
                          <div className="font-medium">{shift.postedBy}</div>
                          <div className="text-gray-500">
                            {new Date(shift.postedDate).toLocaleDateString()}
                          </div>
                        </div>
                        
                        {shift.aiMatchScore && (
                          <div>
                            <span className="text-gray-600">AI Match:</span>
                            <div className={`font-medium ${getAIScoreColor(shift.aiMatchScore)}`}>
                              {shift.aiMatchScore}%
                            </div>
                          </div>
                        )}
                        
                        {shift.completionRate && (
                          <div>
                            <span className="text-gray-600">Completion:</span>
                            <div className="font-medium text-green-600">
                              {shift.completionRate}%
                            </div>
                          </div>
                        )}
                      </div>

                      {shift.assignedNurse && (
                        <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg mb-4">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={shift.assignedNurse.avatar} />
                            <AvatarFallback className="bg-gradient-to-br from-medical-blue to-ai-purple text-white text-sm">
                              {shift.assignedNurse.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium text-sm">Assigned to: {shift.assignedNurse.name}</div>
                            <div className="text-xs text-gray-600">Rating: ⭐ {shift.assignedNurse.rating}</div>
                          </div>
                        </div>
                      )}

                      <div className="mb-4">
                        <span className="text-sm text-gray-600">Requirements: </span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {shift.requirements.map((req, index) => (
                            <Badge key={index} className="bg-blue-100 text-blue-800 border-blue-200 text-xs">
                              {req}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {shift.aiMatchScore && (
                        <div className="mb-4 p-3 bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 rounded-lg border border-ai-purple/20">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Brain className="w-4 h-4 text-ai-purple" />
                              <span className="text-sm font-medium text-ai-purple">AI Analysis</span>
                            </div>
                            <span className={`text-sm font-bold ${getAIScoreColor(shift.aiMatchScore)}`}>
                              {shift.aiMatchScore}% Match Score
                            </span>
                          </div>
                          <div className="space-y-1 text-xs text-gray-600">
                            <div>• Expected applications: {Math.round(shift.applications * 1.2)}</div>
                            <div>• Optimal pricing detected</div>
                            <div>• High-quality candidate pool available</div>
                          </div>
                        </div>
                      )}

                      <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                        <div className="text-xs text-gray-500">
                          ID: {shift.id} | Posted: {new Date(shift.postedDate).toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleShiftAction(shift.id, 'edit')}
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            View
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleShiftAction(shift.id, 'edit')}
                          >
                            <Edit className="w-4 h-4 mr-1" />
                            Edit
                          </Button>
                          {shift.status === 'draft' && (
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleShiftAction(shift.id, 'publish')}
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Publish
                            </Button>
                          )}
                          {(shift.status === 'published' || shift.status === 'filled') && (
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleShiftAction(shift.id, 'cancel')}
                            >
                              <XCircle className="w-4 h-4 mr-1" />
                              Cancel
                            </Button>
                          )}
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleShiftAction(shift.id, 'duplicate')}
                          >
                            <Plus className="w-4 h-4 mr-1" />
                            Duplicate
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredShifts.length === 0 && (
              <div className="text-center py-12">
                <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No Shifts Found</h3>
                <p className="text-gray-500">
                  Try adjusting your search criteria or filters.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Calendar View */}
      {selectedView === 'calendar' && (
        <Card>
          <CardHeader>
            <CardTitle>Calendar View</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Calendar View</h3>
              <p className="text-gray-500">
                Interactive calendar view would be implemented here with a calendar library like FullCalendar or react-big-calendar.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Analytics View */}
      {selectedView === 'analytics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Fill Rate Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>This Week</span>
                  <div className="flex items-center gap-2">
                    <Progress value={87} className="w-32 h-2" />
                    <span className="text-sm font-medium">87%</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span>Last Week</span>
                  <div className="flex items-center gap-2">
                    <Progress value={92} className="w-32 h-2" />
                    <span className="text-sm font-medium">92%</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span>This Month</span>
                  <div className="flex items-center gap-2">
                    <Progress value={89} className="w-32 h-2" />
                    <span className="text-sm font-medium">89%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Department Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {['ICU', 'Emergency', 'Med-Surg', 'OR', 'PICU'].map((dept, index) => (
                  <div key={dept} className="flex justify-between items-center">
                    <span>{dept}</span>
                    <div className="flex items-center gap-2">
                      <Progress value={[95, 88, 91, 85, 78][index]} className="w-24 h-2" />
                      <span className="text-sm font-medium">{[95, 88, 91, 85, 78][index]}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
