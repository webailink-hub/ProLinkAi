import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Calendar, Clock, DollarSign, MapPin, Users, Star, ArrowLeft, Send, Phone, Mail, CheckCircle, AlertCircle, Brain, Badge, FileText, MessageSquare } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge as UIBadge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';

interface ShiftDetailsType {
  id: string;
  title: string;
  department: string;
  facility: {
    name: string;
    address: string;
    phone: string;
    email: string;
    avatar: string;
    rating: number;
    description: string;
  };
  date: string;
  startTime: string;
  endTime: string;
  hourlyRate: number;
  urgency: 'low' | 'normal' | 'high' | 'urgent';
  status: 'open' | 'filled' | 'completed' | 'cancelled';
  description: string;
  requirements: string[];
  benefits: string[];
  contactPerson: {
    name: string;
    title: string;
    phone: string;
    email: string;
  };
  applications: number;
  aiMatchScore?: number;
  patientRatio: string;
  specialInstructions: string;
  parkingInfo: string;
  dressCode: string;
}

export default function ShiftDetails() {
  const { shiftId } = useParams();
  const navigate = useNavigate();
  const [hasApplied, setHasApplied] = useState(false);
  const [showContactInfo, setShowContactInfo] = useState(false);

  // Mock data - in real app, fetch based on shiftId
  const shift: ShiftDetailsType = {
    id: shiftId || '1',
    title: 'ICU Night Shift Nurse',
    department: 'Intensive Care Unit',
    facility: {
      name: 'SF General Hospital',
      address: '1001 Potrero Ave, San Francisco, CA 94110',
      phone: '(415) 206-8000',
      email: 'nursing@sfgeneral.org',
      avatar: '/api/placeholder/80/80',
      rating: 4.7,
      description: 'Leading trauma center providing comprehensive emergency and critical care services to the San Francisco community.'
    },
    date: '2024-02-15',
    startTime: '19:00',
    endTime: '07:00',
    hourlyRate: 52,
    urgency: 'high',
    status: 'open',
    description: 'Seeking an experienced ICU nurse for night shift coverage. This position involves caring for critically ill patients in our 24-bed ICU. You will work alongside a multidisciplinary team including physicians, respiratory therapists, and support staff.',
    requirements: [
      'Active RN License (California)',
      'BLS Certification',
      'ACLS Certification',
      'ICU Experience (2+ years)',
      'Critical Care Certification (CCRN preferred)',
      'COVID-19 Vaccination'
    ],
    benefits: [
      'Premium night shift differential',
      'Free parking',
      'Meals provided',
      'Access to continuing education',
      'Professional development opportunities'
    ],
    contactPerson: {
      name: 'Maria Rodriguez',
      title: 'Nursing Supervisor',
      phone: '(415) 206-8123',
      email: 'maria.rodriguez@sfgeneral.org'
    },
    applications: 23,
    aiMatchScore: 96,
    patientRatio: '1:2 patient ratio',
    specialInstructions: 'Report to ICU Nursing Station on Level 4. Please arrive 15 minutes early for shift briefing.',
    parkingInfo: 'Free staff parking available in Garage C. Validation required at nursing station.',
    dressCode: 'Hospital scrubs required. Navy blue or hospital-approved colors only.'
  };

  const handleApply = () => {
    setHasApplied(true);
    // In real app, send application to API
  };

  const handleMessage = () => {
    navigate('/dashboard/messages');
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'normal': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'low': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-green-100 text-green-800 border-green-200';
      case 'filled': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'completed': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const calculateShiftDuration = () => {
    const start = new Date(`2024-01-01 ${shift.startTime}`);
    const end = new Date(`2024-01-01 ${shift.endTime}`);
    if (end < start) end.setDate(end.getDate() + 1); // Handle overnight shifts
    const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
    return hours;
  };

  const totalPay = calculateShiftDuration() * shift.hourlyRate;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button variant="ghost" onClick={() => navigate(-1)} className="mr-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{shift.title}</h1>
            <p className="text-gray-600">{shift.facility.name} • {shift.department}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Shift Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Shift Overview</span>
                  <div className="flex gap-2">
                    <UIBadge className={getStatusColor(shift.status)}>
                      {shift.status.charAt(0).toUpperCase() + shift.status.slice(1)}
                    </UIBadge>
                    <UIBadge className={getUrgencyColor(shift.urgency)}>
                      {shift.urgency.charAt(0).toUpperCase() + shift.urgency.slice(1)} Priority
                    </UIBadge>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Calendar className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">
                        {new Date(shift.date).toLocaleDateString()}
                      </div>
                      <div className="text-sm text-gray-600">Date</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-100 rounded-lg">
                      <Clock className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">
                        {shift.startTime} - {shift.endTime}
                      </div>
                      <div className="text-sm text-gray-600">{calculateShiftDuration()} hours</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-green-100 rounded-lg">
                      <DollarSign className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">${shift.hourlyRate}/hr</div>
                      <div className="text-sm text-gray-600">Total: ${totalPay}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-orange-100 rounded-lg">
                      <Users className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">{shift.applications}</div>
                      <div className="text-sm text-gray-600">Applications</div>
                    </div>
                  </div>
                </div>

                {/* AI Match Score */}
                {shift.aiMatchScore && (
                  <div className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 rounded-lg p-4 border border-ai-purple/20 mb-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Brain className="w-5 h-5 text-ai-purple" />
                        <span className="font-semibold text-ai-purple">AI Compatibility Match</span>
                      </div>
                      <div className="text-2xl font-bold text-ai-purple">{shift.aiMatchScore}%</div>
                    </div>
                    <p className="text-sm text-gray-600 mt-2">
                      Based on your experience, credentials, and preferences, this shift is an excellent match for your profile.
                    </p>
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Shift Description</h4>
                    <p className="text-gray-700">{shift.description}</p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Key Details</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-gray-500" />
                        <span>{shift.patientRatio}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span>{shift.department}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Requirements */}
            <Card>
              <CardHeader>
                <CardTitle>Requirements & Qualifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-2">
                  {shift.requirements.map((req, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-gray-700">{req}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Benefits */}
            <Card>
              <CardHeader>
                <CardTitle>Benefits & Perks</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-2">
                  {shift.benefits.map((benefit, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span className="text-gray-700">{benefit}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Additional Information */}
            <Card>
              <CardHeader>
                <CardTitle>Additional Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Special Instructions</h4>
                  <p className="text-gray-700">{shift.specialInstructions}</p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Parking Information</h4>
                  <p className="text-gray-700">{shift.parkingInfo}</p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Dress Code</h4>
                  <p className="text-gray-700">{shift.dressCode}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Application Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Apply for this Shift</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!hasApplied ? (
                  <>
                    <Button 
                      onClick={handleApply}
                      className="w-full bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Apply Now
                    </Button>
                    <Button variant="outline" className="w-full" onClick={handleMessage}>
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Ask Questions
                    </Button>
                  </>
                ) : (
                  <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
                    <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                    <h4 className="font-semibold text-green-800">Application Submitted!</h4>
                    <p className="text-sm text-green-700 mt-1">
                      You'll hear back within 24 hours
                    </p>
                  </div>
                )}
                
                <div className="text-xs text-gray-500 text-center">
                  Applications are reviewed within 2-4 hours
                </div>
              </CardContent>
            </Card>

            {/* Facility Information */}
            <Card>
              <CardHeader>
                <CardTitle>Facility Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={shift.facility.avatar} />
                      <AvatarFallback>{shift.facility.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-semibold text-gray-900">{shift.facility.name}</h4>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span className="text-sm text-gray-600">{shift.facility.rating} rating</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-sm text-gray-700">{shift.facility.description}</p>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-700">{shift.facility.address}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-700">{shift.facility.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-700">{shift.facility.email}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contact Person */}
            <Card>
              <CardHeader>
                <CardTitle>Contact Person</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-gray-900">{shift.contactPerson.name}</h4>
                    <p className="text-sm text-gray-600">{shift.contactPerson.title}</p>
                  </div>

                  {showContactInfo ? (
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-700">{shift.contactPerson.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-700">{shift.contactPerson.email}</span>
                      </div>
                    </div>
                  ) : (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setShowContactInfo(true)}
                      className="w-full"
                    >
                      Show Contact Info
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Applications</span>
                  <span className="font-semibold">{shift.applications}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shift Duration</span>
                  <span className="font-semibold">{calculateShiftDuration()} hours</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Pay</span>
                  <span className="font-semibold text-green-600">${totalPay}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Response Rate</span>
                  <span className="font-semibold">2.3 hours avg</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
