import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Search,
  Filter,
  MapPin,
  Calendar,
  Clock,
  DollarSign,
  Star,
  Award,
  Building2,
  Navigation,
  Heart,
  Zap,
  TrendingUp,
  CheckCircle2,
  Eye,
  Bookmark,
  BookmarkCheck,
  AlertCircle,
  Users,
  Shield,
  Briefcase,
  ArrowRight,
  SlidersHorizontal,
  RefreshCw,
  ThumbsUp,
  MessageSquare,
  Share2,
  ExternalLink,
  Plus,
  X,
} from "lucide-react";

interface Shift {
  id: string;
  title: string;
  facilityName: string;
  facilityLogo: string;
  facilityRating: number;
  location: string;
  distance: string;
  shiftDate: string;
  shiftTime: string;
  duration: string;
  hourlyRate: number;
  totalPay: number;
  urgency: "normal" | "high" | "urgent";
  requirements: string[];
  benefits: string[];
  description: string;
  department: string;
  experienceLevel: "entry" | "mid" | "senior";
  postedDate: string;
  applicants: number;
  matchScore: number;
  isBookmarked: boolean;
  hasApplied: boolean;
  facilityType: string;
  shiftType: "day" | "night" | "weekend" | "holiday";
  bonuses?: string[];
}

export default function Shifts() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<"cards" | "list">("cards");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedShift, setSelectedShift] = useState<Shift | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    location: "",
    dateRange: "",
    hourlyRateMin: "",
    hourlyRateMax: "",
    department: "",
    shiftType: "",
    urgency: "",
    experienceLevel: "",
  });

  // Mock data - in real app this would come from API
  const shifts: Shift[] = [
    {
      id: "1",
      title: "ICU Nurse - Night Shift",
      facilityName: "UCSF Medical Center",
      facilityLogo:
        "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=64&h=64&fit=crop",
      facilityRating: 4.8,
      location: "San Francisco, CA",
      distance: "2.3 miles",
      shiftDate: "Jan 15, 2024",
      shiftTime: "7:00 PM - 7:00 AM",
      duration: "12 hours",
      hourlyRate: 58,
      totalPay: 696,
      urgency: "high",
      requirements: ["BLS", "ACLS", "2+ years ICU experience"],
      benefits: ["Parking included", "Meal vouchers", "Premium pay"],
      description:
        "Seeking experienced ICU nurse for night shift coverage. Unit specializes in cardiac and trauma patients.",
      department: "ICU",
      experienceLevel: "mid",
      postedDate: "2 hours ago",
      applicants: 12,
      matchScore: 96,
      isBookmarked: false,
      hasApplied: false,
      facilityType: "Academic Medical Center",
      shiftType: "night",
      bonuses: ["$50 completion bonus", "Holiday pay eligible"],
    },
    {
      id: "2",
      title: "Emergency Department Nurse",
      facilityName: "Stanford Hospital",
      facilityLogo:
        "https://images.unsplash.com/photo-1551076805-e1869033e561?w=64&h=64&fit=crop",
      facilityRating: 4.7,
      location: "Palo Alto, CA",
      distance: "8.1 miles",
      shiftDate: "Jan 16, 2024",
      shiftTime: "3:00 PM - 11:00 PM",
      duration: "8 hours",
      hourlyRate: 52,
      totalPay: 416,
      urgency: "urgent",
      requirements: ["BLS", "ACLS", "TNCC preferred", "1+ years ED experience"],
      benefits: ["Free parking", "Cafeteria discount", "Flexible scheduling"],
      description:
        "Fast-paced ED seeking skilled nurse for evening shift. Level 1 trauma center with high acuity patients.",
      department: "Emergency",
      experienceLevel: "mid",
      postedDate: "4 hours ago",
      applicants: 8,
      matchScore: 89,
      isBookmarked: true,
      hasApplied: false,
      facilityType: "Level 1 Trauma Center",
      shiftType: "day",
    },
    {
      id: "3",
      title: "Medical-Surgical Float Nurse",
      facilityName: "Kaiser Permanente",
      facilityLogo:
        "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=64&h=64&fit=crop",
      facilityRating: 4.5,
      location: "Oakland, CA",
      distance: "12.5 miles",
      shiftDate: "Jan 17, 2024",
      shiftTime: "7:00 AM - 7:00 PM",
      duration: "12 hours",
      hourlyRate: 48,
      totalPay: 576,
      urgency: "normal",
      requirements: [
        "BLS",
        "Med-Surg experience",
        "Float pool experience preferred",
      ],
      benefits: [
        "Health insurance discount",
        "PTO accrual",
        "Career development",
      ],
      description:
        "Float nurse needed for medical-surgical units. Opportunity to work across multiple specialties.",
      department: "Medical-Surgical",
      experienceLevel: "entry",
      postedDate: "1 day ago",
      applicants: 15,
      matchScore: 82,
      isBookmarked: false,
      hasApplied: true,
      facilityType: "Integrated Health System",
      shiftType: "day",
    },
    {
      id: "4",
      title: "Operating Room Circulator",
      facilityName: "SF General Hospital",
      facilityLogo:
        "https://images.unsplash.com/photo-1504813184591-01572f98c85f?w=64&h=64&fit=crop",
      facilityRating: 4.6,
      location: "San Francisco, CA",
      distance: "5.7 miles",
      shiftDate: "Jan 18, 2024",
      shiftTime: "6:00 AM - 4:00 PM",
      duration: "10 hours",
      hourlyRate: 65,
      totalPay: 650,
      urgency: "high",
      requirements: [
        "BLS",
        "CNOR preferred",
        "3+ years OR experience",
        "Trauma experience",
      ],
      benefits: [
        "Scrubs provided",
        "Continuing education fund",
        "Mentorship program",
      ],
      description:
        "Experienced OR nurse needed for trauma surgery cases. Must be comfortable with high-stress environment.",
      department: "Operating Room",
      experienceLevel: "senior",
      postedDate: "6 hours ago",
      applicants: 5,
      matchScore: 75,
      isBookmarked: true,
      hasApplied: false,
      facilityType: "Public Hospital",
      shiftType: "day",
      bonuses: ["Weekend differential", "$100 completion bonus"],
    },
    {
      id: "5",
      title: "NICU Nurse - Weekend Coverage",
      facilityName: "CPMC Mission Bernal",
      facilityLogo:
        "https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=64&h=64&fit=crop",
      facilityRating: 4.4,
      location: "San Francisco, CA",
      distance: "4.2 miles",
      shiftDate: "Jan 20, 2024",
      shiftTime: "11:00 PM - 7:00 AM",
      duration: "8 hours",
      hourlyRate: 55,
      totalPay: 440,
      urgency: "normal",
      requirements: [
        "BLS",
        "NRP",
        "NICU experience",
        "Comfort with high-risk neonates",
      ],
      benefits: ["Weekend premium", "Free meals", "Quiet unit environment"],
      description:
        "NICU weekend coverage for Level III nursery. Small unit with excellent nurse-to-patient ratios.",
      department: "NICU",
      experienceLevel: "mid",
      postedDate: "3 days ago",
      applicants: 7,
      matchScore: 68,
      isBookmarked: false,
      hasApplied: false,
      facilityType: "Community Hospital",
      shiftType: "weekend",
    },
    {
      id: "6",
      title: "Telemetry Nurse - Holiday Coverage",
      facilityName: "UCSF Parnassus",
      facilityLogo:
        "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=64&h=64&fit=crop",
      facilityRating: 4.9,
      location: "San Francisco, CA",
      distance: "3.1 miles",
      shiftDate: "Dec 25, 2024",
      shiftTime: "7:00 AM - 7:00 PM",
      duration: "12 hours",
      hourlyRate: 62,
      totalPay: 744,
      urgency: "high",
      requirements: [
        "BLS",
        "ACLS",
        "Telemetry experience",
        "Holiday availability",
      ],
      benefits: ["Holiday pay x2", "Premium parking", "Holiday meal provided"],
      description:
        "Holiday coverage needed for cardiac telemetry unit. Competitive holiday pay rates.",
      department: "Telemetry",
      experienceLevel: "mid",
      postedDate: "1 week ago",
      applicants: 20,
      matchScore: 91,
      isBookmarked: false,
      hasApplied: false,
      facilityType: "Academic Medical Center",
      shiftType: "holiday",
      bonuses: ["Double holiday pay", "Free holiday dinner"],
    },
  ];

  const getUrgencyBadge = (urgency: string) => {
    const urgencyConfig = {
      normal: { bg: "bg-blue-100", text: "text-blue-800", label: "Standard" },
      high: {
        bg: "bg-orange-100",
        text: "text-orange-800",
        label: "High Priority",
      },
      urgent: { bg: "bg-red-100", text: "text-red-800", label: "Urgent" },
    };

    const config = urgencyConfig[urgency as keyof typeof urgencyConfig];
    return (
      <span
        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}
      >
        {config.label}
      </span>
    );
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600 bg-green-100";
    if (score >= 80) return "text-blue-600 bg-blue-100";
    if (score >= 70) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  const toggleBookmark = (shiftId: string) => {
    // In real app, this would update the backend
    console.log(`Toggle bookmark for shift ${shiftId}`);
  };

  const applyToShift = (shiftId: string) => {
    // In real app, this would submit application
    console.log(`Apply to shift ${shiftId}`);
  };

  const filteredShifts = shifts.filter((shift) => {
    const matchesSearch =
      shift.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      shift.facilityName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      shift.department.toLowerCase().includes(searchTerm.toLowerCase());
    // Add filter logic here
    return matchesSearch;
  });

  const recommendedShifts = shifts.filter((shift) => shift.matchScore >= 85);
  const urgentShifts = shifts.filter((shift) => shift.urgency === "urgent");
  const bookmarkedShifts = shifts.filter((shift) => shift.isBookmarked);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-header font-bold text-gray-900 flex items-center">
            <Briefcase className="w-8 h-8 mr-3 text-medical-blue" />
            Find & Manage Shifts
          </h1>
          <p className="text-gray-600 font-body mt-2">
            AI-powered shift discovery with intelligent matching and
            personalized recommendations
          </p>
        </div>

        <div className="flex items-center gap-3 mt-4 lg:mt-0">
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode("cards")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                viewMode === "cards"
                  ? "bg-white text-medical-blue shadow-sm"
                  : "text-gray-600"
              }`}
            >
              Cards
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                viewMode === "list"
                  ? "bg-white text-medical-blue shadow-sm"
                  : "text-gray-600"
              }`}
            >
              List
            </button>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/dashboard/shift-calendar")}
              className="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Calendar View
            </button>
            <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-br from-ai-purple to-medical-blue rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Zap className="w-6 h-6 mr-3" />
            <h2 className="text-xl font-header font-bold">AI Shift Insights</h2>
          </div>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-5 h-5 text-white" />
              <span className="text-xs bg-white/20 px-2 py-1 rounded">
                Trending
              </span>
            </div>
            <h3 className="font-semibold mb-1">High Demand Areas</h3>
            <p className="text-blue-100 text-sm">
              ICU and Emergency shifts paying 15% above average
            </p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <Heart className="w-5 h-5 text-white" />
              <span className="text-xs bg-white/20 px-2 py-1 rounded">
                Match
              </span>
            </div>
            <h3 className="font-semibold mb-1">Perfect Matches</h3>
            <p className="text-blue-100 text-sm">
              {recommendedShifts.length} shifts match your preferences 90%+
            </p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <AlertCircle className="w-5 h-5 text-white" />
              <span className="text-xs bg-white/20 px-2 py-1 rounded">
                Urgent
              </span>
            </div>
            <h3 className="font-semibold mb-1">Urgent Opportunities</h3>
            <p className="text-blue-100 text-sm">
              {urgentShifts.length} urgent shifts with premium pay
            </p>
          </div>
        </div>
      </div>

      {/* Quick Categories */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <Star className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-2xl font-bold text-green-600">
              {recommendedShifts.length}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">
            Recommended for You
          </h3>
          <p className="text-gray-600 text-sm">
            AI-matched shifts based on your profile
          </p>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
            <span className="text-2xl font-bold text-red-600">
              {urgentShifts.length}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Urgent Shifts</h3>
          <p className="text-gray-600 text-sm">
            High-priority openings with premium pay
          </p>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Bookmark className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl font-bold text-blue-600">
              {bookmarkedShifts.length}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Saved Shifts</h3>
          <p className="text-gray-600 text-sm">Your bookmarked opportunities</p>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search by facility, department, or location..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent text-lg"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="bg-gray-100 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-200 transition-colors flex items-center font-medium"
            >
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              Filters
            </button>
            <select className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent">
              <option>Sort by Match Score</option>
              <option>Sort by Distance</option>
              <option>Sort by Pay Rate</option>
              <option>Sort by Date</option>
            </select>
          </div>
        </div>

        {/* Expandable Filters */}
        {showFilters && (
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Location
                </label>
                <input
                  type="text"
                  placeholder="City or ZIP code"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Department
                </label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent">
                  <option value="">All Departments</option>
                  <option value="icu">ICU</option>
                  <option value="emergency">Emergency</option>
                  <option value="med-surg">Medical-Surgical</option>
                  <option value="or">Operating Room</option>
                  <option value="nicu">NICU</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Hourly Rate
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Min"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent"
                  />
                  <input
                    type="number"
                    placeholder="Max"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Shift Type
                </label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent">
                  <option value="">All Types</option>
                  <option value="day">Day Shift</option>
                  <option value="night">Night Shift</option>
                  <option value="weekend">Weekend</option>
                  <option value="holiday">Holiday</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Shifts Display */}
      {viewMode === "cards" ? (
        <div className="grid gap-6">
          {filteredShifts.map((shift) => (
            <div
              key={shift.id}
              className={`bg-white rounded-lg shadow-sm border hover:shadow-md transition-all cursor-pointer ${
                shift.urgency === "urgent"
                  ? "border-red-200 bg-red-50/30"
                  : shift.urgency === "high"
                    ? "border-orange-200 bg-orange-50/30"
                    : "border-gray-200"
              }`}
            >
              <div className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
                  <div className="flex items-start space-x-4 mb-4 lg:mb-0 flex-1">
                    <img
                      src={shift.facilityLogo}
                      alt={shift.facilityName}
                      className="w-16 h-16 rounded-xl object-cover"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-xl font-semibold text-gray-900">
                          {shift.title}
                        </h3>
                        {getUrgencyBadge(shift.urgency)}
                        <div
                          className={`px-3 py-1 rounded-full text-sm font-medium ${getMatchScoreColor(shift.matchScore)}`}
                        >
                          {shift.matchScore}% match
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 mb-3">
                        <h4 className="text-lg font-medium text-gray-800">
                          {shift.facilityName}
                        </h4>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-500 mr-1" />
                          <span className="text-sm text-gray-600">
                            {shift.facilityRating}
                          </span>
                        </div>
                        <span className="text-sm text-gray-500">•</span>
                        <span className="text-sm text-gray-600">
                          {shift.facilityType}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-sm text-gray-600 mb-4">
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-2" />
                          {shift.location} ({shift.distance})
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2" />
                          {shift.shiftDate}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-2" />
                          {shift.shiftTime}
                        </div>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-2" />
                          {shift.applicants} applicants
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {shift.requirements.slice(0, 3).map((req, index) => (
                          <span
                            key={index}
                            className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium"
                          >
                            {req}
                          </span>
                        ))}
                        {shift.requirements.length > 3 && (
                          <span className="text-xs text-gray-500">
                            +{shift.requirements.length - 3} more
                          </span>
                        )}
                      </div>

                      <p className="text-gray-700 text-sm line-clamp-2 mb-4">
                        {shift.description}
                      </p>

                      {shift.bonuses && (
                        <div className="flex flex-wrap gap-2 mb-4">
                          {shift.bonuses.map((bonus, index) => (
                            <span
                              key={index}
                              className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium flex items-center"
                            >
                              <Award className="w-3 h-3 mr-1" />
                              {bonus}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="lg:ml-6 lg:text-right">
                    <div className="mb-4">
                      <div className="text-3xl font-bold text-gray-900">
                        ${shift.hourlyRate}
                      </div>
                      <div className="text-sm text-gray-600">per hour</div>
                      <div className="text-lg font-semibold text-green-600">
                        ${shift.totalPay} total
                      </div>
                    </div>

                    <div className="flex lg:flex-col gap-2">
                      <button
                        onClick={() => toggleBookmark(shift.id)}
                        className={`p-2 rounded-lg border transition-colors ${
                          shift.isBookmarked
                            ? "bg-blue-50 border-blue-200 text-blue-600"
                            : "bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100"
                        }`}
                      >
                        {shift.isBookmarked ? (
                          <BookmarkCheck className="w-5 h-5" />
                        ) : (
                          <Bookmark className="w-5 h-5" />
                        )}
                      </button>

                      <button
                        onClick={() => navigate(`/dashboard/shift/${shift.id}`)}
                        className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View Details
                      </button>

                      {shift.hasApplied ? (
                        <div className="bg-green-100 text-green-800 px-4 py-2 rounded-lg flex items-center">
                          <CheckCircle2 className="w-4 h-4 mr-1" />
                          Applied
                        </div>
                      ) : (
                        <button
                          onClick={() => applyToShift(shift.id)}
                          className="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center"
                        >
                          Apply Now
                          <ArrowRight className="w-4 h-4 ml-1" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Shift Details
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date & Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Pay & Match
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredShifts.map((shift) => (
                  <tr
                    key={shift.id}
                    className="hover:bg-gray-50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <img
                          src={shift.facilityLogo}
                          alt={shift.facilityName}
                          className="w-10 h-10 rounded-lg object-cover mr-3"
                        />
                        <div>
                          <div className="font-medium text-gray-900">
                            {shift.title}
                          </div>
                          <div className="text-sm text-gray-600">
                            {shift.facilityName}
                          </div>
                          <div className="text-xs text-gray-500 flex items-center mt-1">
                            <MapPin className="w-3 h-3 mr-1" />
                            {shift.distance}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="text-sm">
                        <div className="font-medium text-gray-900">
                          {shift.shiftDate}
                        </div>
                        <div className="text-gray-600">{shift.shiftTime}</div>
                        <div className="text-gray-500">{shift.duration}</div>
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="text-sm">
                        <div className="font-medium text-gray-900">
                          ${shift.hourlyRate}/hr
                        </div>
                        <div className="text-green-600">
                          ${shift.totalPay} total
                        </div>
                        <div
                          className={`text-xs mt-1 px-2 py-1 rounded-full inline-block ${getMatchScoreColor(shift.matchScore)}`}
                        >
                          {shift.matchScore}% match
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="space-y-1">
                        {getUrgencyBadge(shift.urgency)}
                        {shift.hasApplied && (
                          <div className="text-green-600 text-xs flex items-center">
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            Applied
                          </div>
                        )}
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => toggleBookmark(shift.id)}
                          className={`p-1 rounded transition-colors ${
                            shift.isBookmarked
                              ? "text-blue-600"
                              : "text-gray-400 hover:text-blue-600"
                          }`}
                        >
                          {shift.isBookmarked ? (
                            <BookmarkCheck className="w-4 h-4" />
                          ) : (
                            <Bookmark className="w-4 h-4" />
                          )}
                        </button>
                        <button
                          onClick={() => setSelectedShift(shift)}
                          className="text-gray-600 hover:text-medical-blue transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {!shift.hasApplied && (
                          <button
                            onClick={() => applyToShift(shift.id)}
                            className="bg-medical-blue text-white px-3 py-1 rounded text-xs hover:bg-blue-700 transition-colors"
                          >
                            Apply
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {filteredShifts.length === 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <Briefcase className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No shifts found
          </h3>
          <p className="text-gray-600 mb-6">
            Try adjusting your search criteria or filters to see more results.
          </p>
          <button className="bg-medical-blue text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Reset Filters
          </button>
        </div>
      )}

      {/* Shift Detail Modal */}
      {selectedShift && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-header font-bold text-gray-900">
                {selectedShift.title}
              </h2>
              <button
                onClick={() => setSelectedShift(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6">
              <div className="grid md:grid-cols-3 gap-8">
                <div className="md:col-span-2">
                  <div className="flex items-center space-x-4 mb-6">
                    <img
                      src={selectedShift.facilityLogo}
                      alt={selectedShift.facilityName}
                      className="w-16 h-16 rounded-xl object-cover"
                    />
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">
                        {selectedShift.facilityName}
                      </h3>
                      <div className="flex items-center space-x-2">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span className="text-gray-600">
                          {selectedShift.facilityRating}
                        </span>
                        <span className="text-gray-400">•</span>
                        <span className="text-gray-600">
                          {selectedShift.facilityType}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-3">
                        Shift Details
                      </h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Department:</span>
                          <div className="font-medium">
                            {selectedShift.department}
                          </div>
                        </div>
                        <div>
                          <span className="text-gray-600">
                            Experience Level:
                          </span>
                          <div className="font-medium capitalize">
                            {selectedShift.experienceLevel}
                          </div>
                        </div>
                        <div>
                          <span className="text-gray-600">Location:</span>
                          <div className="font-medium">
                            {selectedShift.location}
                          </div>
                        </div>
                        <div>
                          <span className="text-gray-600">Distance:</span>
                          <div className="font-medium">
                            {selectedShift.distance}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-3">
                        Description
                      </h4>
                      <p className="text-gray-700">
                        {selectedShift.description}
                      </p>
                    </div>

                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-3">
                        Requirements
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedShift.requirements.map((req, index) => (
                          <span
                            key={index}
                            className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium"
                          >
                            {req}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-3">
                        Benefits
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedShift.benefits.map((benefit, index) => (
                          <span
                            key={index}
                            className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium"
                          >
                            {benefit}
                          </span>
                        ))}
                      </div>
                    </div>

                    {selectedShift.bonuses && (
                      <div>
                        <h4 className="text-lg font-semibold text-gray-900 mb-3">
                          Special Bonuses
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {selectedShift.bonuses.map((bonus, index) => (
                            <span
                              key={index}
                              className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium flex items-center"
                            >
                              <Award className="w-4 h-4 mr-1" />
                              {bonus}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <div className="bg-gray-50 rounded-xl p-6 sticky top-6">
                    <div className="text-center mb-6">
                      <div className="text-4xl font-bold text-gray-900 mb-1">
                        ${selectedShift.hourlyRate}
                      </div>
                      <div className="text-gray-600 mb-2">per hour</div>
                      <div className="text-2xl font-semibold text-green-600">
                        ${selectedShift.totalPay}
                      </div>
                      <div className="text-gray-600">total pay</div>
                    </div>

                    <div className="space-y-4 mb-6 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Date:</span>
                        <span className="font-medium">
                          {selectedShift.shiftDate}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Time:</span>
                        <span className="font-medium">
                          {selectedShift.shiftTime}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Duration:</span>
                        <span className="font-medium">
                          {selectedShift.duration}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Match Score:</span>
                        <div
                          className={`px-2 py-1 rounded-full text-xs font-medium ${getMatchScoreColor(selectedShift.matchScore)}`}
                        >
                          {selectedShift.matchScore}%
                        </div>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Applicants:</span>
                        <span className="font-medium">
                          {selectedShift.applicants}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {selectedShift.hasApplied ? (
                        <div className="bg-green-100 text-green-800 py-3 px-4 rounded-lg text-center font-medium flex items-center justify-center">
                          <CheckCircle2 className="w-5 h-5 mr-2" />
                          Application Submitted
                        </div>
                      ) : (
                        <button
                          onClick={() => applyToShift(selectedShift.id)}
                          className="w-full bg-medical-blue text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center"
                        >
                          Apply for This Shift
                          <ArrowRight className="w-5 h-5 ml-2" />
                        </button>
                      )}

                      <button
                        onClick={() => toggleBookmark(selectedShift.id)}
                        className={`w-full py-3 px-4 rounded-lg transition-colors font-medium flex items-center justify-center ${
                          selectedShift.isBookmarked
                            ? "bg-blue-100 text-blue-800 border border-blue-200"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                        }`}
                      >
                        {selectedShift.isBookmarked ? (
                          <>
                            <BookmarkCheck className="w-5 h-5 mr-2" />
                            Saved
                          </>
                        ) : (
                          <>
                            <Bookmark className="w-5 h-5 mr-2" />
                            Save Shift
                          </>
                        )}
                      </button>

                      <button className="w-full bg-gray-100 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-200 transition-colors font-medium flex items-center justify-center">
                        <Share2 className="w-5 h-5 mr-2" />
                        Share
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
