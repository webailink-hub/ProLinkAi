import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import {
  ArrowLeft,
  Star,
  MapPin,
  Award,
  Mail,
  Phone,
  Building2,
  CheckCircle,
  MessageSquare,
  MoreHorizontal,
  Download,
  Eye,
  Globe,
  Bed,
  Users,
  DollarSign,
  Target,
  ShieldCheck,
} from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";

// Mock facility data - in real app this would come from API based on facilityId
const generateMockFacilityData = (facilityId: string) => ({
  id: facilityId,
  name: "San Francisco General Hospital",
  type: "Level 1 Trauma Center",
  email: "staffing@sfgeneral.org",
  phone: "(415) 206-8000",
  website: "https://sfgeneral.ucsf.edu",
  logo: null,
  status: "active",
  verificationStatus: "verified",
  joinDate: "2023-03-10",
  address: {
    street: "1001 Potrero Avenue",
    city: "San Francisco",
    state: "CA",
    zipCode: "94110",
  },
  description:
    "San Francisco's premier Level 1 Trauma Center providing comprehensive emergency and specialty care. We pride ourselves on excellence in patient care and maintaining the highest standards for our healthcare professionals.",
  departments: [
    "Emergency Department",
    "Intensive Care Unit",
    "Medical/Surgical",
    "Pediatrics",
    "Maternity",
    "Operating Room",
    "Oncology",
    "Cardiac Care",
  ],
  credentials: [
    {
      type: "Joint Commission Accreditation",
      expiry: "2025-06-30",
      status: "active",
    },
    { type: "Magnet Recognition", expiry: "2026-12-31", status: "active" },
    { type: "Level 1 Trauma Center", expiry: "2024-08-15", status: "active" },
    {
      type: "Medicare/Medicaid Certified",
      expiry: "2025-03-20",
      status: "active",
    },
  ],
  stats: {
    totalBeds: 284,
    totalShiftsPosted: 156,
    averageFillRate: 94.2,
    averageRating: 4.7,
    activeNurses: 34,
    totalHours: 2840,
    monthlySpend: 45200,
    shiftsThisMonth: 28,
    responseTime: "< 3 hours",
    repeatBookingRate: 87.5,
  },
  recentShifts: [
    {
      id: 1,
      department: "ICU",
      date: "2024-01-20",
      duration: "12 hours",
      pay: 680,
      nurseAssigned: "Sarah Johnson",
      status: "completed",
      rating: 5,
    },
    {
      id: 2,
      department: "Emergency",
      date: "2024-01-18",
      duration: "8 hours",
      pay: 520,
      nurseAssigned: "Marcus Williams",
      status: "completed",
      rating: 4,
    },
  ],
});

export default function FacilityProfileDynamic() {
  const { facilityId } = useParams();
  const [facilityData, setFacilityData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      if (facilityId) {
        setFacilityData(generateMockFacilityData(facilityId));
      }
      setLoading(false);
    }, 1000);
  }, [facilityId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-medical-blue"></div>
      </div>
    );
  }

  if (!facilityData) {
    return (
      <div className="p-6 text-center">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Building2 className="w-8 h-8 text-gray-400" />
        </div>
        <h2 className="text-xl font-semibold text-gray-900 mb-2">
          Facility Not Found
        </h2>
        <p className="text-gray-600 mb-4">
          The facility profile you're looking for doesn't exist.
        </p>
        <Link to="/dashboard">
          <Button variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "verified":
        return "bg-blue-100 text-blue-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "in-progress":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Link to="/dashboard">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Facility Profile</h1>
          <p className="text-gray-600">
            Comprehensive facility information and performance analytics
          </p>
        </div>
      </div>

      {/* Profile Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-6">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 bg-gradient-to-br from-medical-blue to-ai-purple rounded-full flex items-center justify-center text-white text-xl font-bold">
                {facilityData.name
                  .split(" ")
                  .map((word) => word[0])
                  .join("")
                  .substring(0, 2)}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  {facilityData.name}
                </h2>
                <p className="text-lg text-gray-600 mb-2">
                  {facilityData.type}
                </p>
                <div className="flex items-center gap-2 mb-2">
                  <Badge className={getStatusColor(facilityData.status)}>
                    {facilityData.status}
                  </Badge>
                  <Badge
                    className={getStatusColor(facilityData.verificationStatus)}
                  >
                    <ShieldCheck className="w-3 h-3 mr-1" />
                    {facilityData.verificationStatus}
                  </Badge>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium">
                      {facilityData.stats.averageRating}/5
                    </span>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <Mail className="w-4 h-4" />
                    {facilityData.email}
                  </span>
                  <span className="flex items-center gap-1">
                    <Phone className="w-4 h-4" />
                    {facilityData.phone}
                  </span>
                  <span className="flex items-center gap-1">
                    <Globe className="w-4 h-4" />
                    <a
                      href={facilityData.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-medical-blue hover:underline"
                    >
                      Website
                    </a>
                  </span>
                </div>
              </div>
            </div>

            <div className="md:ml-auto flex flex-col md:flex-row gap-2">
              <Button variant="outline" size="sm">
                <MessageSquare className="w-4 h-4 mr-2" />
                Contact
              </Button>
              <Button variant="outline" size="sm">
                <Eye className="w-4 h-4 mr-2" />
                View Public
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Fill Rate</p>
                <p className="text-2xl font-bold text-gray-900">
                  {facilityData.stats.averageFillRate}%
                </p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <Target className="w-5 h-5 text-green-600" />
              </div>
            </div>
            <div className="mt-2">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-600 h-2 rounded-full"
                  style={{ width: `${facilityData.stats.averageFillRate}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Nurses</p>
                <p className="text-2xl font-bold text-gray-900">
                  {facilityData.stats.activeNurses}
                </p>
              </div>
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-2">Working with you</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Beds</p>
                <p className="text-2xl font-bold text-gray-900">
                  {facilityData.stats.totalBeds}
                </p>
              </div>
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <Bed className="w-5 h-5 text-purple-600" />
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-2">Capacity</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Monthly Spend</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${(facilityData.stats.monthlySpend / 1000).toFixed(0)}K
                </p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-2">This month</p>
          </CardContent>
        </Card>
      </div>

      {/* About Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">About</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-4">{facilityData.description}</p>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-gray-400" />
                <span>
                  {facilityData.address.street}, {facilityData.address.city},{" "}
                  {facilityData.address.state} {facilityData.address.zipCode}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Stats</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Response Time</span>
              <span className="font-medium">
                {facilityData.stats.responseTime}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Repeat Booking Rate</span>
              <span className="font-medium">
                {facilityData.stats.repeatBookingRate}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Total Shifts Posted</span>
              <span className="font-medium">
                {facilityData.stats.totalShiftsPosted}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Average Rating</span>
              <div className="flex items-center gap-1">
                <span className="font-medium">
                  {facilityData.stats.averageRating}/5
                </span>
                <Star className="w-3 h-3 text-yellow-400 fill-current" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Departments */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Departments & Specialties</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {facilityData.departments.map((department, index) => (
              <div
                key={index}
                className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg"
              >
                <div className="w-8 h-8 bg-medical-blue/10 rounded-full flex items-center justify-center">
                  <Building2 className="w-4 h-4 text-medical-blue" />
                </div>
                <span className="font-medium text-gray-900">{department}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Credentials */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">
            Certifications & Accreditations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {facilityData.credentials.map((credential, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Award className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {credential.type}
                    </h4>
                    <p className="text-xs text-gray-500">
                      Expires:{" "}
                      {new Date(credential.expiry).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <Badge
                  className={
                    credential.status === "active"
                      ? "bg-green-100 text-green-800"
                      : "bg-yellow-100 text-yellow-800"
                  }
                >
                  {credential.status}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Shifts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Shifts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {facilityData.recentShifts.map((shift) => (
              <div
                key={shift.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {shift.department}
                    </h4>
                    <p className="text-sm text-gray-600">
                      Assigned to: {shift.nurseAssigned}
                    </p>
                    <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
                      <span>{new Date(shift.date).toLocaleDateString()}</span>
                      <span>{shift.duration}</span>
                      <span className="text-green-600 font-medium">
                        ${shift.pay}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  {shift.rating && (
                    <div className="flex items-center gap-1 mb-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${i < shift.rating ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                  )}
                  <Badge className={getStatusColor(shift.status)}>
                    {shift.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
