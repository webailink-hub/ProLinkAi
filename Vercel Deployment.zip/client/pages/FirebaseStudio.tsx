import React, { useState, useEffect } from "react";
import {
  Database,
  Users,
  Activity,
  Settings,
  FileText,
  Palette,
  Code,
  Play,
  Square,
  RefreshCw,
  Terminal,
  Monitor,
} from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import { Badge } from "../components/ui/badge";
import { VisualEditor } from "../components/VisualEditor/VisualEditor";
import { ContentManager } from "../components/ContentManager/ContentManager";
import { FirebaseProvider } from "../contexts/FirebaseContext";

export default function FirebaseStudio() {
  const [emulatorStatus, setEmulatorStatus] = useState<
    "stopped" | "starting" | "running" | "error"
  >("stopped");
  const [activeProject, setActiveProject] = useState<string>("demo-project");
  const [activeTab, setActiveTab] = useState("overview");

  const emulatorServices = [
    { name: "Firestore", port: 8080, status: "running" },
    { name: "Authentication", port: 9099, status: "running" },
    { name: "Storage", port: 9199, status: "running" },
    { name: "Functions", port: 5001, status: "stopped" },
    { name: "Hosting", port: 5000, status: "stopped" },
    { name: "Database", port: 9000, status: "stopped" },
  ];

  const projectStats = {
    totalUsers: 23,
    activeCollaborators: 5,
    documentsCount: 156,
    storageUsed: "2.3 GB",
    functionsDeployed: 8,
    lastActivity: "2 minutes ago",
  };

  const startEmulators = async () => {
    setEmulatorStatus("starting");
    // Simulate starting emulators
    setTimeout(() => {
      setEmulatorStatus("running");
    }, 3000);
  };

  const stopEmulators = () => {
    setEmulatorStatus("stopped");
  };

  return (
    <FirebaseProvider>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Database className="w-8 h-8 text-orange-500" />
                  <h1 className="text-2xl font-bold text-gray-900">
                    Firebase Studio
                  </h1>
                </div>
                <Badge
                  variant="secondary"
                  className="bg-orange-100 text-orange-800"
                >
                  Local Development
                </Badge>
              </div>

              <div className="flex items-center space-x-4">
                <select
                  value={activeProject}
                  onChange={(e) => setActiveProject(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-md text-sm"
                >
                  <option value="demo-project">ProLinkAi Demo</option>
                  <option value="healthcare-app">Healthcare App</option>
                  <option value="component-lib">Component Library</option>
                </select>

                {emulatorStatus === "running" ? (
                  <Button
                    onClick={stopEmulators}
                    variant="outline"
                    className="text-red-600 border-red-600 hover:bg-red-50"
                  >
                    <Square className="w-4 h-4 mr-2" />
                    Stop Emulators
                  </Button>
                ) : (
                  <Button
                    onClick={startEmulators}
                    disabled={emulatorStatus === "starting"}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    {emulatorStatus === "starting" ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Play className="w-4 h-4 mr-2" />
                    )}
                    {emulatorStatus === "starting"
                      ? "Starting..."
                      : "Start Emulators"}
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="px-6 py-6">
          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            className="space-y-6"
          >
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Monitor className="w-4 h-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger
                value="visual-editor"
                className="flex items-center gap-2"
              >
                <Palette className="w-4 h-4" />
                Visual Editor
              </TabsTrigger>
              <TabsTrigger value="content" className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Content
              </TabsTrigger>
              <TabsTrigger value="database" className="flex items-center gap-2">
                <Database className="w-4 h-4" />
                Database
              </TabsTrigger>
              <TabsTrigger
                value="collaboration"
                className="flex items-center gap-2"
              >
                <Users className="w-4 h-4" />
                Collaboration
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Settings
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* Emulator Status */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Terminal className="w-5 h-5" />
                    Emulator Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    {emulatorServices.map((service) => (
                      <div
                        key={service.name}
                        className="p-3 border border-gray-200 rounded-lg"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-sm font-medium text-gray-900">
                            {service.name}
                          </h4>
                          <div
                            className={`w-2 h-2 rounded-full ${
                              service.status === "running"
                                ? "bg-green-400"
                                : "bg-gray-400"
                            }`}
                          />
                        </div>
                        <p className="text-xs text-gray-500">
                          Port: {service.port}
                        </p>
                        <Badge
                          variant={
                            service.status === "running"
                              ? "default"
                              : "secondary"
                          }
                          className="text-xs mt-1"
                        >
                          {service.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Project Stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Active Users</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-2xl font-bold text-gray-900">
                          {projectStats.totalUsers}
                        </p>
                        <p className="text-sm text-gray-500">
                          Total registered
                        </p>
                      </div>
                      <Users className="w-8 h-8 text-blue-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Documents</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-2xl font-bold text-gray-900">
                          {projectStats.documentsCount}
                        </p>
                        <p className="text-sm text-gray-500">In Firestore</p>
                      </div>
                      <Database className="w-8 h-8 text-green-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Storage</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-2xl font-bold text-gray-900">
                          {projectStats.storageUsed}
                        </p>
                        <p className="text-sm text-gray-500">Files & assets</p>
                      </div>
                      <FileText className="w-8 h-8 text-purple-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    Recent Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-green-400 rounded-full" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          New user registered
                        </p>
                        <p className="text-xs text-gray-500">2 minutes ago</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-blue-400 rounded-full" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          Document updated in collaboration
                        </p>
                        <p className="text-xs text-gray-500">5 minutes ago</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-purple-400 rounded-full" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          New content published
                        </p>
                        <p className="text-xs text-gray-500">12 minutes ago</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col gap-2"
                      onClick={() => setActiveTab("visual-editor")}
                    >
                      <Palette className="w-6 h-6" />
                      <span className="text-sm">Visual Editor</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col gap-2"
                      onClick={() => setActiveTab("content")}
                    >
                      <FileText className="w-6 h-6" />
                      <span className="text-sm">Manage Content</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col gap-2"
                      onClick={() => setActiveTab("database")}
                    >
                      <Database className="w-6 h-6" />
                      <span className="text-sm">View Database</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col gap-2"
                      onClick={() => setActiveTab("collaboration")}
                    >
                      <Users className="w-6 h-6" />
                      <span className="text-sm">Collaboration</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="visual-editor">
              <VisualEditor
                projectId={activeProject}
                documentId="main-document"
              />
            </TabsContent>

            <TabsContent value="content">
              <ContentManager projectId={activeProject} />
            </TabsContent>

            <TabsContent value="database">
              <Card>
                <CardHeader>
                  <CardTitle>Firestore Database</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <h3 className="font-medium text-blue-900 mb-2">
                        Emulator UI
                      </h3>
                      <p className="text-sm text-blue-700 mb-3">
                        Access the full Firebase Emulator UI for detailed
                        database management, authentication testing, and more.
                      </p>
                      <Button
                        variant="outline"
                        onClick={() =>
                          window.open("http://localhost:4000", "_blank")
                        }
                        className="border-blue-300 text-blue-700 hover:bg-blue-100"
                      >
                        Open Emulator UI
                      </Button>
                    </div>

                    <div className="text-center py-8">
                      <Database className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        Database Management
                      </h3>
                      <p className="text-gray-500">
                        Use the Firebase Emulator UI to manage your Firestore
                        collections, documents, and authentication users.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="collaboration">
              <Card>
                <CardHeader>
                  <CardTitle>Real-time Collaboration</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="font-medium text-gray-900 mb-3">
                          Active Collaborators
                        </h3>
                        <div className="space-y-2">
                          {Array.from({ length: 3 }).map((_, i) => (
                            <div
                              key={i}
                              className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg"
                            >
                              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                                {String.fromCharCode(65 + i)}
                              </div>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-gray-900">
                                  User {i + 1}
                                </p>
                                <p className="text-xs text-gray-500">
                                  Active in Visual Editor
                                </p>
                              </div>
                              <div className="w-2 h-2 bg-green-400 rounded-full" />
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="font-medium text-gray-900 mb-3">
                          Recent Changes
                        </h3>
                        <div className="space-y-2">
                          <div className="p-3 border border-gray-200 rounded-lg">
                            <p className="text-sm font-medium text-gray-900">
                              Component updated
                            </p>
                            <p className="text-xs text-gray-500">
                              by User 1 • 2 minutes ago
                            </p>
                          </div>
                          <div className="p-3 border border-gray-200 rounded-lg">
                            <p className="text-sm font-medium text-gray-900">
                              New page created
                            </p>
                            <p className="text-xs text-gray-500">
                              by User 2 • 5 minutes ago
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Project Settings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-medium text-gray-900 mb-3">
                        Emulator Configuration
                      </h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              Firestore Emulator
                            </p>
                            <p className="text-xs text-gray-500">
                              localhost:8080
                            </p>
                          </div>
                          <Badge variant="default">Enabled</Badge>
                        </div>
                        <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              Auth Emulator
                            </p>
                            <p className="text-xs text-gray-500">
                              localhost:9099
                            </p>
                          </div>
                          <Badge variant="default">Enabled</Badge>
                        </div>
                        <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              Storage Emulator
                            </p>
                            <p className="text-xs text-gray-500">
                              localhost:9199
                            </p>
                          </div>
                          <Badge variant="default">Enabled</Badge>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium text-gray-900 mb-3">
                        Export Data
                      </h3>
                      <div className="space-y-3">
                        <Button
                          variant="outline"
                          className="w-full justify-start"
                        >
                          <Database className="w-4 h-4 mr-2" />
                          Export Firestore Data
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-start"
                        >
                          <Users className="w-4 h-4 mr-2" />
                          Export Auth Users
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </FirebaseProvider>
  );
}
