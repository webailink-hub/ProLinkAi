import React, { useState } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Filter, Search, MapPin, Clock, DollarSign, Users, Brain, Grid, List } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';

interface CalendarShift {
  id: string;
  title: string;
  facility: string;
  department: string;
  startTime: string;
  endTime: string;
  hourlyRate: number;
  urgency: 'low' | 'normal' | 'high' | 'urgent';
  applications: number;
  aiMatch?: number;
}

interface CalendarDay {
  date: Date;
  isCurrentMonth: boolean;
  shifts: CalendarShift[];
}

export default function ShiftCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [viewMode, setViewMode] = useState<'month' | 'week'>('month');
  const [filterDepartment, setFilterDepartment] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Mock shift data
  const shiftsData: Record<string, CalendarShift[]> = {
    '2024-02-05': [
      {
        id: '1',
        title: 'ICU Night Shift',
        facility: 'SF General',
        department: 'ICU',
        startTime: '19:00',
        endTime: '07:00',
        hourlyRate: 52,
        urgency: 'high',
        applications: 15,
        aiMatch: 96
      }
    ],
    '2024-02-07': [
      {
        id: '2',
        title: 'ER Day Shift',
        facility: 'Stanford Medical',
        department: 'Emergency',
        startTime: '07:00',
        endTime: '19:00',
        hourlyRate: 48,
        urgency: 'urgent',
        applications: 23,
        aiMatch: 87
      },
      {
        id: '3',
        title: 'Med-Surg Evening',
        facility: 'UCSF Medical',
        department: 'Med-Surg',
        startTime: '15:00',
        endTime: '23:00',
        hourlyRate: 45,
        urgency: 'normal',
        applications: 12,
        aiMatch: 92
      }
    ],
    '2024-02-10': [
      {
        id: '4',
        title: 'PICU Night',
        facility: 'Children\'s Hospital',
        department: 'PICU',
        startTime: '19:00',
        endTime: '07:00',
        hourlyRate: 55,
        urgency: 'high',
        applications: 8,
        aiMatch: 78
      }
    ],
    '2024-02-12': [
      {
        id: '5',
        title: 'OR Morning',
        facility: 'SF General',
        department: 'OR',
        startTime: '06:00',
        endTime: '14:00',
        hourlyRate: 50,
        urgency: 'normal',
        applications: 18,
        aiMatch: 85
      }
    ],
    '2024-02-15': [
      {
        id: '6',
        title: 'ICU Day Shift',
        facility: 'Stanford Medical',
        department: 'ICU',
        startTime: '07:00',
        endTime: '19:00',
        hourlyRate: 49,
        urgency: 'normal',
        applications: 20,
        aiMatch: 94
      }
    ]
  };

  const departments = ['All Departments', 'ICU', 'Emergency', 'Med-Surg', 'OR', 'PICU', 'Labor & Delivery'];

  const generateCalendarDays = (): CalendarDay[] => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());
    
    const days: CalendarDay[] = [];
    const currentDay = new Date(startDate);
    
    for (let i = 0; i < 42; i++) {
      const dateKey = currentDay.toISOString().split('T')[0];
      const dayShifts = shiftsData[dateKey] || [];
      
      days.push({
        date: new Date(currentDay),
        isCurrentMonth: currentDay.getMonth() === month,
        shifts: dayShifts.filter(shift => {
          const matchesDepartment = filterDepartment === 'all' || shift.department === filterDepartment;
          const matchesSearch = searchTerm === '' || 
            shift.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            shift.facility.toLowerCase().includes(searchTerm.toLowerCase());
          return matchesDepartment && matchesSearch;
        })
      });
      
      currentDay.setDate(currentDay.getDate() + 1);
    }
    
    return days;
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    newDate.setMonth(currentDate.getMonth() + (direction === 'next' ? 1 : -1));
    setCurrentDate(newDate);
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'urgent': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'normal': return 'bg-blue-500';
      case 'low': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getDepartmentColor = (department: string) => {
    switch (department) {
      case 'ICU': return 'bg-medical-blue';
      case 'Emergency': return 'bg-red-600';
      case 'Med-Surg': return 'bg-medical-teal';
      case 'OR': return 'bg-ai-purple';
      case 'PICU': return 'bg-medical-green';
      default: return 'bg-gray-600';
    }
  };

  const calendarDays = generateCalendarDays();
  const monthYear = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  const selectedDateShifts = selectedDate 
    ? shiftsData[selectedDate.toISOString().split('T')[0]] || []
    : [];

  const totalShifts = Object.values(shiftsData).flat().length;
  const avgHourlyRate = Object.values(shiftsData).flat().reduce((sum, shift) => sum + shift.hourlyRate, 0) / totalShifts;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent">
            Shift Calendar
          </h1>
          <p className="text-gray-600 mt-2">
            Visual calendar view of available shifts with AI-powered recommendations
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant={viewMode === 'month' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('month')}
          >
            <Grid className="w-4 h-4 mr-1" />
            Month
          </Button>
          <Button
            variant={viewMode === 'week' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('week')}
          >
            <List className="w-4 h-4 mr-1" />
            Week
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-medical-blue">{totalShifts}</div>
            <div className="text-sm text-gray-600">Available Shifts</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">${avgHourlyRate.toFixed(0)}</div>
            <div className="text-sm text-gray-600">Avg Hourly Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-ai-purple">94%</div>
            <div className="text-sm text-gray-600">AI Match Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">12</div>
            <div className="text-sm text-gray-600">Urgent Shifts</div>
          </CardContent>
        </Card>
      </div>

      {/* AI Insights */}
      <Card className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 border-ai-purple/20">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-5 h-5 text-ai-purple" />
            <h3 className="font-semibold text-ai-purple">AI Calendar Insights</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-green-600">Best Opportunities</div>
              <p className="text-gray-600">3 high-match shifts this week with 90%+ compatibility</p>
            </div>
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-blue-600">Peak Demand</div>
              <p className="text-gray-600">Weekend shifts show 40% higher demand and rates</p>
            </div>
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-orange-600">Urgent Needs</div>
              <p className="text-gray-600">5 urgent shifts need immediate coverage</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search shifts or facilities..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={filterDepartment}
              onChange={(e) => setFilterDepartment(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
            >
              {departments.map((dept, index) => (
                <option key={index} value={index === 0 ? 'all' : dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Calendar */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <CalendarIcon className="w-5 h-5" />
                  {monthYear}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => navigateMonth('prev')}>
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setCurrentDate(new Date())}>
                    Today
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => navigateMonth('next')}>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-1">
                {/* Day headers */}
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="p-2 text-center text-sm font-medium text-gray-500">
                    {day}
                  </div>
                ))}
                
                {/* Calendar days */}
                {calendarDays.map((day, index) => (
                  <div
                    key={index}
                    className={`min-h-[120px] p-1 border border-gray-200 cursor-pointer hover:bg-gray-50 transition-colors ${
                      !day.isCurrentMonth ? 'bg-gray-50' : ''
                    } ${
                      selectedDate?.toDateString() === day.date.toDateString() 
                        ? 'ring-2 ring-medical-blue bg-medical-blue/5' 
                        : ''
                    }`}
                    onClick={() => setSelectedDate(day.date)}
                  >
                    <div className={`text-sm font-medium mb-1 ${
                      day.isCurrentMonth ? 'text-gray-900' : 'text-gray-400'
                    } ${
                      day.date.toDateString() === new Date().toDateString() 
                        ? 'text-medical-blue font-bold' 
                        : ''
                    }`}>
                      {day.date.getDate()}
                    </div>
                    
                    {/* Shifts for this day */}
                    <div className="space-y-1">
                      {day.shifts.slice(0, 3).map((shift, shiftIndex) => (
                        <div
                          key={shiftIndex}
                          className="text-xs p-1 rounded text-white truncate cursor-pointer hover:opacity-80"
                          style={{ backgroundColor: getDepartmentColor(shift.department) }}
                          title={`${shift.title} at ${shift.facility} - $${shift.hourlyRate}/hr`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="truncate">{shift.title}</span>
                            {shift.aiMatch && shift.aiMatch > 90 && (
                              <Brain className="w-3 h-3 flex-shrink-0" />
                            )}
                          </div>
                          <div className="opacity-80">{shift.startTime}</div>
                        </div>
                      ))}
                      
                      {day.shifts.length > 3 && (
                        <div className="text-xs text-gray-500 text-center">
                          +{day.shifts.length - 3} more
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Selected Day Details */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>
                {selectedDate 
                  ? selectedDate.toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      month: 'long', 
                      day: 'numeric' 
                    })
                  : 'Select a Date'
                }
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedDate ? (
                <div className="space-y-4">
                  {selectedDateShifts.length > 0 ? (
                    selectedDateShifts.map((shift) => (
                      <div key={shift.id} className="p-3 border rounded-lg hover:shadow-sm transition-shadow">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-semibold text-sm">{shift.title}</h4>
                          <div className={`w-2 h-2 rounded-full ${getUrgencyColor(shift.urgency)}`} />
                        </div>
                        
                        <p className="text-xs text-gray-600 mb-2">{shift.facility}</p>
                        
                        <div className="space-y-1 text-xs text-gray-500">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{shift.startTime} - {shift.endTime}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <DollarSign className="w-3 h-3" />
                            <span>${shift.hourlyRate}/hour</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            <span>{shift.applications} applications</span>
                          </div>
                          {shift.aiMatch && (
                            <div className="flex items-center gap-1">
                              <Brain className="w-3 h-3 text-ai-purple" />
                              <span className="text-ai-purple">{shift.aiMatch}% match</span>
                            </div>
                          )}
                        </div>
                        
                        <Button size="sm" className="w-full mt-2 text-xs h-7">
                          View Details
                        </Button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-gray-500 py-8">
                      <CalendarIcon className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-sm">No shifts available</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center text-gray-500 py-8">
                  <CalendarIcon className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm">Click on a date to view available shifts</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Legend */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Department Legend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {['ICU', 'Emergency', 'Med-Surg', 'OR', 'PICU'].map((dept) => (
                  <div key={dept} className="flex items-center gap-2 text-xs">
                    <div className={`w-3 h-3 rounded ${getDepartmentColor(dept)}`} />
                    <span>{dept}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Urgency Legend */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Urgency Levels</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {[
                  { level: 'urgent', label: 'Urgent' },
                  { level: 'high', label: 'High' },
                  { level: 'normal', label: 'Normal' },
                  { level: 'low', label: 'Low' }
                ].map((item) => (
                  <div key={item.level} className="flex items-center gap-2 text-xs">
                    <div className={`w-2 h-2 rounded-full ${getUrgencyColor(item.level)}`} />
                    <span>{item.label}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
