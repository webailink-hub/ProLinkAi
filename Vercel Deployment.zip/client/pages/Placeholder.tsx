import { ArrowLeft, Construction, Brain } from "lucide-react";
import { Link } from "react-router-dom";

interface PlaceholderPageProps {
  title: string;
  description: string;
  returnTo?: string;
  returnLabel?: string;
}

export default function PlaceholderPage({
  title,
  description,
  returnTo = "/",
  returnLabel = "Back to Home",
}: PlaceholderPageProps) {
  return (
    <div className="min-h-screen bg-medical-gray">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            {/* Navigation Links */}
            <div className="hidden md:flex items-center space-x-8">
              <Link
                to="/"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Home
              </Link>
              <Link
                to="/about"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                About
              </Link>
              <Link
                to="/login"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-6 py-2 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium shadow-card hover:shadow-card-hover"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Placeholder Content */}
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] px-4 py-8">
        <div className="text-center max-w-lg w-full">
          <div className="w-16 sm:w-20 h-16 sm:h-20 bg-orange-100 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6">
            <Construction className="w-8 sm:w-10 h-8 sm:h-10 text-orange-500" />
          </div>

          <h1 className="text-2xl sm:text-3xl font-header font-bold text-gray-900 mb-3 sm:mb-4 px-4">
            {title}
          </h1>

          <p className="text-gray-600 font-body text-base sm:text-lg leading-relaxed mb-6 sm:mb-8 px-4">
            {description}
          </p>

          <div className="space-y-3 sm:space-y-4 px-4">
            <p className="text-sm text-gray-500 font-body">
              This page is coming soon! Continue prompting to have us build out
              this section.
            </p>

            <Link
              to={returnTo}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-medical-blue to-ai-purple text-white px-5 sm:px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 touch-manipulation"
            >
              <ArrowLeft className="w-4 h-4" />
              {returnLabel}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
