import React, { useState } from 'react';
import { Calendar, Clock, DollarSign, MapPin, Users, Stethoscope, Star, Brain, AlertCircle, CheckCircle, Plus, X, Save, Send } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Switch } from '../components/ui/switch';

interface ShiftRequirement {
  id: string;
  name: string;
  required: boolean;
}

interface AIRecommendation {
  type: 'rate' | 'requirements' | 'timing' | 'description';
  suggestion: string;
  confidence: number;
}

export default function PostShift() {
  const [step, setStep] = useState(1);
  const [shiftData, setShiftData] = useState({
    title: '',
    department: '',
    date: '',
    startTime: '',
    endTime: '',
    hourlyRate: '',
    urgency: 'normal' as 'low' | 'normal' | 'high' | 'urgent',
    description: '',
    requirements: [] as string[],
    location: '',
    contactPerson: '',
    contactPhone: '',
    contactEmail: '',
    specialInstructions: '',
    autoApprove: false,
    aiOptimized: true
  });

  const [requirements, setRequirements] = useState<ShiftRequirement[]>([
    { id: '1', name: 'BLS Certification', required: true },
    { id: '2', name: 'RN License', required: true },
    { id: '3', name: 'ICU Experience', required: false },
    { id: '4', name: 'ACLS Certification', required: false },
    { id: '5', name: 'Previous Hospital Experience', required: false },
    { id: '6', name: 'COVID Vaccination', required: true }
  ]);

  const [customRequirement, setCustomRequirement] = useState('');
  const [aiRecommendations, setAiRecommendations] = useState<AIRecommendation[]>([
    {
      type: 'rate',
      suggestion: 'Recommended rate: $45-52/hour based on current market data for ICU shifts',
      confidence: 87
    },
    {
      type: 'timing',
      suggestion: 'Post 48-72 hours in advance for 23% higher application rate',
      confidence: 92
    },
    {
      type: 'requirements',
      suggestion: 'Consider making ACLS optional to increase candidate pool by 34%',
      confidence: 78
    }
  ]);

  const departments = [
    'ICU', 'Emergency', 'Medical-Surgical', 'Pediatrics', 'Labor & Delivery',
    'Operating Room', 'Recovery', 'Oncology', 'Cardiology', 'Neurology'
  ];

  const urgencyLevels = [
    { value: 'low', label: 'Low Priority', color: 'bg-gray-100 text-gray-800', description: '7+ days advance' },
    { value: 'normal', label: 'Normal', color: 'bg-blue-100 text-blue-800', description: '3-7 days advance' },
    { value: 'high', label: 'High Priority', color: 'bg-orange-100 text-orange-800', description: '24-72 hours' },
    { value: 'urgent', label: 'Urgent', color: 'bg-red-100 text-red-800', description: 'Same day/next day' }
  ];

  const handleRequirementChange = (id: string, required: boolean) => {
    setRequirements(requirements.map(req => 
      req.id === id ? { ...req, required } : req
    ));
  };

  const addCustomRequirement = () => {
    if (!customRequirement.trim()) return;
    
    const newId = Date.now().toString();
    setRequirements([...requirements, {
      id: newId,
      name: customRequirement,
      required: false
    }]);
    setCustomRequirement('');
  };

  const removeRequirement = (id: string) => {
    setRequirements(requirements.filter(req => req.id !== id));
  };

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
  };

  const handlePrevious = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = (action: 'draft' | 'publish') => {
    // In a real app, this would submit to API
    console.log('Submitting shift:', { ...shiftData, action, requirements });
    alert(`Shift ${action === 'draft' ? 'saved as draft' : 'published'} successfully!`);
  };

  const getUrgencyInfo = (urgency: string) => {
    return urgencyLevels.find(level => level.value === urgency) || urgencyLevels[1];
  };

  const calculateEstimatedApplications = () => {
    const baseApplications = 15;
    const urgencyMultiplier = shiftData.urgency === 'urgent' ? 1.5 : shiftData.urgency === 'high' ? 1.2 : 1;
    const rateMultiplier = parseFloat(shiftData.hourlyRate) > 50 ? 1.3 : parseFloat(shiftData.hourlyRate) > 40 ? 1.1 : 0.9;
    const requirementMultiplier = requirements.filter(r => r.required).length > 4 ? 0.8 : 1;
    
    return Math.round(baseApplications * urgencyMultiplier * rateMultiplier * requirementMultiplier);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent mb-2">
          Post a Shift
        </h1>
        <p className="text-gray-600">
          Create shift postings with AI assistance for optimal nurse matching
        </p>
      </div>

      {/* Progress Steps */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            {[1, 2, 3].map((stepNumber) => (
              <div key={stepNumber} className="flex items-center">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  step >= stepNumber 
                    ? 'bg-medical-blue text-white' 
                    : 'bg-gray-200 text-gray-600'
                }`}>
                  {step > stepNumber ? <CheckCircle className="w-4 h-4" /> : stepNumber}
                </div>
                <div className="ml-2">
                  <div className={`text-sm font-medium ${step >= stepNumber ? 'text-medical-blue' : 'text-gray-600'}`}>
                    {stepNumber === 1 && 'Shift Details'}
                    {stepNumber === 2 && 'Requirements'}
                    {stepNumber === 3 && 'Review & Publish'}
                  </div>
                </div>
                {stepNumber < 3 && (
                  <div className={`w-16 h-0.5 mx-4 ${step > stepNumber ? 'bg-medical-blue' : 'bg-gray-300'}`} />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Recommendations Panel */}
      {shiftData.aiOptimized && (
        <Card className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 border-ai-purple/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Brain className="w-5 h-5 text-ai-purple" />
              <h3 className="font-semibold text-ai-purple">AI Optimization Suggestions</h3>
              <Badge className="bg-ai-purple/10 text-ai-purple border-ai-purple/20">
                Real-time
              </Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {aiRecommendations.map((rec, index) => (
                <div key={index} className="p-3 bg-white/50 rounded-lg border border-ai-purple/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium capitalize">{rec.type} Suggestion</span>
                    <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">
                      {rec.confidence}% confidence
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-700">{rec.suggestion}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 1: Shift Details */}
      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Shift Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Shift Title *</label>
                <Input
                  placeholder="e.g., ICU Night Shift Nurse"
                  value={shiftData.title}
                  onChange={(e) => setShiftData({...shiftData, title: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Department *</label>
                <select
                  value={shiftData.department}
                  onChange={(e) => setShiftData({...shiftData, department: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
                >
                  <option value="">Select Department</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Date *</label>
                <Input
                  type="date"
                  value={shiftData.date}
                  onChange={(e) => setShiftData({...shiftData, date: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Urgency Level</label>
                <select
                  value={shiftData.urgency}
                  onChange={(e) => setShiftData({...shiftData, urgency: e.target.value as any})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
                >
                  {urgencyLevels.map(level => (
                    <option key={level.value} value={level.value}>
                      {level.label} - {level.description}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Start Time *</label>
                <Input
                  type="time"
                  value={shiftData.startTime}
                  onChange={(e) => setShiftData({...shiftData, startTime: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">End Time *</label>
                <Input
                  type="time"
                  value={shiftData.endTime}
                  onChange={(e) => setShiftData({...shiftData, endTime: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Hourly Rate *</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    type="number"
                    placeholder="45.00"
                    value={shiftData.hourlyRate}
                    onChange={(e) => setShiftData({...shiftData, hourlyRate: e.target.value})}
                    className="pl-10"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Location *</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Hospital address or unit"
                    value={shiftData.location}
                    onChange={(e) => setShiftData({...shiftData, location: e.target.value})}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Shift Description</label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
                rows={4}
                placeholder="Describe the shift responsibilities, patient ratios, special requirements..."
                value={shiftData.description}
                onChange={(e) => setShiftData({...shiftData, description: e.target.value})}
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div>
                <h4 className="font-medium text-blue-900">AI Optimization</h4>
                <p className="text-sm text-blue-700">Let AI optimize your posting for better nurse matching</p>
              </div>
              <Switch
                checked={shiftData.aiOptimized}
                onCheckedChange={(checked) => setShiftData({...shiftData, aiOptimized: checked})}
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Requirements */}
      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Stethoscope className="w-5 h-5" />
              Requirements & Qualifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h4 className="font-medium mb-4">Required Certifications & Skills</h4>
              <div className="space-y-3">
                {requirements.map((requirement) => (
                  <div key={requirement.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={requirement.required}
                        onCheckedChange={(checked) => handleRequirementChange(requirement.id, checked)}
                      />
                      <span className={requirement.required ? 'font-medium' : 'text-gray-600'}>
                        {requirement.name}
                      </span>
                      {requirement.required && (
                        <Badge className="bg-red-100 text-red-800 border-red-200 text-xs">Required</Badge>
                      )}
                    </div>
                    {!['1', '2', '6'].includes(requirement.id) && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeRequirement(requirement.id)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <div className="flex gap-2 mt-4">
                <Input
                  placeholder="Add custom requirement..."
                  value={customRequirement}
                  onChange={(e) => setCustomRequirement(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addCustomRequirement()}
                />
                <Button onClick={addCustomRequirement} variant="outline">
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Contact Person</label>
                <Input
                  placeholder="Nursing supervisor name"
                  value={shiftData.contactPerson}
                  onChange={(e) => setShiftData({...shiftData, contactPerson: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Contact Phone</label>
                <Input
                  placeholder="(555) 123-4567"
                  value={shiftData.contactPhone}
                  onChange={(e) => setShiftData({...shiftData, contactPhone: e.target.value})}
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Contact Email</label>
                <Input
                  type="email"
                  placeholder="supervisor@hospital.com"
                  value={shiftData.contactEmail}
                  onChange={(e) => setShiftData({...shiftData, contactEmail: e.target.value})}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Special Instructions</label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
                rows={3}
                placeholder="Parking instructions, dress code, reporting procedures..."
                value={shiftData.specialInstructions}
                onChange={(e) => setShiftData({...shiftData, specialInstructions: e.target.value})}
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
              <div>
                <h4 className="font-medium text-green-900">Auto-approve Qualified Candidates</h4>
                <p className="text-sm text-green-700">Automatically approve nurses who meet all requirements</p>
              </div>
              <Switch
                checked={shiftData.autoApprove}
                onCheckedChange={(checked) => setShiftData({...shiftData, autoApprove: checked})}
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Review & Publish */}
      {step === 3 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              Review & Publish
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Preview */}
            <div className="border rounded-lg p-4 bg-gray-50">
              <h4 className="font-semibold text-lg mb-2">{shiftData.title}</h4>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-medical-blue" />
                  <span>{shiftData.date}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-medical-blue" />
                  <span>{shiftData.startTime} - {shiftData.endTime}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <DollarSign className="w-4 h-4 text-green-600" />
                  <span>${shiftData.hourlyRate}/hour</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-medical-blue" />
                  <span>{shiftData.department}</span>
                </div>
              </div>

              <div className="mb-4">
                <Badge className={getUrgencyInfo(shiftData.urgency).color}>
                  {getUrgencyInfo(shiftData.urgency).label}
                </Badge>
              </div>

              {shiftData.description && (
                <p className="text-gray-700 text-sm mb-4">{shiftData.description}</p>
              )}

              <div className="mb-4">
                <h5 className="font-medium mb-2">Required:</h5>
                <div className="flex flex-wrap gap-2">
                  {requirements.filter(r => r.required).map(req => (
                    <Badge key={req.id} className="bg-red-100 text-red-800 border-red-200">
                      {req.name}
                    </Badge>
                  ))}
                </div>
              </div>

              {requirements.some(r => !r.required) && (
                <div>
                  <h5 className="font-medium mb-2">Preferred:</h5>
                  <div className="flex flex-wrap gap-2">
                    {requirements.filter(r => !r.required).map(req => (
                      <Badge key={req.id} className="bg-blue-100 text-blue-800 border-blue-200">
                        {req.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* AI Predictions */}
            <div className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 rounded-lg p-4 border border-ai-purple/20">
              <div className="flex items-center gap-2 mb-3">
                <Brain className="w-4 h-4 text-ai-purple" />
                <span className="font-semibold text-ai-purple">AI Predictions</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-ai-purple">{calculateEstimatedApplications()}</div>
                  <div className="text-sm text-gray-600">Expected Applications</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-ai-purple">94%</div>
                  <div className="text-sm text-gray-600">Match Quality Score</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-ai-purple">6 hrs</div>
                  <div className="text-sm text-gray-600">Avg Response Time</div>
                </div>
              </div>
            </div>

            {/* Validation */}
            <div className="space-y-2">
              {!shiftData.title && (
                <div className="flex items-center gap-2 text-red-600 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  <span>Shift title is required</span>
                </div>
              )}
              {!shiftData.department && (
                <div className="flex items-center gap-2 text-red-600 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  <span>Department is required</span>
                </div>
              )}
              {!shiftData.date && (
                <div className="flex items-center gap-2 text-red-600 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  <span>Date is required</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between">
        <div>
          {step > 1 && (
            <Button variant="outline" onClick={handlePrevious}>
              Previous
            </Button>
          )}
        </div>

        <div className="flex items-center gap-2">
          {step < 3 ? (
            <Button 
              onClick={handleNext}
              className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
              disabled={
                (step === 1 && (!shiftData.title || !shiftData.department || !shiftData.date)) ||
                (step === 2 && !requirements.some(r => r.required))
              }
            >
              Next Step
            </Button>
          ) : (
            <>
              <Button 
                variant="outline"
                onClick={() => handleSubmit('draft')}
              >
                <Save className="w-4 h-4 mr-2" />
                Save Draft
              </Button>
              <Button 
                onClick={() => handleSubmit('publish')}
                className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
                disabled={!shiftData.title || !shiftData.department || !shiftData.date}
              >
                <Send className="w-4 h-4 mr-2" />
                Publish Shift
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
