import React, { useState } from 'react';
import { Clock, CheckCircle, XCircle, AlertCircle, Eye, Calendar, User, DollarSign, Camera, FileText, Download, Filter, Search, Brain, MessageSquare } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';

interface TimesheetEntry {
  id: string;
  nurse: {
    id: string;
    name: string;
    avatar?: string;
    rating: number;
  };
  shift: {
    title: string;
    date: string;
    department: string;
  };
  clockIn: string;
  clockOut: string;
  breakMinutes: number;
  totalHours: number;
  hourlyRate: number;
  totalPay: number;
  status: 'pending' | 'approved' | 'rejected' | 'queried';
  submittedDate: string;
  photoVerification: {
    clockInPhoto?: string;
    clockOutPhoto?: string;
  };
  location: {
    clockIn: string;
    clockOut: string;
  };
  notes: string;
  aiAnomalies: string[];
  overtimeHours: number;
  facilityNotes?: string;
}

export default function TimesheetApproval() {
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected' | 'queried'>('pending');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTimesheet, setSelectedTimesheet] = useState<TimesheetEntry | null>(null);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  const [timesheets, setTimesheets] = useState<TimesheetEntry[]>([
    {
      id: '1',
      nurse: {
        id: 'n1',
        name: 'Sarah Johnson',
        avatar: '/api/placeholder/40/40',
        rating: 4.9
      },
      shift: {
        title: 'ICU Night Shift',
        date: '2024-02-10',
        department: 'ICU'
      },
      clockIn: '18:45',
      clockOut: '07:15',
      breakMinutes: 30,
      totalHours: 12,
      hourlyRate: 52,
      totalPay: 624,
      status: 'pending',
      submittedDate: '2024-02-11',
      photoVerification: {
        clockInPhoto: '/api/placeholder/150/150',
        clockOutPhoto: '/api/placeholder/150/150'
      },
      location: {
        clockIn: 'ICU Nursing Station - Level 4',
        clockOut: 'ICU Nursing Station - Level 4'
      },
      notes: 'Covered extra patient due to short staffing. Great teamwork with day shift during handoff.',
      aiAnomalies: [],
      overtimeHours: 0,
      facilityNotes: ''
    },
    {
      id: '2',
      nurse: {
        id: 'n2',
        name: 'Marcus Williams',
        avatar: '/api/placeholder/40/40',
        rating: 4.2
      },
      shift: {
        title: 'Emergency Day Shift',
        date: '2024-02-09',
        department: 'Emergency'
      },
      clockIn: '07:00',
      clockOut: '19:30',
      breakMinutes: 45,
      totalHours: 12,
      hourlyRate: 48,
      totalPay: 600,
      status: 'pending',
      submittedDate: '2024-02-10',
      photoVerification: {
        clockInPhoto: '/api/placeholder/150/150',
        clockOutPhoto: '/api/placeholder/150/150'
      },
      location: {
        clockIn: 'Emergency Department - Main Entrance',
        clockOut: 'Emergency Department - Main Entrance'
      },
      notes: 'Busy shift with multiple trauma cases. Stayed 30 minutes late to complete documentation.',
      aiAnomalies: ['Late clock-out detected', 'Extended shift duration'],
      overtimeHours: 0.5,
      facilityNotes: ''
    },
    {
      id: '3',
      nurse: {
        id: 'n3',
        name: 'Jennifer Chen',
        avatar: '/api/placeholder/40/40',
        rating: 4.8
      },
      shift: {
        title: 'Med-Surg Evening',
        date: '2024-02-08',
        department: 'Med-Surg'
      },
      clockIn: '14:55',
      clockOut: '23:05',
      breakMinutes: 30,
      totalHours: 8,
      hourlyRate: 45,
      totalPay: 360,
      status: 'approved',
      submittedDate: '2024-02-09',
      photoVerification: {
        clockInPhoto: '/api/placeholder/150/150',
        clockOutPhoto: '/api/placeholder/150/150'
      },
      location: {
        clockIn: 'Med-Surg Unit 3B - Nurses Station',
        clockOut: 'Med-Surg Unit 3B - Nurses Station'
      },
      notes: 'Smooth shift with good patient outcomes. All medications administered on time.',
      aiAnomalies: [],
      overtimeHours: 0,
      facilityNotes: 'Excellent work. Patient feedback was very positive.'
    },
    {
      id: '4',
      nurse: {
        id: 'n4',
        name: 'David Park',
        avatar: '/api/placeholder/40/40',
        rating: 3.9
      },
      shift: {
        title: 'OR Morning',
        date: '2024-02-07',
        department: 'OR'
      },
      clockIn: '06:15',
      clockOut: '14:45',
      breakMinutes: 60,
      totalHours: 7.5,
      hourlyRate: 50,
      totalPay: 375,
      status: 'queried',
      submittedDate: '2024-02-08',
      photoVerification: {
        clockInPhoto: '/api/placeholder/150/150'
      },
      location: {
        clockIn: 'OR Suite 5 - Prep Area',
        clockOut: 'OR Suite 5 - Prep Area'
      },
      notes: 'Assisted with emergency surgery that ran over. Forgot to take clock-out photo due to emergency.',
      aiAnomalies: ['Missing clock-out photo', 'Unusual break duration'],
      overtimeHours: 0,
      facilityNotes: 'Missing clock-out photo verification. Please provide explanation.'
    }
  ]);

  const handleApprove = (timesheetId: string) => {
    setTimesheets(timesheets.map(t => 
      t.id === timesheetId ? { ...t, status: 'approved' as const } : t
    ));
  };

  const handleReject = (timesheetId: string, reason: string) => {
    setTimesheets(timesheets.map(t => 
      t.id === timesheetId ? { 
        ...t, 
        status: 'rejected' as const,
        facilityNotes: reason
      } : t
    ));
    setShowRejectModal(false);
    setRejectReason('');
  };

  const handleQuery = (timesheetId: string, query: string) => {
    setTimesheets(timesheets.map(t => 
      t.id === timesheetId ? { 
        ...t, 
        status: 'queried' as const,
        facilityNotes: query
      } : t
    ));
  };

  const filteredTimesheets = timesheets.filter(timesheet => {
    const matchesStatus = statusFilter === 'all' || timesheet.status === statusFilter;
    const matchesSearch = searchTerm === '' || 
      timesheet.nurse.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      timesheet.shift.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      timesheet.shift.department.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesStatus && matchesSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'approved': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      case 'queried': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'approved': return <CheckCircle className="w-4 h-4" />;
      case 'rejected': return <XCircle className="w-4 h-4" />;
      case 'queried': return <MessageSquare className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const stats = {
    pending: timesheets.filter(t => t.status === 'pending').length,
    approved: timesheets.filter(t => t.status === 'approved').length,
    rejected: timesheets.filter(t => t.status === 'rejected').length,
    queried: timesheets.filter(t => t.status === 'queried').length,
    totalHours: timesheets.reduce((sum, t) => sum + t.totalHours, 0),
    totalPay: timesheets.reduce((sum, t) => sum + t.totalPay, 0)
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent">
            Timesheet Approval
          </h1>
          <p className="text-gray-600 mt-2">
            Review and approve submitted timesheets with AI-powered anomaly detection
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button variant="outline">
            <FileText className="w-4 h-4 mr-2" />
            Bulk Actions
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
            <div className="text-sm text-gray-600">Pending Review</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{stats.approved}</div>
            <div className="text-sm text-gray-600">Approved</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.queried}</div>
            <div className="text-sm text-gray-600">Queried</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">{stats.rejected}</div>
            <div className="text-sm text-gray-600">Rejected</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-medical-blue">{stats.totalHours}</div>
            <div className="text-sm text-gray-600">Total Hours</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">${stats.totalPay.toLocaleString()}</div>
            <div className="text-sm text-gray-600">Total Payroll</div>
          </CardContent>
        </Card>
      </div>

      {/* AI Anomaly Detection Panel */}
      <Card className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 border-ai-purple/20">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-5 h-5 text-ai-purple" />
            <h3 className="font-semibold text-ai-purple">AI Anomaly Detection</h3>
            <Badge className="bg-ai-purple/10 text-ai-purple border-ai-purple/20">
              Active
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-orange-600">2 Anomalies Detected</div>
              <p className="text-gray-600">Unusual clock patterns requiring review</p>
            </div>
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-green-600">95% Accuracy Rate</div>
              <p className="text-gray-600">AI verification matches manual review</p>
            </div>
            <div className="p-3 bg-white/50 rounded-lg">
              <div className="font-semibold text-blue-600">Auto-Approved: 8</div>
              <p className="text-gray-600">Clean timesheets with no anomalies</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by nurse name, shift, or department..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending Review</option>
              <option value="approved">Approved</option>
              <option value="queried">Queried</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Timesheets List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Timesheets ({filteredTimesheets.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredTimesheets.map((timesheet) => (
              <div
                key={timesheet.id}
                className="p-4 border rounded-lg hover:shadow-sm transition-shadow"
              >
                <div className="flex items-start gap-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={timesheet.nurse.avatar} />
                    <AvatarFallback className="bg-gradient-to-br from-medical-blue to-ai-purple text-white">
                      {timesheet.nurse.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-gray-900">{timesheet.nurse.name}</h4>
                        <p className="text-medical-blue font-medium">{timesheet.shift.title}</p>
                        <p className="text-sm text-gray-600">
                          {timesheet.shift.department} • {new Date(timesheet.shift.date).toLocaleDateString()}
                        </p>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(timesheet.status)}>
                          <div className="flex items-center gap-1">
                            {getStatusIcon(timesheet.status)}
                            {timesheet.status.charAt(0).toUpperCase() + timesheet.status.slice(1)}
                          </div>
                        </Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 text-sm mb-4">
                      <div>
                        <span className="text-gray-600">Clock In:</span>
                        <div className="font-medium">{timesheet.clockIn}</div>
                      </div>
                      
                      <div>
                        <span className="text-gray-600">Clock Out:</span>
                        <div className="font-medium">{timesheet.clockOut}</div>
                      </div>
                      
                      <div>
                        <span className="text-gray-600">Total Hours:</span>
                        <div className="font-medium">{timesheet.totalHours}h</div>
                        {timesheet.overtimeHours > 0 && (
                          <div className="text-xs text-orange-600">+{timesheet.overtimeHours}h OT</div>
                        )}
                      </div>
                      
                      <div>
                        <span className="text-gray-600">Break:</span>
                        <div className="font-medium">{timesheet.breakMinutes} min</div>
                      </div>
                      
                      <div>
                        <span className="text-gray-600">Rate:</span>
                        <div className="font-medium">${timesheet.hourlyRate}/hr</div>
                      </div>
                      
                      <div>
                        <span className="text-gray-600">Total Pay:</span>
                        <div className="font-medium text-green-600">${timesheet.totalPay}</div>
                      </div>
                    </div>

                    {/* AI Anomalies */}
                    {timesheet.aiAnomalies.length > 0 && (
                      <div className="mb-4 p-3 bg-orange-50 rounded-lg border border-orange-200">
                        <div className="flex items-center gap-2 mb-2">
                          <Brain className="w-4 h-4 text-orange-600" />
                          <span className="font-medium text-orange-800">AI Detected Anomalies</span>
                        </div>
                        <ul className="text-sm text-orange-700 space-y-1">
                          {timesheet.aiAnomalies.map((anomaly, index) => (
                            <li key={index}>• {anomaly}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Photo Verification */}
                    <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                      <h5 className="font-medium text-gray-900 mb-2 flex items-center gap-2">
                        <Camera className="w-4 h-4" />
                        Photo Verification
                      </h5>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-xs text-gray-600">Clock In Photo:</span>
                          {timesheet.photoVerification.clockInPhoto ? (
                            <div className="mt-1">
                              <img 
                                src={timesheet.photoVerification.clockInPhoto} 
                                alt="Clock in verification" 
                                className="w-16 h-16 object-cover rounded border cursor-pointer hover:opacity-80"
                                onClick={() => {/* Open photo modal */}}
                              />
                              <p className="text-xs text-gray-500 mt-1">{timesheet.location.clockIn}</p>
                            </div>
                          ) : (
                            <div className="text-xs text-red-600 mt-1">Missing</div>
                          )}
                        </div>
                        <div>
                          <span className="text-xs text-gray-600">Clock Out Photo:</span>
                          {timesheet.photoVerification.clockOutPhoto ? (
                            <div className="mt-1">
                              <img 
                                src={timesheet.photoVerification.clockOutPhoto} 
                                alt="Clock out verification" 
                                className="w-16 h-16 object-cover rounded border cursor-pointer hover:opacity-80"
                                onClick={() => {/* Open photo modal */}}
                              />
                              <p className="text-xs text-gray-500 mt-1">{timesheet.location.clockOut}</p>
                            </div>
                          ) : (
                            <div className="text-xs text-red-600 mt-1">Missing</div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Notes */}
                    {timesheet.notes && (
                      <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <h5 className="font-medium text-blue-900 mb-1">Nurse Notes:</h5>
                        <p className="text-sm text-blue-800">{timesheet.notes}</p>
                      </div>
                    )}

                    {/* Facility Notes */}
                    {timesheet.facilityNotes && (
                      <div className="mb-4 p-3 bg-purple-50 rounded-lg border border-purple-200">
                        <h5 className="font-medium text-purple-900 mb-1">Facility Notes:</h5>
                        <p className="text-sm text-purple-800">{timesheet.facilityNotes}</p>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                      <div className="text-xs text-gray-500">
                        Submitted: {new Date(timesheet.submittedDate).toLocaleDateString()}
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setSelectedTimesheet(timesheet)}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          Details
                        </Button>
                        
                        {timesheet.status === 'pending' && (
                          <>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleApprove(timesheet.id)}
                              className="text-green-600 hover:text-green-700"
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Approve
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => {
                                // Open query modal
                                const query = prompt('Enter your query:');
                                if (query) handleQuery(timesheet.id, query);
                              }}
                              className="text-blue-600 hover:text-blue-700"
                            >
                              <MessageSquare className="w-4 h-4 mr-1" />
                              Query
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => {
                                const reason = prompt('Enter rejection reason:');
                                if (reason) handleReject(timesheet.id, reason);
                              }}
                              className="text-red-600 hover:text-red-700"
                            >
                              <XCircle className="w-4 h-4 mr-1" />
                              Reject
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredTimesheets.length === 0 && (
            <div className="text-center py-12">
              <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No Timesheets Found</h3>
              <p className="text-gray-500">
                Try adjusting your search criteria or filters.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
