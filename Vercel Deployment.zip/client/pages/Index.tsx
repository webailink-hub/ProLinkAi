import {
  Brain,
  Calendar,
  CheckCircle,
  Clock,
  MapPin,
  Shield,
  Users,
  Zap,
  TrendingUp,
  MessageSquare,
  Activity,
  Sparkles,
  Menu,
  X,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";

export default function Index() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-medical-gray">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <span className="ml-3 text-xl font-header font-bold text-gray-900">
                  ProLink<span className="text-ai-purple">Ai</span>
                </span>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <div className="hidden md:flex items-baseline space-x-8">
              <Link
                to="/nurses"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                For Nurses
              </Link>
              <Link
                to="/facilities"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                For Facilities
              </Link>
              <Link
                to="/about"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                About
              </Link>
            </div>

            {/* Desktop Auth Buttons */}
            <div className="hidden md:flex items-center space-x-4">
              <Link
                to="/login"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-6 py-2 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium shadow-card hover:shadow-card-hover"
              >
                Get Started
              </Link>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-lg text-gray-600 hover:text-medical-blue hover:bg-gray-100 transition-colors"
                aria-label="Toggle mobile menu"
              >
                {mobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200 py-4 space-y-4">
              <Link
                to="/nurses"
                className="block px-4 py-2 text-gray-600 hover:text-medical-blue hover:bg-gray-50 rounded-lg transition-colors font-body"
                onClick={() => setMobileMenuOpen(false)}
              >
                For Nurses
              </Link>
              <Link
                to="/facilities"
                className="block px-4 py-2 text-gray-600 hover:text-medical-blue hover:bg-gray-50 rounded-lg transition-colors font-body"
                onClick={() => setMobileMenuOpen(false)}
              >
                For Facilities
              </Link>
              <Link
                to="/about"
                className="block px-4 py-2 text-gray-600 hover:text-medical-blue hover:bg-gray-50 rounded-lg transition-colors font-body"
                onClick={() => setMobileMenuOpen(false)}
              >
                About
              </Link>
              <div className="border-t border-gray-200 pt-4 space-y-2">
                <Link
                  to="/login"
                  className="block px-4 py-2 text-gray-600 hover:text-medical-blue hover:bg-gray-50 rounded-lg transition-colors font-body"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Sign In
                </Link>
                <Link
                  to="/register"
                  className="block mx-4 bg-gradient-to-r from-medical-blue to-ai-purple text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium shadow-card hover:shadow-card-hover text-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Get Started
                </Link>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-medical-gray via-white to-blue-50">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-32 relative">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="text-left order-2 lg:order-1">
              <div className="inline-flex items-center bg-ai-purple/10 text-ai-purple px-3 sm:px-4 py-2 rounded-full text-xs sm:text-sm font-medium mb-4 sm:mb-6">
                <Sparkles className="w-3 sm:w-4 h-3 sm:h-4 mr-2" />
                Powered by Advanced AI Technology
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-6xl font-header font-bold text-gray-900 leading-tight">
                AI-Powered Healthcare
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-medical-blue to-ai-purple block">
                  Staffing Platform
                </span>
              </h1>
              <p className="mt-4 sm:mt-6 text-lg sm:text-xl text-gray-600 font-body leading-relaxed">
                Connect healthcare professionals with facilities using
                intelligent matching, predictive analytics, and AI-enhanced
                workflows. The future of medical staffing is here.
              </p>
              <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row gap-3 sm:gap-4">
                <Link
                  to="/register/nurse"
                  className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium text-base sm:text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 text-center"
                >
                  Join as Healthcare Professional
                </Link>
                <Link
                  to="/register/facility"
                  className="bg-white text-medical-blue border-2 border-medical-blue px-6 sm:px-8 py-3 sm:py-4 rounded-xl hover:bg-medical-blue hover:text-white transition-all duration-200 font-body font-medium text-base sm:text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 text-center"
                >
                  Register Your Facility
                </Link>
              </div>
            </div>

            {/* Hero Visualization */}
            <div className="relative order-1 lg:order-2">
              <div className="bg-gradient-to-br from-medical-blue via-ai-purple to-medical-teal rounded-2xl sm:rounded-3xl p-4 sm:p-6 lg:p-8 shadow-card-hover">
                <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:gap-6">
                  <div className="bg-white/95 backdrop-blur rounded-xl sm:rounded-2xl p-3 sm:p-4 lg:p-6 shadow-card">
                    <Brain className="w-6 sm:w-7 lg:w-8 h-6 sm:h-7 lg:h-8 text-ai-purple mb-2 sm:mb-3 lg:mb-4" />
                    <h3 className="font-header font-semibold text-gray-900 mb-1 sm:mb-2 text-sm sm:text-base">
                      AI Matching
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-600 font-body">
                      Smart algorithms find perfect matches
                    </p>
                  </div>
                  <div className="bg-white/95 backdrop-blur rounded-xl sm:rounded-2xl p-3 sm:p-4 lg:p-6 shadow-card">
                    <TrendingUp className="w-6 sm:w-7 lg:w-8 h-6 sm:h-7 lg:h-8 text-medical-green mb-2 sm:mb-3 lg:mb-4" />
                    <h3 className="font-header font-semibold text-gray-900 mb-1 sm:mb-2 text-sm sm:text-base">
                      Predictive Analytics
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-600 font-body">
                      Forecast staffing needs accurately
                    </p>
                  </div>
                  <div className="bg-white/95 backdrop-blur rounded-xl sm:rounded-2xl p-3 sm:p-4 lg:p-6 shadow-card">
                    <Activity className="w-6 sm:w-7 lg:w-8 h-6 sm:h-7 lg:h-8 text-medical-blue mb-2 sm:mb-3 lg:mb-4" />
                    <h3 className="font-header font-semibold text-gray-900 mb-1 sm:mb-2 text-sm sm:text-base">
                      Real-time Insights
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-600 font-body">
                      Live data drives better decisions
                    </p>
                  </div>
                  <div className="bg-white/95 backdrop-blur rounded-xl sm:rounded-2xl p-3 sm:p-4 lg:p-6 shadow-card">
                    <MessageSquare className="w-6 sm:w-7 lg:w-8 h-6 sm:h-7 lg:h-8 text-medical-teal mb-2 sm:mb-3 lg:mb-4" />
                    <h3 className="font-header font-semibold text-gray-900 mb-1 sm:mb-2 text-sm sm:text-base">
                      AI Communication
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-600 font-body">
                      Enhanced messaging and support
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AI Features Section */}
      <section className="py-12 sm:py-16 lg:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <div className="inline-flex items-center bg-medical-green/10 text-medical-green px-3 sm:px-4 py-2 rounded-full text-xs sm:text-sm font-medium mb-3 sm:mb-4">
              <Zap className="w-3 sm:w-4 h-3 sm:h-4 mr-2" />
              Advanced AI Capabilities
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-3 sm:mb-4">
              Intelligent Healthcare Staffing
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 font-body max-w-3xl mx-auto px-4">
              Our AI-powered platform revolutionizes how healthcare facilities
              and professionals connect, collaborate, and succeed together.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {/* AI Feature 1 */}
            <div className="bg-white border border-gray-200 rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1 group">
              <div className="w-10 sm:w-12 h-10 sm:h-12 bg-gradient-to-br from-ai-purple to-medical-blue rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform">
                <Brain className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-header font-semibold text-gray-900 mb-3 sm:mb-4">
                Smart Matching Algorithm
              </h3>
              <p className="text-gray-600 font-body leading-relaxed text-sm sm:text-base">
                Our AI analyzes skills, experience, location, and preferences to
                create perfect matches between healthcare professionals and
                facilities.
              </p>
            </div>

            {/* AI Feature 2 */}
            <div className="bg-white border border-gray-200 rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1 group">
              <div className="w-10 sm:w-12 h-10 sm:h-12 bg-gradient-to-br from-medical-green to-medical-teal rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform">
                <TrendingUp className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-header font-semibold text-gray-900 mb-3 sm:mb-4">
                Predictive Staffing
              </h3>
              <p className="text-gray-600 font-body leading-relaxed text-sm sm:text-base">
                Advanced analytics predict staffing needs, seasonal trends, and
                optimal scheduling patterns to prevent shortages before they
                occur.
              </p>
            </div>

            {/* AI Feature 3 */}
            <div className="bg-white border border-gray-200 rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1 group">
              <div className="w-10 sm:w-12 h-10 sm:h-12 bg-gradient-to-br from-medical-blue to-medical-teal rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform">
                <Shield className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-header font-semibold text-gray-900 mb-3 sm:mb-4">
                Automated Verification
              </h3>
              <p className="text-gray-600 font-body leading-relaxed text-sm sm:text-base">
                AI-powered credential verification, background checks, and
                license monitoring ensure compliance and quality standards.
              </p>
            </div>

            {/* AI Feature 4 */}
            <div className="bg-white border border-gray-200 rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1 group">
              <div className="w-10 sm:w-12 h-10 sm:h-12 bg-gradient-to-br from-accent-orange to-medical-green rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform">
                <Activity className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-header font-semibold text-gray-900 mb-3 sm:mb-4">
                Real-time Analytics
              </h3>
              <p className="text-gray-600 font-body leading-relaxed text-sm sm:text-base">
                Live dashboards provide insights into performance metrics,
                staffing levels, and market trends for data-driven decisions.
              </p>
            </div>

            {/* AI Feature 5 */}
            <div className="bg-white border border-gray-200 rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1 group">
              <div className="w-10 sm:w-12 h-10 sm:h-12 bg-gradient-to-br from-ai-purple to-accent-orange rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform">
                <MessageSquare className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-header font-semibold text-gray-900 mb-3 sm:mb-4">
                AI-Enhanced Communication
              </h3>
              <p className="text-gray-600 font-body leading-relaxed text-sm sm:text-base">
                Intelligent messaging with translation, summarization, and
                automated responses to streamline professional communication.
              </p>
            </div>

            {/* AI Feature 6 */}
            <div className="bg-white border border-gray-200 rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1 group">
              <div className="w-10 sm:w-12 h-10 sm:h-12 bg-gradient-to-br from-medical-teal to-ai-purple rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform">
                <Zap className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-header font-semibold text-gray-900 mb-3 sm:mb-4">
                Automated Workflows
              </h3>
              <p className="text-gray-600 font-body leading-relaxed text-sm sm:text-base">
                Streamlined processes for shift posting, applications,
                approvals, and payments powered by intelligent automation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 sm:py-16 lg:py-20 bg-gradient-to-br from-medical-blue via-ai-purple to-medical-teal">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white/10 backdrop-blur rounded-full p-3 sm:p-4 w-16 sm:w-20 h-16 sm:h-20 mx-auto mb-4 sm:mb-6 flex items-center justify-center">
            <Sparkles className="w-8 sm:w-10 h-8 sm:h-10 text-white" />
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-header font-bold text-white mb-4 sm:mb-6 px-4">
            Experience the Future of Healthcare Staffing
          </h2>
          <p className="text-lg sm:text-xl text-blue-100 font-body mb-6 sm:mb-8 leading-relaxed px-4">
            Join the AI revolution in healthcare staffing. Thousands of
            professionals and facilities are already experiencing smarter,
            faster, more efficient workflows.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center px-4">
            <Link
              to="/register/nurse"
              className="bg-white text-medical-blue px-6 sm:px-8 py-3 sm:py-4 rounded-xl hover:bg-gray-50 transition-all duration-200 font-body font-medium text-base sm:text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 text-center"
            >
              Start as Healthcare Professional
            </Link>
            <Link
              to="/register/facility"
              className="bg-transparent text-white border-2 border-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl hover:bg-white hover:text-medical-blue transition-all duration-200 font-body font-medium text-base sm:text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 text-center"
            >
              Register Your Facility
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 sm:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            <div className="sm:col-span-2 lg:col-span-2">
              <div className="flex items-center mb-4">
                <div className="w-8 sm:w-10 h-8 sm:h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-lg sm:rounded-xl flex items-center justify-center">
                  <Brain className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
                </div>
                <span className="ml-3 text-lg sm:text-xl font-header font-bold">
                  ProLink<span className="text-ai-purple">Ai</span>
                </span>
              </div>
              <p className="text-gray-400 font-body leading-relaxed mb-4 sm:mb-6 text-sm sm:text-base">
                <p>
                  2025 A & A 24/7 Health Care Staffing Services LLC All Rights
                  Reserved.{" "}
                </p>
                <p>
                  <br />
                </p>
                <p>
                  <br />
                </p>
                <p>
                  Revolutionizing healthcare staffing with artificial
                  intelligence, connecting professionals and facilities through
                  smart technology.
                </p>
              </p>
              <div className="text-xs sm:text-sm text-gray-400 font-body">
                <p>
                  <br />
                </p>
              </div>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-3 sm:mb-4 text-base sm:text-lg">
                For Healthcare Professionals
              </h3>
              <ul className="space-y-2 font-body text-sm sm:text-base">
                <li>
                  <Link
                    to="/nurses"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Browse Opportunities
                  </Link>
                </li>
                <li>
                  <Link
                    to="/dashboard/shifts"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Find Shifts
                  </Link>
                </li>
                <li>
                  <Link
                    to="/dashboard/profile"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    My Profile
                  </Link>
                </li>
                <li>
                  <Link
                    to="/dashboard/help"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    AI Support
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-3 sm:mb-4 text-base sm:text-lg">
                For Facilities
              </h3>
              <ul className="space-y-2 font-body text-sm sm:text-base">
                <li>
                  <Link
                    to="/facilities"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Platform Features
                  </Link>
                </li>
                <li>
                  <Link
                    to="/dashboard/post-shift"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Post Shifts
                  </Link>
                </li>
                <li>
                  <Link
                    to="/dashboard/applicants"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Manage Applications
                  </Link>
                </li>
                <li>
                  <Link
                    to="/about"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    About Us
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
