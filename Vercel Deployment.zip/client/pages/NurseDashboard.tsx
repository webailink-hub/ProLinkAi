import PlaceholderPage from "./Placeholder";

export default function NurseDashboard() {
  return (
    <PlaceholderPage
      title="Nurse Dashboard"
      description="Your personalized dashboard will show available shifts, your schedule, earnings summary, and quick actions for managing your nursing career."
      returnTo="/login"
      returnLabel="Sign In to Continue"
    />
  );
}
