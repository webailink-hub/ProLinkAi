import PlaceholderPage from "./Placeholder";

export default function AuditTrail() {
  return (
    <PlaceholderPage
      title="Security Monitoring"
      description="AI-powered security audit trail with anomaly detection, compliance tracking, and intelligent threat analysis."
      returnTo="/dashboard/admin"
      returnLabel="Back to Admin Dashboard"
    />
  );
}
