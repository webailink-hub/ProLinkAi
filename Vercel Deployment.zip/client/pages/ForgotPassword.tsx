import React, { useState } from 'react';
import { ArrowLeft, Mail, Shield, CheckCircle, AlertCircle, Smartphone, Key, Brain } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Badge } from '../components/ui/badge';

export default function ForgotPassword() {
  const [step, setStep] = useState<'email' | 'verification' | 'reset' | 'success'>('email');
  const [email, setEmail] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [verificationMethod, setVerificationMethod] = useState<'email' | 'sms' | 'ai'>('email');

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Simulate API call
    setTimeout(() => {
      if (email.includes('@')) {
        setStep('verification');
      } else {
        setError('Please enter a valid email address');
      }
      setLoading(false);
    }, 1000);
  };

  const handleVerificationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Simulate API call
    setTimeout(() => {
      if (verificationCode.length === 6) {
        setStep('reset');
      } else {
        setError('Please enter a valid 6-digit verification code');
      }
      setLoading(false);
    }, 1000);
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (newPassword !== confirmPassword) {
      setError('Passwords do not match');
      setLoading(false);
      return;
    }

    if (newPassword.length < 8) {
      setError('Password must be at least 8 characters long');
      setLoading(false);
      return;
    }

    // Simulate API call
    setTimeout(() => {
      setStep('success');
      setLoading(false);
    }, 1000);
  };

  const getPasswordStrength = (password: string) => {
    if (password.length < 6) return { strength: 'weak', color: 'bg-red-500', width: '25%' };
    if (password.length < 10) return { strength: 'medium', color: 'bg-yellow-500', width: '50%' };
    if (password.length < 12) return { strength: 'good', color: 'bg-blue-500', width: '75%' };
    return { strength: 'strong', color: 'bg-green-500', width: '100%' };
  };

  const passwordStrength = getPasswordStrength(newPassword);

  return (
    <div className="min-h-screen bg-gradient-to-br from-medical-blue/5 via-ai-purple/5 to-medical-teal/5 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
              <Shield className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent mb-2">
            Reset Password
          </h1>
          <p className="text-gray-600">
            {step === 'email' && 'Enter your email to receive password reset instructions'}
            {step === 'verification' && 'Verify your identity with our AI-assisted security'}
            {step === 'reset' && 'Create your new secure password'}
            {step === 'success' && 'Your password has been successfully reset'}
          </p>
        </div>

        <Card className="shadow-lg border-0">
          <CardContent className="p-6">
            {/* Step 1: Email Entry */}
            {step === 'email' && (
              <form onSubmit={handleEmailSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="nurse@example.com"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                {error && (
                  <Alert className="border-red-200 bg-red-50">
                    <AlertCircle className="h-4 w-4 text-red-500" />
                    <AlertDescription className="text-red-700">{error}</AlertDescription>
                  </Alert>
                )}

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
                  disabled={loading}
                >
                  {loading ? 'Sending Reset Link...' : 'Send Reset Link'}
                </Button>
              </form>
            )}

            {/* Step 2: Verification */}
            {step === 'verification' && (
              <div className="space-y-6">
                {/* AI Security Panel */}
                <div className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 rounded-lg p-4 border border-ai-purple/20">
                  <div className="flex items-center gap-2 mb-3">
                    <Brain className="w-5 h-5 text-ai-purple" />
                    <span className="font-semibold text-ai-purple">AI Security Verification</span>
                    <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">
                      Enhanced Protection
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">
                    Our AI has analyzed your account patterns and recommends verification via:
                  </p>
                  
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    <button
                      onClick={() => setVerificationMethod('email')}
                      className={`p-3 rounded-lg border text-center transition-colors ${
                        verificationMethod === 'email'
                          ? 'border-medical-blue bg-medical-blue/10 text-medical-blue'
                          : 'border-gray-200 hover:border-medical-blue/50'
                      }`}
                    >
                      <Mail className="w-4 h-4 mx-auto mb-1" />
                      <div className="text-xs">Email</div>
                    </button>
                    <button
                      onClick={() => setVerificationMethod('sms')}
                      className={`p-3 rounded-lg border text-center transition-colors ${
                        verificationMethod === 'sms'
                          ? 'border-medical-blue bg-medical-blue/10 text-medical-blue'
                          : 'border-gray-200 hover:border-medical-blue/50'
                      }`}
                    >
                      <Smartphone className="w-4 h-4 mx-auto mb-1" />
                      <div className="text-xs">SMS</div>
                    </button>
                    <button
                      onClick={() => setVerificationMethod('ai')}
                      className={`p-3 rounded-lg border text-center transition-colors ${
                        verificationMethod === 'ai'
                          ? 'border-ai-purple bg-ai-purple/10 text-ai-purple'
                          : 'border-gray-200 hover:border-ai-purple/50'
                      }`}
                    >
                      <Brain className="w-4 h-4 mx-auto mb-1" />
                      <div className="text-xs">AI Quiz</div>
                    </button>
                  </div>
                </div>

                <form onSubmit={handleVerificationSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Verification Code
                    </label>
                    <div className="relative">
                      <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        type="text"
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value)}
                        placeholder="Enter 6-digit code"
                        className="pl-10 text-center text-lg tracking-wider"
                        maxLength={6}
                        required
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {verificationMethod === 'email' && `Code sent to ${email}`}
                      {verificationMethod === 'sms' && 'Code sent to your registered phone'}
                      {verificationMethod === 'ai' && 'Answer the AI-generated security question'}
                    </p>
                  </div>

                  {error && (
                    <Alert className="border-red-200 bg-red-50">
                      <AlertCircle className="h-4 w-4 text-red-500" />
                      <AlertDescription className="text-red-700">{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
                    disabled={loading}
                  >
                    {loading ? 'Verifying...' : 'Verify Code'}
                  </Button>

                  <Button
                    type="button"
                    variant="ghost"
                    className="w-full"
                    onClick={() => setStep('email')}
                  >
                    Resend Code
                  </Button>
                </form>
              </div>
            )}

            {/* Step 3: Password Reset */}
            {step === 'reset' && (
              <form onSubmit={handlePasswordReset} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    New Password
                  </label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter new password"
                      className="pl-10"
                      required
                    />
                  </div>
                  
                  {newPassword && (
                    <div className="mt-2">
                      <div className="flex justify-between text-xs text-gray-600 mb-1">
                        <span>Password Strength</span>
                        <span className="capitalize">{passwordStrength.strength}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-300 ${passwordStrength.color}`}
                          style={{ width: passwordStrength.width }}
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Confirm new password"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                {/* AI Password Recommendations */}
                <div className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 rounded-lg p-4 border border-ai-purple/20">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain className="w-4 h-4 text-ai-purple" />
                    <span className="text-sm font-semibold text-ai-purple">AI Security Tips</span>
                  </div>
                  <ul className="text-xs text-gray-600 space-y-1">
                    <li>• Use 12+ characters with mix of letters, numbers, symbols</li>
                    <li>• Avoid personal information or common patterns</li>
                    <li>• Consider using a unique passphrase</li>
                  </ul>
                </div>

                {error && (
                  <Alert className="border-red-200 bg-red-50">
                    <AlertCircle className="h-4 w-4 text-red-500" />
                    <AlertDescription className="text-red-700">{error}</AlertDescription>
                  </Alert>
                )}

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
                  disabled={loading || !newPassword || !confirmPassword}
                >
                  {loading ? 'Updating Password...' : 'Update Password'}
                </Button>
              </form>
            )}

            {/* Step 4: Success */}
            {step === 'success' && (
              <div className="text-center space-y-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    Password Reset Successful!
                  </h3>
                  <p className="text-gray-600">
                    Your password has been successfully updated. You can now log in with your new password.
                  </p>
                </div>

                <div className="bg-gradient-to-r from-green-50 to-medical-teal-50 rounded-lg p-4 border border-green-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Shield className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-semibold text-green-800">Security Update</span>
                  </div>
                  <p className="text-xs text-green-700">
                    For your security, all active sessions have been logged out. Please log in again.
                  </p>
                </div>

                <Link to="/login">
                  <Button className="w-full bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90">
                    Continue to Login
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Back to Login */}
        {step !== 'success' && (
          <div className="text-center mt-6">
            <Link 
              to="/login" 
              className="inline-flex items-center text-sm text-gray-600 hover:text-medical-blue transition-colors"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back to Login
            </Link>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-xs text-gray-500">
            Need help? <Link to="/dashboard/help" className="text-medical-blue hover:underline">Contact Support</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
