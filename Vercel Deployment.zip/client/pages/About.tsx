import {
  Brain,
  Heart,
  Shield,
  TrendingUp,
  Users,
  Zap,
  Target,
  Award,
  Globe,
  Lightbulb,
  Rocket,
  CheckCircle2,
  ArrowRight,
  BarChart3,
  Clock,
  DollarSign,
  Building2,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            <div className="hidden md:flex items-center space-x-8">
              <Link
                to="/nurses"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                For Nurses
              </Link>
              <Link
                to="/facilities"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                For Facilities
              </Link>
              <Link
                to="/about"
                className="text-medical-blue font-medium font-body"
              >
                About
              </Link>
              <Link
                to="/login"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-6 py-2 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium shadow-card hover:shadow-card-hover"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-medical-gray via-white to-blue-50 py-20 lg:py-32">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center bg-ai-purple/10 text-ai-purple px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Rocket className="w-4 h-4 mr-2" />
              Founded by Healthcare Professionals, Powered by AI
            </div>
            <h1 className="text-4xl lg:text-6xl font-header font-bold text-gray-900 leading-tight mb-6">
              Revolutionizing Healthcare
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-medical-blue to-ai-purple block">
                Through Intelligent Staffing
              </span>
            </h1>
            <p className="text-xl text-gray-600 font-body leading-relaxed mb-8 max-w-3xl mx-auto">
              ProLinkAi combines deep healthcare expertise with cutting-edge AI
              technology to solve the industry's most critical staffing
              challenges. We're not just a platform—we're healthcare's partner
              in transformation.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link
                to="/register"
                className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5"
              >
                Join Our Mission
              </Link>
              <Link
                to="#vision"
                className="bg-white text-medical-blue border-2 border-medical-blue px-8 py-4 rounded-xl hover:bg-medical-blue hover:text-white transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5"
              >
                Learn Our Story
              </Link>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-header font-bold text-medical-blue">
                  15,000+
                </div>
                <div className="text-sm text-gray-600 font-body">
                  Healthcare Professionals
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-header font-bold text-medical-green">
                  500+
                </div>
                <div className="text-sm text-gray-600 font-body">
                  Healthcare Facilities
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-header font-bold text-ai-purple">
                  $2.1M
                </div>
                <div className="text-sm text-gray-600 font-body">
                  Average Annual Savings
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-header font-bold text-accent-orange">
                  98%
                </div>
                <div className="text-sm text-gray-600 font-body">
                  Satisfaction Rate
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section id="vision" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-6">
                Our Mission: Empowering Healthcare Through AI
              </h2>
              <p className="text-xl text-gray-600 font-body leading-relaxed mb-8">
                Healthcare faces an unprecedented staffing crisis. Traditional
                solutions are slow, expensive, and ineffective. We believe
                artificial intelligence can bridge this gap, creating better
                outcomes for everyone.
              </p>

              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-medical-blue/10 rounded-lg flex items-center justify-center mr-4 mt-1">
                    <Heart className="w-5 h-5 text-medical-blue" />
                  </div>
                  <div>
                    <h3 className="font-header font-semibold text-gray-900 mb-2">
                      For Patients
                    </h3>
                    <p className="text-gray-600 font-body">
                      Ensuring consistent, quality care through optimal staffing
                      levels
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 bg-medical-green/10 rounded-lg flex items-center justify-center mr-4 mt-1">
                    <Users className="w-5 h-5 text-medical-green" />
                  </div>
                  <div>
                    <h3 className="font-header font-semibold text-gray-900 mb-2">
                      For Nurses
                    </h3>
                    <p className="text-gray-600 font-body">
                      Creating flexible, rewarding careers with AI-powered
                      matching and growth
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 bg-ai-purple/10 rounded-lg flex items-center justify-center mr-4 mt-1">
                    <Shield className="w-5 h-5 text-ai-purple" />
                  </div>
                  <div>
                    <h3 className="font-header font-semibold text-gray-900 mb-2">
                      For Facilities
                    </h3>
                    <p className="text-gray-600 font-body">
                      Reducing costs and complexity while improving patient
                      outcomes
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="bg-gradient-to-br from-medical-blue via-ai-purple to-medical-teal rounded-3xl p-8 shadow-card-hover">
                <div className="text-white text-center mb-8">
                  <Brain className="w-16 h-16 mx-auto mb-4" />
                  <h3 className="text-2xl font-header font-bold">
                    AI-Driven Impact
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/20 backdrop-blur rounded-xl p-4 text-center">
                    <Clock className="w-8 h-8 text-white mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">50%</div>
                    <div className="text-sm text-blue-100">Faster Matching</div>
                  </div>
                  <div className="bg-white/20 backdrop-blur rounded-xl p-4 text-center">
                    <DollarSign className="w-8 h-8 text-white mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">35%</div>
                    <div className="text-sm text-blue-100">Cost Reduction</div>
                  </div>
                  <div className="bg-white/20 backdrop-blur rounded-xl p-4 text-center">
                    <TrendingUp className="w-8 h-8 text-white mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">98%</div>
                    <div className="text-sm text-blue-100">Satisfaction</div>
                  </div>
                  <div className="bg-white/20 backdrop-blur rounded-xl p-4 text-center">
                    <Target className="w-8 h-8 text-white mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">100%</div>
                    <div className="text-sm text-blue-100">Compliance</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-medical-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Our Story: From Healthcare Crisis to AI Solution
            </h2>
            <p className="text-xl text-gray-600 font-body max-w-3xl mx-auto">
              Born from real healthcare experience, built with cutting-edge
              technology
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Chapter 1 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-6">
                <Award className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                The Crisis
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Our founders, experienced healthcare administrators, witnessed
                firsthand the devastating impact of staffing shortages:
                overworked nurses, compromised patient care, and skyrocketing
                costs.
              </p>
              <div className="text-red-600 font-medium text-sm">
                2019: The breaking point
              </div>
            </div>

            {/* Chapter 2 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="w-12 h-12 bg-ai-purple/10 rounded-xl flex items-center justify-center mb-6">
                <Lightbulb className="w-6 h-6 text-ai-purple" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                The Innovation
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                We assembled a team of healthcare experts and AI engineers to
                create the first truly intelligent staffing platform. Our AI
                learns from every interaction to make better matches.
              </p>
              <div className="text-ai-purple font-medium text-sm">
                2020-2022: Building the future
              </div>
            </div>

            {/* Chapter 3 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="w-12 h-12 bg-medical-green/10 rounded-xl flex items-center justify-center mb-6">
                <Globe className="w-6 h-6 text-medical-green" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                The Impact
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Today, we serve 500+ facilities and 15,000+ nurses nationwide.
                Our platform has saved healthcare systems millions while
                improving patient outcomes and nurse satisfaction.
              </p>
              <div className="text-medical-green font-medium text-sm">
                2023-Present: Transforming healthcare
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Leadership Team
            </h2>
            <p className="text-xl text-gray-600 font-body">
              Healthcare veterans and technology innovators driving
              transformation
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Founder & Principal */}
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-medical-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl font-bold text-white">AG</span>
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-2">
                Andrew Gutierrez
              </h3>
              <p className="text-medical-blue font-medium mb-2">
                Visionary Founder & Key Principal
              </p>
              <p className="text-gray-600 font-body text-sm">
                Healthcare industry visionary with deep understanding of staffing challenges.
                Founded ProLinkAi to revolutionize nurse-facility connections through AI innovation.
              </p>
            </div>

            {/* CTO */}
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-ai-purple to-medical-teal rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl font-bold text-white">VL</span>
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-2">
                Victor Ledesma
              </h3>
              <p className="text-ai-purple font-medium mb-2">
                Chief Technical Officer
              </p>
              <p className="text-gray-600 font-body text-sm">
                Technology leader driving the development of ProLinkAi's AI-powered platform.
                Expert in scalable healthcare technology solutions and machine learning applications.
              </p>
            </div>

            {/* COO */}
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-medical-green to-medical-blue rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl font-bold text-white">AL</span>
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-2">
                Amanda Liu
              </h3>
              <p className="text-medical-green font-medium mb-2">COO</p>
              <p className="text-gray-600 font-body text-sm">
                Healthcare operations leader with experience scaling technology
                platforms from startup to enterprise.
              </p>
            </div>

            {/* Chief Medical Officer */}
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-accent-orange to-medical-green rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl font-bold text-white">RJ</span>
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-2">
                Dr. Robert Johnson
              </h3>
              <p className="text-accent-orange font-medium mb-2">
                Chief Medical Officer
              </p>
              <p className="text-gray-600 font-body text-sm">
                Board-certified physician with 20+ years in healthcare. Former
                medical director at Mayo Clinic.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Case Studies */}
      <section className="py-20 bg-medical-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Real Results: Case Studies
            </h2>
            <p className="text-xl text-gray-600 font-body">
              See how leading healthcare systems transformed their operations
              with ProLinkAi
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Case Study 1 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center mr-4">
                  <Building2 className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-header font-semibold text-gray-900">
                    Metro General Hospital
                  </h3>
                  <p className="text-gray-600">450-bed Level 1 Trauma Center</p>
                </div>
              </div>

              <h4 className="font-header font-semibold text-gray-900 mb-4">
                Challenge
              </h4>
              <p className="text-gray-600 font-body mb-6">
                Struggling with 15% nurse vacancy rate, $2.3M annual overtime
                costs, and 8-hour average shift fill times during critical
                shortages.
              </p>

              <h4 className="font-header font-semibold text-gray-900 mb-4">
                Solution
              </h4>
              <p className="text-gray-600 font-body mb-6">
                Implemented ProLinkAi's complete platform with AI matching,
                predictive staffing, and automated credential management.
              </p>

              <h4 className="font-header font-semibold text-gray-900 mb-4">
                Results
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-medical-blue/10 rounded-lg">
                  <div className="text-2xl font-bold text-medical-blue">
                    85%
                  </div>
                  <div className="text-sm text-gray-600">Faster Fill Times</div>
                </div>
                <div className="text-center p-4 bg-medical-green/10 rounded-lg">
                  <div className="text-2xl font-bold text-medical-green">
                    $1.6M
                  </div>
                  <div className="text-sm text-gray-600">Annual Savings</div>
                </div>
              </div>
            </div>

            {/* Case Study 2 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-medical-green to-medical-teal rounded-xl flex items-center justify-center mr-4">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-header font-semibold text-gray-900">
                    Regional Healthcare Network
                  </h3>
                  <p className="text-gray-600">8 facilities, 2,000+ beds</p>
                </div>
              </div>

              <h4 className="font-header font-semibold text-gray-900 mb-4">
                Challenge
              </h4>
              <p className="text-gray-600 font-body mb-6">
                Multi-facility coordination challenges, inconsistent quality
                standards, and 22% turnover rate among traveling nurses.
              </p>

              <h4 className="font-header font-semibold text-gray-900 mb-4">
                Solution
              </h4>
              <p className="text-gray-600 font-body mb-6">
                Deployed enterprise-wide ProLinkAi with centralized management,
                AI-powered quality assurance, and unified credentialing.
              </p>

              <h4 className="font-header font-semibold text-gray-900 mb-4">
                Results
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-ai-purple/10 rounded-lg">
                  <div className="text-2xl font-bold text-ai-purple">40%</div>
                  <div className="text-sm text-gray-600">
                    Turnover Reduction
                  </div>
                </div>
                <div className="text-center p-4 bg-accent-orange/10 rounded-lg">
                  <div className="text-2xl font-bold text-accent-orange">
                    98%
                  </div>
                  <div className="text-sm text-gray-600">Quality Score</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Technology & Innovation */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Our Technology Advantage
            </h2>
            <p className="text-xl text-gray-600 font-body">
              Cutting-edge AI and machine learning powering healthcare
              transformation
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-ai-purple/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Brain className="w-8 h-8 text-ai-purple" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Machine Learning Algorithms
              </h3>
              <p className="text-gray-600 font-body">
                Advanced neural networks continuously learn from matching
                patterns to improve recommendations
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-medical-blue/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <BarChart3 className="w-8 h-8 text-medical-blue" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Predictive Analytics
              </h3>
              <p className="text-gray-600 font-body">
                Forecast staffing needs and identify potential shortages before
                they impact patient care
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-medical-green/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8 text-medical-green" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Security & Compliance
              </h3>
              <p className="text-gray-600 font-body">
                HIPAA-compliant platform with enterprise-grade security and
                automated compliance monitoring
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Investors & Partners */}
      <section className="py-20 bg-medical-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Backed by Leading Investors
            </h2>
            <p className="text-xl text-gray-600 font-body">
              Trusted by top-tier VCs and healthcare industry leaders
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="bg-white rounded-xl p-6 shadow-card text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-lg mx-auto mb-4 flex items-center justify-center">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <p className="font-medium text-gray-900">Series A: $25M</p>
              <p className="text-sm text-gray-600">
                Led by Healthcare Ventures
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-card text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-green to-medical-teal rounded-lg mx-auto mb-4 flex items-center justify-center">
                <Award className="w-8 h-8 text-white" />
              </div>
              <p className="font-medium text-gray-900">AI Innovation Award</p>
              <p className="text-sm text-gray-600">Healthcare IT Excellence</p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-card text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-ai-purple to-accent-orange rounded-lg mx-auto mb-4 flex items-center justify-center">
                <Users className="w-8 h-8 text-white" />
              </div>
              <p className="font-medium text-gray-900">Partnership</p>
              <p className="text-sm text-gray-600">
                American Nurses Association
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-card text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-accent-orange to-medical-green rounded-lg mx-auto mb-4 flex items-center justify-center">
                <Globe className="w-8 h-8 text-white" />
              </div>
              <p className="font-medium text-gray-900">Strategic Partner</p>
              <p className="text-sm text-gray-600">Joint Commission</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-medical-blue via-ai-purple to-medical-teal">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white/10 backdrop-blur rounded-full p-4 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
            <Rocket className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl lg:text-4xl font-header font-bold text-white mb-6">
            Join the Healthcare Revolution
          </h2>
          <p className="text-xl text-blue-100 font-body mb-8 leading-relaxed">
            Whether you're a nurse seeking better opportunities or a facility
            looking to transform operations, ProLinkAi is your partner in
            creating the future of healthcare.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="bg-white text-medical-blue px-8 py-4 rounded-xl hover:bg-gray-50 transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 inline-flex items-center justify-center"
            >
              Start Your Journey
              <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
            <Link
              to="/contact"
              className="bg-transparent text-white border-2 border-white px-8 py-4 rounded-xl hover:bg-white hover:text-medical-blue transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <span className="ml-3 text-xl font-header font-bold">
                  ProLink<span className="text-ai-purple">Ai</span>
                </span>
              </div>
              <p className="text-gray-400 font-body leading-relaxed mb-6">
                Transforming healthcare staffing through artificial
                intelligence. Empowering professionals, optimizing operations,
                improving patient care.
              </p>
              <div className="text-sm text-gray-400 font-body">
                © 2024 ProLinkAi. All rights reserved.
              </div>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-4">Company</h3>
              <ul className="space-y-2 font-body">
                <li>
                  <Link
                    to="/about"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/careers"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Careers
                  </Link>
                </li>
                <li>
                  <Link
                    to="/press"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Press
                  </Link>
                </li>
                <li>
                  <Link
                    to="/investors"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Investors
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-4">Solutions</h3>
              <ul className="space-y-2 font-body">
                <li>
                  <Link
                    to="/nurses"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    For Nurses
                  </Link>
                </li>
                <li>
                  <Link
                    to="/facilities"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    For Facilities
                  </Link>
                </li>
                <li>
                  <Link
                    to="/enterprise"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Enterprise
                  </Link>
                </li>
                <li>
                  <Link
                    to="/api"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    API
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
