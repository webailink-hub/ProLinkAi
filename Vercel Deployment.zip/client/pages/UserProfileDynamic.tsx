import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import {
  ArrowLeft,
  Star,
  Calendar,
  Clock,
  MapPin,
  Award,
  Shield,
  Mail,
  Phone,
  Building2,
  CheckCircle,
  MessageSquare,
  MoreHorizontal,
  User,
  Download,
  Briefcase,
  CreditCard,
  Target,
} from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";

// Mock user data - in real app this would come from API based on userId
const generateMockUserData = (userId: string) => ({
  id: userId,
  firstName: "Sarah",
  lastName: "Johnson",
  email: "sarah.johnson@email.com",
  phone: "(555) 123-4567",
  role: "nurse",
  avatar: null,
  status: "active",
  verificationStatus: "verified",
  joinDate: "2023-08-15",
  location: {
    city: "San Francisco",
    state: "CA",
    zipCode: "94102",
  },
  credentials: [
    {
      type: "RN License",
      state: "CA",
      number: "RN123456",
      expiry: "2025-12-31",
      status: "active",
    },
    {
      type: "BLS Certification",
      issuer: "AHA",
      expiry: "2024-10-15",
      status: "active",
    },
    {
      type: "ACLS Certification",
      issuer: "AHA",
      expiry: "2024-08-20",
      status: "active",
    },
    {
      type: "NIH Stroke Scale",
      issuer: "NIH",
      expiry: "2024-12-01",
      status: "active",
    },
  ],
  specialties: ["ICU", "Emergency Medicine", "Trauma", "Pediatrics"],
  stats: {
    totalShifts: 89,
    hoursWorked: 1067,
    averageRating: 4.8,
    completionRate: 98.9,
    onTimeRate: 96.3,
    responseTime: "< 2 hours",
    earnings: 42750,
    shiftsThisMonth: 12,
    earningsThisMonth: 6840,
  },
  recentShifts: [
    {
      id: 1,
      facility: "UCSF Medical Center",
      department: "ICU",
      date: "2024-01-15",
      duration: "12 hours",
      pay: 680,
      rating: 5,
      status: "completed",
    },
    {
      id: 2,
      facility: "San Francisco General",
      department: "Emergency",
      date: "2024-01-12",
      duration: "8 hours",
      pay: 520,
      rating: 5,
      status: "completed",
    },
  ],
});

export default function UserProfileDynamic() {
  const { userId } = useParams();
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      if (userId) {
        setUserData(generateMockUserData(userId));
      }
      setLoading(false);
    }, 1000);
  }, [userId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-medical-blue"></div>
      </div>
    );
  }

  if (!userData) {
    return (
      <div className="p-6 text-center">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <User className="w-8 h-8 text-gray-400" />
        </div>
        <h2 className="text-xl font-semibold text-gray-900 mb-2">
          User Not Found
        </h2>
        <p className="text-gray-600 mb-4">
          The user profile you're looking for doesn't exist.
        </p>
        <Link to="/dashboard">
          <Button variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "verified":
        return "bg-blue-100 text-blue-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Link to="/dashboard">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">User Profile</h1>
          <p className="text-gray-600">
            Comprehensive profile and performance analytics
          </p>
        </div>
      </div>

      {/* Profile Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-6">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 bg-gradient-to-br from-medical-blue to-ai-purple rounded-full flex items-center justify-center text-white text-2xl font-bold">
                {userData.firstName[0]}
                {userData.lastName[0]}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  {userData.firstName} {userData.lastName}
                </h2>
                <div className="flex items-center gap-2 mt-1">
                  <Badge className={getStatusColor(userData.status)}>
                    {userData.status}
                  </Badge>
                  <Badge
                    className={getStatusColor(userData.verificationStatus)}
                  >
                    <CheckCircle className="w-3 h-3 mr-1" />
                    {userData.verificationStatus}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <Mail className="w-4 h-4" />
                    {userData.email}
                  </span>
                  <span className="flex items-center gap-1">
                    <Phone className="w-4 h-4" />
                    {userData.phone}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {userData.location.city}, {userData.location.state}
                  </span>
                </div>
              </div>
            </div>

            <div className="md:ml-auto flex flex-col md:flex-row gap-2">
              <Button variant="outline" size="sm">
                <MessageSquare className="w-4 h-4 mr-2" />
                Message
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Average Rating</p>
                <p className="text-2xl font-bold text-gray-900">
                  {userData.stats.averageRating}/5
                </p>
              </div>
              <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                <Star className="w-5 h-5 text-yellow-600" />
              </div>
            </div>
            <div className="flex mt-2">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3 h-3 ${i < Math.floor(userData.stats.averageRating) ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                />
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Shifts</p>
                <p className="text-2xl font-bold text-gray-900">
                  {userData.stats.totalShifts}
                </p>
              </div>
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-blue-600" />
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {userData.stats.hoursWorked} total hours
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Completion Rate</p>
                <p className="text-2xl font-bold text-gray-900">
                  {userData.stats.completionRate}%
                </p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <Target className="w-5 h-5 text-green-600" />
              </div>
            </div>
            <div className="mt-2">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-600 h-2 rounded-full"
                  style={{ width: `${userData.stats.completionRate}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Earnings</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${userData.stats.earnings.toLocaleString()}
                </p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-green-600" />
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              ${userData.stats.earningsThisMonth} this month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Overview Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Specialties</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {userData.specialties.map((specialty, index) => (
                <Badge key={index} variant="secondary" className="px-3 py-1">
                  {specialty}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Stats</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Response Time</span>
              <span className="font-medium">{userData.stats.responseTime}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">On-Time Rate</span>
              <span className="font-medium">{userData.stats.onTimeRate}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Shifts This Month</span>
              <span className="font-medium">
                {userData.stats.shiftsThisMonth}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Member Since</span>
              <span className="font-medium">
                {new Date(userData.joinDate).toLocaleDateString()}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Credentials */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">
            Credentials & Certifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {userData.credentials.map((credential, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Award className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {credential.type}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {credential.state ? `${credential.state} - ` : ""}
                      {credential.issuer ? `${credential.issuer} - ` : ""}
                      {credential.number || ""}
                    </p>
                    <p className="text-xs text-gray-500">
                      Expires:{" "}
                      {new Date(credential.expiry).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <Badge
                  className={
                    credential.status === "active"
                      ? "bg-green-100 text-green-800"
                      : "bg-yellow-100 text-yellow-800"
                  }
                >
                  {credential.status}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Shifts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Shifts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {userData.recentShifts.map((shift) => (
              <div
                key={shift.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {shift.facility}
                    </h4>
                    <p className="text-sm text-gray-600">{shift.department}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
                      <span>{new Date(shift.date).toLocaleDateString()}</span>
                      <span>{shift.duration}</span>
                      <span className="text-green-600 font-medium">
                        ${shift.pay}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 mb-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${i < shift.rating ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                      />
                    ))}
                  </div>
                  <Badge className={getStatusColor(shift.status)}>
                    {shift.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
