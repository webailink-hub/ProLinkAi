import React, { useState } from 'react';
import { User, Shield, Bell, Palette, Globe, Brain, Smartphone, Mail, Eye, Lock, Download, Trash2, Save, ChevronRight } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Switch } from '../components/ui/switch';

export default function Settings() {
  const [activeTab, setActiveTab] = useState('profile');
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);

  // Profile Settings
  const [profile, setProfile] = useState({
    firstName: 'Sarah',
    lastName: 'Johnson',
    email: 'sarah.johnson@email.com',
    phone: '+1 (555) 123-4567',
    location: 'San Francisco, CA',
    timezone: 'Pacific Time (PT)',
    language: 'English'
  });

  // Privacy Settings
  const [privacy, setPrivacy] = useState({
    profileVisibility: 'facility-only',
    showLocation: true,
    showPhone: false,
    allowMessages: true,
    dataSharing: false
  });

  // Notification Settings
  const [notifications, setNotifications] = useState({
    email: {
      shiftAlerts: true,
      messages: true,
      applications: true,
      payouts: true,
      marketing: false
    },
    push: {
      shiftAlerts: true,
      messages: true,
      applications: false,
      payouts: true,
      marketing: false
    },
    sms: {
      shiftAlerts: true,
      messages: false,
      applications: false,
      payouts: false,
      marketing: false
    }
  });

  // AI Settings
  const [aiSettings, setAiSettings] = useState({
    personalizedRecommendations: true,
    smartMatching: true,
    aiAssistant: true,
    dataAnalysis: true,
    autoOptimization: false
  });

  // Security Settings
  const [security, setSecurity] = useState({
    twoFactor: false,
    biometric: true,
    sessionTimeout: '30',
    loginAlerts: true
  });

  const handleSave = async () => {
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setSaved(true);
      setLoading(false);
      setTimeout(() => setSaved(false), 3000);
    }, 1000);
  };

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'privacy', label: 'Privacy', icon: Eye },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'ai', label: 'AI Assistance', icon: Brain },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'account', label: 'Account', icon: Lock }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-medical-blue to-ai-purple bg-clip-text text-transparent">
            Settings
          </h1>
          <p className="text-gray-600 mt-2">
            Manage your account preferences and AI assistance levels
          </p>
        </div>

        <Button 
          onClick={handleSave}
          disabled={loading}
          className="bg-gradient-to-r from-medical-blue to-ai-purple hover:from-medical-blue/90 hover:to-ai-purple/90"
        >
          <Save className="w-4 h-4 mr-2" />
          {loading ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>

      {saved && (
        <Alert className="border-green-200 bg-green-50">
          <Shield className="h-4 w-4 text-green-500" />
          <AlertDescription className="text-green-700">
            Settings saved successfully!
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar Navigation */}
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-0">
              <nav className="space-y-1">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors ${
                        activeTab === tab.id
                          ? 'bg-gradient-to-r from-medical-blue/10 to-ai-purple/10 text-medical-blue border-r-2 border-medical-blue'
                          : 'hover:bg-gray-50 text-gray-700'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="font-medium">{tab.label}</span>
                      <ChevronRight className="w-4 h-4 ml-auto" />
                    </button>
                  );
                })}
              </nav>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          {/* Profile Settings */}
          {activeTab === 'profile' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Profile Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                    <Input
                      value={profile.firstName}
                      onChange={(e) => setProfile({...profile, firstName: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                    <Input
                      value={profile.lastName}
                      onChange={(e) => setProfile({...profile, lastName: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <Input
                      type="email"
                      value={profile.email}
                      onChange={(e) => setProfile({...profile, email: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                    <Input
                      value={profile.phone}
                      onChange={(e) => setProfile({...profile, phone: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                    <Input
                      value={profile.location}
                      onChange={(e) => setProfile({...profile, location: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Timezone</label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-blue focus:border-medical-blue">
                      <option>Pacific Time (PT)</option>
                      <option>Mountain Time (MT)</option>
                      <option>Central Time (CT)</option>
                      <option>Eastern Time (ET)</option>
                    </select>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Privacy Settings */}
          {activeTab === 'privacy' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  Privacy Controls
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Profile Visibility</h4>
                      <p className="text-sm text-gray-600">Control who can see your profile</p>
                    </div>
                    <select className="px-3 py-2 border border-gray-300 rounded-md">
                      <option value="public">Public</option>
                      <option value="facility-only">Facilities Only</option>
                      <option value="private">Private</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Show Location</h4>
                      <p className="text-sm text-gray-600">Display your city on your profile</p>
                    </div>
                    <Switch 
                      checked={privacy.showLocation}
                      onCheckedChange={(checked) => setPrivacy({...privacy, showLocation: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Show Phone Number</h4>
                      <p className="text-sm text-gray-600">Allow facilities to see your phone</p>
                    </div>
                    <Switch 
                      checked={privacy.showPhone}
                      onCheckedChange={(checked) => setPrivacy({...privacy, showPhone: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Allow Direct Messages</h4>
                      <p className="text-sm text-gray-600">Receive messages from facilities</p>
                    </div>
                    <Switch 
                      checked={privacy.allowMessages}
                      onCheckedChange={(checked) => setPrivacy({...privacy, allowMessages: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Data Sharing for Research</h4>
                      <p className="text-sm text-gray-600">Anonymous data for healthcare research</p>
                    </div>
                    <Switch 
                      checked={privacy.dataSharing}
                      onCheckedChange={(checked) => setPrivacy({...privacy, dataSharing: checked})}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Notifications */}
          {activeTab === 'notifications' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Notification Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Email Notifications */}
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Mail className="w-4 h-4 text-medical-blue" />
                      <h4 className="font-medium">Email</h4>
                    </div>
                    <div className="space-y-3">
                      {Object.entries(notifications.email).map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between">
                          <span className="text-sm capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                          <Switch 
                            checked={value}
                            onCheckedChange={(checked) => setNotifications({
                              ...notifications,
                              email: {...notifications.email, [key]: checked}
                            })}
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Push Notifications */}
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Smartphone className="w-4 h-4 text-ai-purple" />
                      <h4 className="font-medium">Push</h4>
                    </div>
                    <div className="space-y-3">
                      {Object.entries(notifications.push).map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between">
                          <span className="text-sm capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                          <Switch 
                            checked={value}
                            onCheckedChange={(checked) => setNotifications({
                              ...notifications,
                              push: {...notifications.push, [key]: checked}
                            })}
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* SMS Notifications */}
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Smartphone className="w-4 h-4 text-medical-teal" />
                      <h4 className="font-medium">SMS</h4>
                    </div>
                    <div className="space-y-3">
                      {Object.entries(notifications.sms).map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between">
                          <span className="text-sm capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                          <Switch 
                            checked={value}
                            onCheckedChange={(checked) => setNotifications({
                              ...notifications,
                              sms: {...notifications.sms, [key]: checked}
                            })}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* AI Settings */}
          {activeTab === 'ai' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  AI Assistance Levels
                  <Badge className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 text-ai-purple border-ai-purple/20">
                    Enhanced
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-gradient-to-r from-ai-purple/10 to-medical-teal/10 rounded-lg p-4 border border-ai-purple/20">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain className="w-4 h-4 text-ai-purple" />
                    <span className="font-semibold text-ai-purple">ProLinkAi Intelligence</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Configure how our AI assists you in finding shifts, optimizing schedules, and managing your healthcare career.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Personalized Recommendations</h4>
                      <p className="text-sm text-gray-600">AI-powered shift and facility suggestions</p>
                    </div>
                    <Switch 
                      checked={aiSettings.personalizedRecommendations}
                      onCheckedChange={(checked) => setAiSettings({...aiSettings, personalizedRecommendations: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Smart Matching</h4>
                      <p className="text-sm text-gray-600">Intelligent pairing with compatible facilities</p>
                    </div>
                    <Switch 
                      checked={aiSettings.smartMatching}
                      onCheckedChange={(checked) => setAiSettings({...aiSettings, smartMatching: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">AI Assistant</h4>
                      <p className="text-sm text-gray-600">Chat-based help and guidance</p>
                    </div>
                    <Switch 
                      checked={aiSettings.aiAssistant}
                      onCheckedChange={(checked) => setAiSettings({...aiSettings, aiAssistant: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Performance Analysis</h4>
                      <p className="text-sm text-gray-600">AI insights on your work patterns</p>
                    </div>
                    <Switch 
                      checked={aiSettings.dataAnalysis}
                      onCheckedChange={(checked) => setAiSettings({...aiSettings, dataAnalysis: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Auto-Optimization</h4>
                      <p className="text-sm text-gray-600">Automatic schedule and preference adjustments</p>
                    </div>
                    <Switch 
                      checked={aiSettings.autoOptimization}
                      onCheckedChange={(checked) => setAiSettings({...aiSettings, autoOptimization: checked})}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Security */}
          {activeTab === 'security' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Security Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Two-Factor Authentication</h4>
                      <p className="text-sm text-gray-600">Extra security for your account</p>
                    </div>
                    <Switch 
                      checked={security.twoFactor}
                      onCheckedChange={(checked) => setSecurity({...security, twoFactor: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Biometric Login</h4>
                      <p className="text-sm text-gray-600">Use fingerprint or face recognition</p>
                    </div>
                    <Switch 
                      checked={security.biometric}
                      onCheckedChange={(checked) => setSecurity({...security, biometric: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Login Alerts</h4>
                      <p className="text-sm text-gray-600">Notify when someone logs into your account</p>
                    </div>
                    <Switch 
                      checked={security.loginAlerts}
                      onCheckedChange={(checked) => setSecurity({...security, loginAlerts: checked})}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Session Timeout (minutes)
                    </label>
                    <select 
                      value={security.sessionTimeout}
                      onChange={(e) => setSecurity({...security, sessionTimeout: e.target.value})}
                      className="px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="15">15 minutes</option>
                      <option value="30">30 minutes</option>
                      <option value="60">1 hour</option>
                      <option value="240">4 hours</option>
                    </select>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Appearance */}
          {activeTab === 'appearance' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="w-5 h-5" />
                  Appearance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="font-medium mb-4">Theme</h4>
                  <div className="grid grid-cols-3 gap-3">
                    <button className="p-4 border-2 border-medical-blue rounded-lg bg-white">
                      <div className="w-full h-8 bg-gradient-to-r from-gray-100 to-gray-200 rounded mb-2"></div>
                      <span className="text-sm">Light</span>
                    </button>
                    <button className="p-4 border-2 border-gray-200 rounded-lg bg-gray-900">
                      <div className="w-full h-8 bg-gradient-to-r from-gray-700 to-gray-800 rounded mb-2"></div>
                      <span className="text-sm text-white">Dark</span>
                    </button>
                    <button className="p-4 border-2 border-gray-200 rounded-lg bg-gradient-to-br from-blue-50 to-purple-50">
                      <div className="w-full h-8 bg-gradient-to-r from-medical-blue to-ai-purple rounded mb-2"></div>
                      <span className="text-sm">Auto</span>
                    </button>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-4">Language</h4>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-md">
                    <option>English (US)</option>
                    <option>Spanish</option>
                    <option>French</option>
                    <option>German</option>
                  </select>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Account */}
          {activeTab === 'account' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="w-5 h-5" />
                  Account Management
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <Button variant="outline" className="w-full justify-start">
                    <Download className="w-4 h-4 mr-2" />
                    Download My Data
                  </Button>
                  
                  <Button variant="outline" className="w-full justify-start">
                    <Mail className="w-4 h-4 mr-2" />
                    Change Email Address
                  </Button>
                  
                  <Button variant="outline" className="w-full justify-start">
                    <Lock className="w-4 h-4 mr-2" />
                    Change Password
                  </Button>
                  
                  <div className="border-t pt-4">
                    <h4 className="font-medium text-red-700 mb-2">Danger Zone</h4>
                    <Button variant="destructive" className="w-full justify-start">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete Account
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
