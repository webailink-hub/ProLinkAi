export default function Privacy() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">
            Privacy Policy
          </h1>

          <div className="space-y-6 text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                1. Information We Collect
              </h2>
              <p>
                We collect information you provide directly to us, such as when
                you create an account, complete your profile, or contact us for
                support.
              </p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>
                  Personal identification information (name, email, phone
                  number)
                </li>
                <li>Professional credentials and certifications</li>
                <li>Work history and preferences</li>
                <li>Profile photos and documents</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                2. How We Use Your Information
              </h2>
              <ul className="list-disc list-inside space-y-2">
                <li>
                  To provide and maintain our healthcare staffing services
                </li>
                <li>
                  To match healthcare professionals with appropriate facilities
                </li>
                <li>To verify credentials and maintain safety standards</li>
                <li>To process payments and handle billing</li>
                <li>To communicate with you about your account and services</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                3. Information Sharing
              </h2>
              <p>
                We do not sell, trade, or otherwise transfer your personal
                information to third parties except as described in this policy:
              </p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>With healthcare facilities when you apply for shifts</li>
                <li>
                  With background check providers for verification purposes
                </li>
                <li>With payment processors for billing and payments</li>
                <li>When required by law or to protect our rights</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                4. HIPAA Compliance
              </h2>
              <p>
                ProLinkAi is committed to protecting health information in
                accordance with HIPAA regulations. We implement administrative,
                physical, and technical safeguards to protect your health
                information.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                5. Data Security
              </h2>
              <p>
                We implement industry-standard security measures to protect your
                personal information, including encryption, secure servers, and
                regular security audits.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                6. Your Rights
              </h2>
              <ul className="list-disc list-inside space-y-1">
                <li>Access your personal information</li>
                <li>Correct inaccurate information</li>
                <li>Delete your account and associated data</li>
                <li>Export your data in a portable format</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">
                7. Contact Us
              </h2>
              <p>
                If you have questions about this Privacy Policy, please contact
                us at:
              </p>
              <div className="mt-2">
                <p>Email: privacy@prolinkaid.com</p>
                <p>Phone: 1-800-PROLINK</p>
                <p>Address: 123 Healthcare Blvd, Medical City, CA 90210</p>
              </div>
            </section>
          </div>

          <div className="mt-8 text-sm text-gray-500">
            Last updated: January 2024
          </div>
        </div>
      </div>
    </div>
  );
}
