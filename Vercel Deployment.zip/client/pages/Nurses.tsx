import {
  Brain,
  Calendar,
  Clock,
  Shield,
  TrendingUp,
  Zap,
  CheckCircle2,
  Star,
  DollarSign,
  Award,
  Users,
  ArrowRight,
  MapPin,
  Smartphone,
  Heart,
  Target,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function Nurses() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-header font-bold text-gray-900">
                ProLink<span className="text-ai-purple">Ai</span>
              </span>
            </Link>

            <div className="hidden md:flex items-center space-x-8">
              <Link
                to="/nurses"
                className="text-medical-blue font-medium font-body"
              >
                For Nurses
              </Link>
              <Link
                to="/facilities"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                For Facilities
              </Link>
              <Link
                to="/about"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                About
              </Link>
              <Link
                to="/login"
                className="text-gray-600 hover:text-medical-blue transition-colors font-body"
              >
                Sign In
              </Link>
              <Link
                to="/register/nurse"
                className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-6 py-2 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium shadow-card hover:shadow-card-hover"
              >
                Join Now
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-medical-gray via-white to-blue-50 py-20 lg:py-32">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center bg-medical-green/10 text-medical-green px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Heart className="w-4 h-4 mr-2" />
                Trusted by 15,000+ Healthcare Professionals
              </div>
              <h1 className="text-4xl lg:text-6xl font-header font-bold text-gray-900 leading-tight mb-6">
                Your Career,
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-medical-blue to-ai-purple block">
                  AI-Enhanced
                </span>
              </h1>
              <p className="text-xl text-gray-600 font-body leading-relaxed mb-8">
                Join thousands of nurses using AI to find perfect shifts, manage
                credentials, and accelerate their careers. Work smarter, not
                harder.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <Link
                  to="/register/nurse"
                  className="bg-gradient-to-r from-medical-blue to-ai-purple text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:to-purple-600 transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 text-center"
                >
                  Start Your AI-Powered Career
                </Link>
                <Link
                  to="/dashboard/shifts"
                  className="bg-white text-medical-blue border-2 border-medical-blue px-8 py-4 rounded-xl hover:bg-medical-blue hover:text-white transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 text-center"
                >
                  Browse AI-Matched Shifts
                </Link>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-header font-bold text-medical-blue">
                    50%
                  </div>
                  <div className="text-sm text-gray-600 font-body">
                    Faster Shift Discovery
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-header font-bold text-medical-green">
                    24h
                  </div>
                  <div className="text-sm text-gray-600 font-body">
                    Average Payout Time
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-header font-bold text-ai-purple">
                    98%
                  </div>
                  <div className="text-sm text-gray-600 font-body">
                    Nurse Satisfaction
                  </div>
                </div>
              </div>
            </div>

            {/* Hero Visual */}
            <div className="relative">
              <div className="bg-gradient-to-br from-medical-blue via-ai-purple to-medical-teal rounded-3xl p-8 shadow-card-hover">
                <div className="bg-white/95 backdrop-blur rounded-2xl p-6 mb-6">
                  <div className="flex items-center mb-4">
                    <Brain className="w-8 h-8 text-ai-purple mr-3" />
                    <div>
                      <h3 className="font-header font-semibold text-gray-900">
                        AI Recommendations
                      </h3>
                      <p className="text-sm text-gray-600">
                        Personalized for your skills
                      </p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-medical-blue/10 rounded-lg">
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 text-medical-blue mr-2" />
                        <span className="text-sm font-medium">
                          ICU • City General
                        </span>
                      </div>
                      <span className="text-sm font-bold text-medical-blue">
                        $45/hr
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-medical-green/10 rounded-lg">
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 text-medical-green mr-2" />
                        <span className="text-sm font-medium">
                          Night Shift • Metro Care
                        </span>
                      </div>
                      <span className="text-sm font-bold text-medical-green">
                        $52/hr
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-center text-white">
                  <Zap className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm opacity-90">Powered by Advanced AI</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose ProLinkAi */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Why 15,000+ Nurses Choose ProLinkAi
            </h2>
            <p className="text-xl text-gray-600 font-body max-w-3xl mx-auto">
              Our AI-powered platform is designed by nurses, for nurses.
              Experience the future of healthcare careers.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Benefit 1 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1">
              <div className="w-12 h-12 bg-gradient-to-br from-ai-purple to-medical-blue rounded-xl flex items-center justify-center mb-6">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                AI-Powered Shift Matching
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Our AI analyzes your skills, preferences, and availability to
                recommend perfect shifts. No more endless scrolling through
                irrelevant postings.
              </p>
              <div className="text-medical-blue font-medium text-sm">
                Find your ideal shift 5x faster →
              </div>
            </div>

            {/* Benefit 2 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1">
              <div className="w-12 h-12 bg-gradient-to-br from-medical-green to-medical-teal rounded-xl flex items-center justify-center mb-6">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Fast & Secure Payouts
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Get paid in 24 hours with our automated payroll system. Track
                earnings, view payment history, and set up direct deposit
                seamlessly.
              </p>
              <div className="text-medical-green font-medium text-sm">
                Average payout: 24 hours →
              </div>
            </div>

            {/* Benefit 3 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1">
              <div className="w-12 h-12 bg-gradient-to-br from-accent-orange to-medical-green rounded-xl flex items-center justify-center mb-6">
                <Award className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Smart Credential Management
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                AI-powered credential tracking with automated renewal reminders.
                Upload once, use everywhere. Never miss a certification
                deadline.
              </p>
              <div className="text-accent-orange font-medium text-sm">
                100% compliance guaranteed →
              </div>
            </div>

            {/* Benefit 4 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1">
              <div className="w-12 h-12 bg-gradient-to-br from-medical-blue to-medical-teal rounded-xl flex items-center justify-center mb-6">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Flexible Scheduling
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Work when you want, where you want. Our platform adapts to your
                lifestyle with real-time shift availability and instant booking.
              </p>
              <div className="text-medical-blue font-medium text-sm">
                Complete work-life balance →
              </div>
            </div>

            {/* Benefit 5 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1">
              <div className="w-12 h-12 bg-gradient-to-br from-ai-purple to-accent-orange rounded-xl flex items-center justify-center mb-6">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Career Growth Insights
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Get personalized career recommendations, skill development
                suggestions, and market insights to advance your nursing career.
              </p>
              <div className="text-ai-purple font-medium text-sm">
                Accelerate your growth →
              </div>
            </div>

            {/* Benefit 6 */}
            <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-200 hover:-translate-y-1">
              <div className="w-12 h-12 bg-gradient-to-br from-medical-teal to-ai-purple rounded-xl flex items-center justify-center mb-6">
                <Smartphone className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Mobile-First Experience
              </h3>
              <p className="text-gray-600 font-body leading-relaxed mb-4">
                Manage your career on-the-go with our mobile-optimized platform.
                Apply to shifts, track hours, and get paid from anywhere.
              </p>
              <div className="text-medical-teal font-medium text-sm">
                Work from anywhere →
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-medical-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              What Nurses Are Saying
            </h2>
            <p className="text-xl text-gray-600 font-body">
              Real stories from healthcare professionals using ProLinkAi
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 text-yellow-400 fill-current"
                  />
                ))}
              </div>
              <p className="text-gray-700 font-body leading-relaxed mb-6">
                "ProLinkAi's AI matching saved me hours of searching. I found my
                ideal ICU shifts immediately, and the pay is always on time.
                Game-changer for my career!"
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-medical-blue to-ai-purple rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">SJ</span>
                </div>
                <div>
                  <div className="font-medium text-gray-900">
                    Sarah Johnson, RN
                  </div>
                  <div className="text-sm text-gray-600">
                    ICU Specialist • 3 years on platform
                  </div>
                </div>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 text-yellow-400 fill-current"
                  />
                ))}
              </div>
              <p className="text-gray-700 font-body leading-relaxed mb-6">
                "The credential management feature is incredible. I never worry
                about renewals, and facilities trust ProLinkAi's verification.
                It's professional and seamless."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-medical-green to-medical-teal rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">MC</span>
                </div>
                <div>
                  <div className="font-medium text-gray-900">
                    Maria Chen, BSN
                  </div>
                  <div className="text-sm text-gray-600">
                    OR Nurse • Platform power user
                  </div>
                </div>
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white rounded-2xl p-8 shadow-card">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 text-yellow-400 fill-current"
                  />
                ))}
              </div>
              <p className="text-gray-700 font-body leading-relaxed mb-6">
                "I've increased my income by 40% using ProLinkAi. The
                flexibility lets me work around my family schedule while
                advancing my career. Highly recommend!"
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-ai-purple to-accent-orange rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">DW</span>
                </div>
                <div>
                  <div className="font-medium text-gray-900">
                    David Williams, RN
                  </div>
                  <div className="text-sm text-gray-600">
                    ER Nurse • Top performer
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-header font-bold text-gray-900 mb-4">
              Start Your AI-Enhanced Career in 3 Steps
            </h2>
            <p className="text-xl text-gray-600 font-body">
              Get started in minutes, not hours
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Sign Up & Verify
              </h3>
              <p className="text-gray-600 font-body leading-relaxed">
                Create your profile and upload credentials. Our AI verifies
                everything automatically for instant approval.
              </p>
            </div>

            {/* Step 2 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-medical-green to-medical-teal rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Get AI Recommendations
              </h3>
              <p className="text-gray-600 font-body leading-relaxed">
                Our AI analyzes your profile to recommend perfect shift matches.
                Apply with one click directly from your dashboard.
              </p>
            </div>

            {/* Step 3 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-ai-purple to-accent-orange rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-header font-semibold text-gray-900 mb-4">
                Work & Get Paid
              </h3>
              <p className="text-gray-600 font-body leading-relaxed">
                Complete your shifts and get paid fast. Track your earnings and
                career growth with comprehensive analytics.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-medical-blue via-ai-purple to-medical-teal">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white/10 backdrop-blur rounded-full p-4 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
            <Brain className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl lg:text-4xl font-header font-bold text-white mb-6">
            Ready to Transform Your Nursing Career?
          </h2>
          <p className="text-xl text-blue-100 font-body mb-8 leading-relaxed">
            Join 15,000+ nurses already using AI to advance their careers. Start
            finding better shifts, earning more, and working smarter today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register/nurse"
              className="bg-white text-medical-blue px-8 py-4 rounded-xl hover:bg-gray-50 transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5 inline-flex items-center justify-center"
            >
              Start Free Today
              <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
            <Link
              to="/dashboard/shifts"
              className="bg-transparent text-white border-2 border-white px-8 py-4 rounded-xl hover:bg-white hover:text-medical-blue transition-all duration-200 font-body font-medium text-lg shadow-card hover:shadow-card-hover transform hover:-translate-y-0.5"
            >
              Browse Shifts
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-ai-purple rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <span className="ml-3 text-xl font-header font-bold">
                  ProLink<span className="text-ai-purple">Ai</span>
                </span>
              </div>
              <p className="text-gray-400 font-body leading-relaxed mb-6">
                Empowering healthcare professionals with AI-driven career
                solutions. Join the future of nursing today.
              </p>
              <div className="text-sm text-gray-400 font-body">
                © 2024 ProLinkAi. All rights reserved.
              </div>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-4">For Nurses</h3>
              <ul className="space-y-2 font-body">
                <li>
                  <Link
                    to="/dashboard/shifts"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Find Shifts
                  </Link>
                </li>
                <li>
                  <Link
                    to="/dashboard/my-credentials"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Manage Credentials
                  </Link>
                </li>
                <li>
                  <Link
                    to="/dashboard/payouts"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Track Earnings
                  </Link>
                </li>
                <li>
                  <Link
                    to="/dashboard/help"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Get Support
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-header font-semibold mb-4">Company</h3>
              <ul className="space-y-2 font-body">
                <li>
                  <Link
                    to="/about"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/facilities"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    For Facilities
                  </Link>
                </li>
                <li>
                  <Link
                    to="/contact"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Contact
                  </Link>
                </li>
                <li>
                  <Link
                    to="/careers"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Careers
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
