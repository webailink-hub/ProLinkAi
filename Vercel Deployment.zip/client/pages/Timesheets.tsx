import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Clock,
  Calendar,
  DollarSign,
  Camera,
  Upload,
  Download,
  Eye,
  Edit3,
  CheckCircle2,
  AlertCircle,
  Clock3,
  MapPin,
  Building2,
  User,
  FileText,
  Filter,
  Search,
  Plus,
  Zap,
  BarChart3,
  TrendingUp,
  AlertTriangle,
  ArrowUpRight,
  MoreHorizontal,
  Trash2,
} from "lucide-react";

interface Timesheet {
  id: string;
  facilityName: string;
  facilityLogo: string;
  position: string;
  shiftDate: string;
  clockIn: string;
  clockOut: string;
  breakTime: number;
  hoursWorked: number;
  hourlyRate: number;
  totalPay: number;
  status: "draft" | "submitted" | "under_review" | "approved" | "paid" | "disputed";
  submittedDate?: string;
  approvedDate?: string;
  paidDate?: string;
  hasPhoto: boolean;
  notes: string;
  overtime: number;
  location: string;
  supervisor: string;
  anomalies?: string[];
}

export default function Timesheets() {
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTimesheet, setSelectedTimesheet] = useState<Timesheet | null>(null);
  const [showNewTimesheet, setShowNewTimesheet] = useState(false);

  // Mock data - in real app this would come from API
  const timesheets: Timesheet[] = [
    {
      id: "TS-001",
      facilityName: "UCSF Medical Center",
      facilityLogo: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=64&h=64&fit=crop",
      position: "ICU Nurse",
      shiftDate: "Jan 15, 2024",
      clockIn: "07:00 AM",
      clockOut: "07:30 PM",
      breakTime: 30,
      hoursWorked: 12,
      hourlyRate: 58,
      totalPay: 696,
      status: "submitted",
      submittedDate: "Jan 16, 2024",
      hasPhoto: true,
      notes: "Busy night shift with 2 critical patients",
      overtime: 0,
      location: "ICU Unit 3",
      supervisor: "Sarah Johnson, RN",
    },
    {
      id: "TS-002",
      facilityName: "Stanford Hospital",
      facilityLogo: "https://images.unsplash.com/photo-1551076805-e1869033e561?w=64&h=64&fit=crop",
      position: "Emergency Nurse",
      shiftDate: "Jan 12, 2024",
      clockIn: "11:00 PM",
      clockOut: "07:15 AM",
      breakTime: 45,
      hoursWorked: 8,
      hourlyRate: 52,
      totalPay: 416,
      status: "approved",
      submittedDate: "Jan 13, 2024",
      approvedDate: "Jan 14, 2024",
      hasPhoto: true,
      notes: "Standard night shift",
      overtime: 0.25,
      location: "Emergency Department",
      supervisor: "Michael Chen, MD",
    },
    {
      id: "TS-003",
      facilityName: "Kaiser Permanente",
      facilityLogo: "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=64&h=64&fit=crop",
      position: "Med-Surg Nurse",
      shiftDate: "Jan 10, 2024",
      clockIn: "07:00 AM",
      clockOut: "07:00 PM",
      breakTime: 60,
      hoursWorked: 11,
      hourlyRate: 48,
      totalPay: 528,
      status: "paid",
      submittedDate: "Jan 11, 2024",
      approvedDate: "Jan 12, 2024",
      paidDate: "Jan 15, 2024",
      hasPhoto: true,
      notes: "",
      overtime: 0,
      location: "Med-Surg Floor 4",
      supervisor: "Lisa Rodriguez, RN",
    },
    {
      id: "TS-004",
      facilityName: "SF General Hospital",
      facilityLogo: "https://images.unsplash.com/photo-1504813184591-01572f98c85f?w=64&h=64&fit=crop",
      position: "Float Nurse",
      shiftDate: "Jan 8, 2024",
      clockIn: "03:00 PM",
      clockOut: "11:30 PM",
      breakTime: 30,
      hoursWorked: 8,
      hourlyRate: 55,
      totalPay: 440,
      status: "disputed",
      submittedDate: "Jan 9, 2024",
      hasPhoto: false,
      notes: "Shift extended due to emergency",
      overtime: 0.5,
      location: "Multiple Units",
      supervisor: "David Wilson, RN",
      anomalies: ["Late clock out", "Missing photo verification"],
    },
    {
      id: "TS-005",
      facilityName: "UCSF Medical Center",
      facilityLogo: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=64&h=64&fit=crop",
      position: "ICU Nurse",
      shiftDate: "Jan 5, 2024",
      clockIn: "07:00 AM",
      clockOut: "07:00 PM",
      breakTime: 30,
      hoursWorked: 12,
      hourlyRate: 58,
      totalPay: 696,
      status: "draft",
      hasPhoto: false,
      notes: "",
      overtime: 0,
      location: "ICU Unit 2",
      supervisor: "Amanda Taylor, RN",
    },
  ];

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { bg: "bg-gray-100", text: "text-gray-800", label: "Draft" },
      submitted: { bg: "bg-blue-100", text: "text-blue-800", label: "Submitted" },
      under_review: { bg: "bg-yellow-100", text: "text-yellow-800", label: "Under Review" },
      approved: { bg: "bg-green-100", text: "text-green-800", label: "Approved" },
      paid: { bg: "bg-emerald-100", text: "text-emerald-800", label: "Paid" },
      disputed: { bg: "bg-red-100", text: "text-red-800", label: "Disputed" },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig];
    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        {config.label}
      </span>
    );
  };

  const filteredTimesheets = timesheets.filter(timesheet => {
    const matchesSearch = timesheet.facilityName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         timesheet.position.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTab = activeTab === "all" || timesheet.status === activeTab;
    return matchesSearch && matchesTab;
  });

  const statusCounts = {
    all: timesheets.length,
    draft: timesheets.filter(t => t.status === "draft").length,
    submitted: timesheets.filter(t => t.status === "submitted").length,
    approved: timesheets.filter(t => t.status === "approved").length,
    paid: timesheets.filter(t => t.status === "paid").length,
    disputed: timesheets.filter(t => t.status === "disputed").length,
  };

  const totalEarnings = timesheets.filter(t => t.status === "paid").reduce((sum, t) => sum + t.totalPay, 0);
  const pendingEarnings = timesheets.filter(t => ["submitted", "approved"].includes(t.status)).reduce((sum, t) => sum + t.totalPay, 0);
  const totalHours = timesheets.filter(t => t.status === "paid").reduce((sum, t) => sum + t.hoursWorked, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-header font-bold text-gray-900 flex items-center">
            <Clock className="w-8 h-8 mr-3 text-medical-blue" />
            Digital Timesheets
          </h1>
          <p className="text-gray-600 font-body mt-2">
            Smart time tracking with AI-powered verification and automated calculations
          </p>
        </div>

        <div className="flex items-center gap-3 mt-4 lg:mt-0">
          <button 
            onClick={() => setShowNewTimesheet(true)}
            className="bg-medical-blue text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Timesheet
          </button>
          <button className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center font-medium">
            <Download className="w-4 h-4 mr-2" />
            Export
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
            <div className="flex items-center text-green-600 text-sm">
              <ArrowUpRight className="w-4 h-4 mr-1" />
              +12%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            ${totalEarnings.toLocaleString()}
          </h3>
          <p className="text-gray-600 font-body">Total Earnings (Paid)</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
            <div className="flex items-center text-blue-600 text-sm">
              <ArrowUpRight className="w-4 h-4 mr-1" />
              +8%
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">{totalHours}</h3>
          <p className="text-gray-600 font-body">Hours Worked</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-card border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
              <Clock3 className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="text-yellow-600 text-sm">
              Pending
            </div>
          </div>
          <h3 className="text-2xl font-header font-bold text-gray-900">
            ${pendingEarnings.toLocaleString()}
          </h3>
          <p className="text-gray-600 font-body">Pending Approval</p>
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-br from-ai-purple to-medical-blue rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Zap className="w-6 h-6 mr-3" />
            <h2 className="text-xl font-header font-bold">AI Time Insights</h2>
          </div>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <BarChart3 className="w-5 h-5 text-white" />
              <span className="text-xs bg-white/20 px-2 py-1 rounded">This Month</span>
            </div>
            <h3 className="font-semibold mb-1">Average Shift Length</h3>
            <p className="text-blue-100 text-sm">11.2 hours (within normal range)</p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-5 h-5 text-white" />
              <span className="text-xs bg-white/20 px-2 py-1 rounded">Trend</span>
            </div>
            <h3 className="font-semibold mb-1">Overtime Pattern</h3>
            <p className="text-blue-100 text-sm">2.3% below facility average</p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <CheckCircle2 className="w-5 h-5 text-white" />
              <span className="text-xs bg-white/20 px-2 py-1 rounded">Quality</span>
            </div>
            <h3 className="font-semibold mb-1">Accuracy Score</h3>
            <p className="text-blue-100 text-sm">98.5% (excellent)</p>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            {Object.entries(statusCounts).map(([status, count]) => (
              <button
                key={status}
                onClick={() => setActiveTab(status)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  activeTab === status
                    ? "bg-medical-blue text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ')} ({count})
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search timesheets..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent w-64"
              />
            </div>
            <button className="p-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
              <Filter className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Timesheet List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Shift Details
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Time & Hours
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Earnings
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredTimesheets.map((timesheet) => (
                <tr key={timesheet.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <img
                        src={timesheet.facilityLogo}
                        alt={timesheet.facilityName}
                        className="w-10 h-10 rounded-lg object-cover mr-3"
                      />
                      <div>
                        <div className="font-medium text-gray-900">{timesheet.facilityName}</div>
                        <div className="text-sm text-gray-600">{timesheet.position}</div>
                        <div className="text-xs text-gray-500 flex items-center mt-1">
                          <Calendar className="w-3 h-3 mr-1" />
                          {timesheet.shiftDate}
                        </div>
                      </div>
                    </div>
                  </td>
                  
                  <td className="px-6 py-4">
                    <div className="text-sm">
                      <div className="font-medium text-gray-900">
                        {timesheet.clockIn} - {timesheet.clockOut}
                      </div>
                      <div className="text-gray-600">
                        {timesheet.hoursWorked} hours
                        {timesheet.overtime > 0 && (
                          <span className="text-orange-600 ml-2">
                            (+{timesheet.overtime}h OT)
                          </span>
                        )}
                      </div>
                      <div className="flex items-center mt-1">
                        {timesheet.hasPhoto ? (
                          <div className="flex items-center text-green-600 text-xs">
                            <Camera className="w-3 h-3 mr-1" />
                            Verified
                          </div>
                        ) : (
                          <div className="flex items-center text-yellow-600 text-xs">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Missing Photo
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  
                  <td className="px-6 py-4">
                    <div className="text-sm">
                      <div className="font-medium text-gray-900">${timesheet.totalPay}</div>
                      <div className="text-gray-600">${timesheet.hourlyRate}/hr</div>
                    </div>
                  </td>
                  
                  <td className="px-6 py-4">
                    <div className="space-y-2">
                      {getStatusBadge(timesheet.status)}
                      {timesheet.anomalies && timesheet.anomalies.length > 0 && (
                        <div className="flex items-center text-red-600 text-xs">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          {timesheet.anomalies.length} anomal{timesheet.anomalies.length === 1 ? 'y' : 'ies'}
                        </div>
                      )}
                    </div>
                  </td>
                  
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setSelectedTimesheet(timesheet)}
                        className="text-gray-600 hover:text-medical-blue transition-colors"
                        title="View details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      {timesheet.status === "draft" && (
                        <button
                          className="text-gray-600 hover:text-medical-blue transition-colors"
                          title="Edit timesheet"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                      )}
                      <button className="text-gray-600 hover:text-gray-900 transition-colors">
                        <MoreHorizontal className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredTimesheets.length === 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No timesheets found</h3>
          <p className="text-gray-600 mb-6">
            Start tracking your time by creating a new timesheet.
          </p>
          <button 
            onClick={() => setShowNewTimesheet(true)}
            className="bg-medical-blue text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Create First Timesheet
          </button>
        </div>
      )}

      {/* Timesheet Detail Modal */}
      {selectedTimesheet && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-header font-bold text-gray-900">
                Timesheet Details
              </h2>
              <button
                onClick={() => setSelectedTimesheet(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                ×
              </button>
            </div>
            
            <div className="p-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Shift Information</h3>
                  <div className="space-y-3 text-sm">
                    <div>
                      <span className="text-gray-600">Facility:</span>
                      <div className="font-medium">{selectedTimesheet.facilityName}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Position:</span>
                      <div className="font-medium">{selectedTimesheet.position}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Date:</span>
                      <div className="font-medium">{selectedTimesheet.shiftDate}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Location:</span>
                      <div className="font-medium">{selectedTimesheet.location}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Supervisor:</span>
                      <div className="font-medium">{selectedTimesheet.supervisor}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Time & Pay</h3>
                  <div className="space-y-3 text-sm">
                    <div>
                      <span className="text-gray-600">Clock In:</span>
                      <div className="font-medium">{selectedTimesheet.clockIn}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Clock Out:</span>
                      <div className="font-medium">{selectedTimesheet.clockOut}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Break Time:</span>
                      <div className="font-medium">{selectedTimesheet.breakTime} minutes</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Hours Worked:</span>
                      <div className="font-medium">{selectedTimesheet.hoursWorked} hours</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Hourly Rate:</span>
                      <div className="font-medium">${selectedTimesheet.hourlyRate}/hr</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Total Pay:</span>
                      <div className="font-medium text-lg text-green-600">${selectedTimesheet.totalPay}</div>
                    </div>
                  </div>
                </div>
              </div>

              {selectedTimesheet.notes && (
                <div className="mt-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Notes</h3>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-gray-700">{selectedTimesheet.notes}</p>
                  </div>
                </div>
              )}

              {selectedTimesheet.anomalies && selectedTimesheet.anomalies.length > 0 && (
                <div className="mt-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
                    AI-Detected Anomalies
                  </h3>
                  <div className="space-y-2">
                    {selectedTimesheet.anomalies.map((anomaly, index) => (
                      <div key={index} className="bg-red-50 border border-red-200 rounded-lg p-3">
                        <p className="text-red-800 text-sm">{anomaly}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200">
                <button
                  onClick={() => setSelectedTimesheet(null)}
                  className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Close
                </button>
                {selectedTimesheet.status === "draft" && (
                  <button className="px-6 py-2 bg-medical-blue text-white rounded-lg hover:bg-blue-700 transition-colors">
                    Submit Timesheet
                  </button>
                )}
                <button className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                  Download PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
