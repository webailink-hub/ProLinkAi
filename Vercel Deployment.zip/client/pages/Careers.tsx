import { MapPin, Clock, DollarSign, Users, Heart, Zap } from "lucide-react";

const jobListings = [
  {
    id: 1,
    title: "Senior Full Stack Developer",
    department: "Engineering",
    location: "Remote / San Francisco, CA",
    type: "Full-time",
    salary: "$120k - $180k",
    description:
      "Join our engineering team to build the future of healthcare staffing technology.",
  },
  {
    id: 2,
    title: "Healthcare Operations Specialist",
    department: "Operations",
    location: "Medical City, CA",
    type: "Full-time",
    salary: "$70k - $90k",
    description:
      "Help optimize our healthcare staffing operations and improve nurse-facility matching.",
  },
  {
    id: 3,
    title: "Product Manager",
    department: "Product",
    location: "Remote / Medical City, CA",
    type: "Full-time",
    salary: "$110k - $150k",
    description:
      "Lead product strategy for our healthcare staffing platform and mobile applications.",
  },
  {
    id: 4,
    title: "Customer Success Manager",
    department: "Customer Success",
    location: "Remote",
    type: "Full-time",
    salary: "$65k - $85k",
    description:
      "Ensure our healthcare partners have an exceptional experience with our platform.",
  },
];

const benefits = [
  {
    icon: Heart,
    title: "Healthcare Coverage",
    description:
      "Comprehensive medical, dental, and vision insurance for you and your family.",
  },
  {
    icon: Clock,
    title: "Flexible Hours",
    description:
      "Work-life balance with flexible schedules and remote work options.",
  },
  {
    icon: DollarSign,
    title: "Competitive Salary",
    description:
      "Market-leading compensation with performance bonuses and equity options.",
  },
  {
    icon: Users,
    title: "Great Team",
    description:
      "Work with passionate professionals who are changing healthcare staffing.",
  },
  {
    icon: Zap,
    title: "Growth Opportunities",
    description:
      "Professional development budget and clear career advancement paths.",
  },
];

export default function Careers() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-medical-blue to-ai-purple text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Join Our Mission
          </h1>
          <p className="text-xl max-w-3xl mx-auto mb-8">
            Help us revolutionize healthcare staffing and make a real difference
            in patients' lives.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#open-positions"
              className="bg-white text-medical-blue px-8 py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors"
            >
              View Open Positions
            </a>
            <a
              href="/contact"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-medium hover:bg-white hover:text-medical-blue transition-colors"
            >
              Contact HR
            </a>
          </div>
        </div>
      </div>

      {/* Why Work With Us */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why ProLinkAi?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We're building the future of healthcare staffing, and we want you
              to be part of it.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon;
              return (
                <div
                  key={index}
                  className="bg-white rounded-lg p-6 shadow-sm border border-gray-200"
                >
                  <div className="w-12 h-12 bg-medical-blue/10 rounded-lg flex items-center justify-center mb-4">
                    <IconComponent className="w-6 h-6 text-medical-blue" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {benefit.title}
                  </h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Open Positions */}
      <div id="open-positions" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Open Positions
            </h2>
            <p className="text-lg text-gray-600">
              Find your next opportunity and help us improve healthcare
              staffing.
            </p>
          </div>

          <div className="space-y-6">
            {jobListings.map((job) => (
              <div
                key={job.id}
                className="bg-gray-50 rounded-lg p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                      <h3 className="text-xl font-semibold text-gray-900">
                        {job.title}
                      </h3>
                      <span className="text-lg font-medium text-medical-blue">
                        {job.salary}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-3">
                      <span className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {job.department}
                      </span>
                      <span className="flex items-center">
                        <MapPin className="w-4 h-4 mr-1" />
                        {job.location}
                      </span>
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {job.type}
                      </span>
                    </div>

                    <p className="text-gray-700">{job.description}</p>
                  </div>

                  <div className="mt-4 lg:mt-0 lg:ml-6">
                    <button className="w-full lg:w-auto bg-medical-blue text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                      Apply Now
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Culture Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Our Culture
              </h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  At ProLinkAi, we believe that great healthcare starts with
                  great people. Our team is passionate about improving the
                  healthcare industry through innovative technology and
                  human-centered design.
                </p>
                <p>
                  We foster a collaborative environment where every team
                  member's voice is heard and valued. Whether you're an
                  engineer, designer, or healthcare specialist, your expertise
                  contributes to our mission of connecting the right healthcare
                  professionals with the right opportunities.
                </p>
                <p>
                  Join us in building technology that makes a real difference in
                  patients' lives and healthcare workers' careers.
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-medical-blue/10 to-ai-purple/10 rounded-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                Our Values
              </h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-medical-blue rounded-full mt-2 mr-3"></div>
                  <span>
                    <strong>Patient First:</strong> Every decision we make
                    considers patient outcomes.
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-medical-blue rounded-full mt-2 mr-3"></div>
                  <span>
                    <strong>Innovation:</strong> We embrace new ideas and
                    cutting-edge technology.
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-medical-blue rounded-full mt-2 mr-3"></div>
                  <span>
                    <strong>Integrity:</strong> We operate with transparency and
                    ethical practices.
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-medical-blue rounded-full mt-2 mr-3"></div>
                  <span>
                    <strong>Excellence:</strong> We strive for the highest
                    quality in everything we do.
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-medical-blue text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Make an Impact?</h2>
          <p className="text-xl mb-8">
            Don't see a position that matches your skills? We're always looking
            for talented individuals.
          </p>
          <a
            href="/contact"
            className="bg-white text-medical-blue px-8 py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors inline-block"
          >
            Send Us Your Resume
          </a>
        </div>
      </div>
    </div>
  );
}
