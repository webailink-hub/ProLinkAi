import type { VercelRequest, VercelResponse } from "@vercel/node";
import type { DemoResponse } from "../shared/api";

export default function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "GET") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  const response: DemoResponse = {
    message: "Hello from demo endpoint! (Vercel)",
    timestamp: new Date().toISOString(),
    env: process.env.NODE_ENV || "development",
  };

  res.json(response);
}
