# Deployment Guide

This project supports deployment on both Netlify and Vercel.

## Vercel Deployment

### Prerequisites

- Vercel account
- Project connected to Git repository

### Setup Steps

1. **Install Vercel CLI** (optional, for manual deployment):

   ```bash
   npm i -g vercel
   ```

2. **Deploy to Vercel**:

   - **Option A**: Connect your Git repository to Vercel dashboard
   - **Option B**: Use Vercel CLI:
     ```bash
     vercel
     ```

3. **Configuration**:
   - Build Command: `npm run build:vercel`
   - Output Directory: `dist/spa`
   - Install Command: `npm install`

### Environment Variables

Set these in your Vercel dashboard:

- `PING_MESSAGE` (optional): Custom ping response message

### API Routes

API endpoints are automatically deployed as serverless functions:

- `/api/ping` - Health check endpoint
- `/api/demo` - Demo endpoint

### Important Notes

- API routes are in the `/api` directory as serverless functions
- Frontend is served from the `/dist/spa` directory
- SPA routing is handled automatically with fallback to `index.html`

## Netlify Deployment (Alternative)

The project also includes Netlify configuration files if you prefer Netlify:

- `netlify.toml` - Netlify configuration
- `netlify/functions/` - Netlify functions

## Local Development

```bash
npm run dev
```

The development server runs on `http://localhost:8080` with both frontend and backend integrated.
